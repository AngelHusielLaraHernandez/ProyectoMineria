# Carpeta: Final/reports/figures

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## clase_ward_dendrograma.png

Ruta: `Final/reports/figures/clase_ward_dendrograma.png` · Bytes: 37708 · SHA-256: `a98f0f2b12ec4a2d0a00937e1921cfe2469508de337fc6b35fce598156fac7ea`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## clustering_03_dbscan_kdistancia.png

Ruta: `Final/reports/figures/clustering_03_dbscan_kdistancia.png` · Bytes: 46042 · SHA-256: `a93d6ab341dd4acb891beca3400aa92f323839b4c12db2a2976678e29d45dc3e`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## clustering_03_kmeans.png

Ruta: `Final/reports/figures/clustering_03_kmeans.png` · Bytes: 77963 · SHA-256: `de7fbe2d10efb23f90f682d5edc829bd7c511f6992f94d672e6f09170bab75b7`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## clustering_03_proyeccion.png

Ruta: `Final/reports/figures/clustering_03_proyeccion.png` · Bytes: 257834 · SHA-256: `5c7d6a516039cda6137d177e710e8fe394f7c587c49565422414bdbe9608a4ee`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## comparacion_mlp.png

Ruta: `Final/reports/figures/comparacion_mlp.png` · Bytes: 75804 · SHA-256: `e21b87b301c62502b16f4cfc613154ad53773fe47320d7288d3a0ebd9035fee1`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## contraste_tarjetas_escritorio.png

Ruta: `Final/reports/figures/contraste_tarjetas_escritorio.png` · Bytes: 209628 · SHA-256: `06772bc10dfa0bd121b66fdfb33880c7c4c84998d10e13e7da37e6e7a08382ec`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## contraste_tarjetas_movil.png

Ruta: `Final/reports/figures/contraste_tarjetas_movil.png` · Bytes: 107163 · SHA-256: `50706e2a0432f6fb98df05e449804bf29ec2c3f6f402d7d0e2d1505e3366a0c0`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## dashboard_interactivo.png

Ruta: `Final/reports/figures/dashboard_interactivo.png` · Bytes: 110049 · SHA-256: `85f4fdb18a451962642900462eb6c9839ca523ae82dbf6d45f4abdede28aa2dc`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_decadas.png

Ruta: `Final/reports/figures/eda_decadas.png` · Bytes: 22950 · SHA-256: `4f9f44af3109b8201b4b1a8e52376873a120008c81f86146e902683f230d97c2`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_generos_top15.png

Ruta: `Final/reports/figures/eda_generos_top15.png` · Bytes: 48049 · SHA-256: `97e8cd9427a31665e88b23d81e01d315dd0569dc70d5e64018ee046be89ebcd1`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_metacritic.png

Ruta: `Final/reports/figures/eda_metacritic.png` · Bytes: 26557 · SHA-256: `8e8f59559b5f1e3f7307f5e27d44866a85ebcf6109bb7336cfcebff178ba8aa2`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_plays_log.png

Ruta: `Final/reports/figures/eda_plays_log.png` · Bytes: 25053 · SHA-256: `98fa2e089196009093ebb4b81541724bbbc532fcdd8298df130adc9dc7c87c61`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_rating.png

Ruta: `Final/reports/figures/eda_rating.png` · Bytes: 23622 · SHA-256: `3816988b211c3dd994d0ea14b20e505d368d4cb60f0512ab71f0e0102478d623`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## eda_rating_vs_metacritic.png

Ruta: `Final/reports/figures/eda_rating_vs_metacritic.png` · Bytes: 61497 · SHA-256: `5c53a6dd10e6ef5de174f9671e93246273a302280ba75a679568ad611b90ba44`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## intervalos_importancia.png

Ruta: `Final/reports/figures/intervalos_importancia.png` · Bytes: 76905 · SHA-256: `5c3c24525104f89fe49c2eca22dc33ed8c3bb10ba2750db6e3fca07afb4098ac`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## intervalos_modelo.png

Ruta: `Final/reports/figures/intervalos_modelo.png` · Bytes: 84049 · SHA-256: `6252ac5ff0df2d74c27e08ebd1d8eeb4fe43e0cab8de8203b51e8e8b048519b1`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## pca_tres_metodos.png

Ruta: `Final/reports/figures/pca_tres_metodos.png` · Bytes: 182720 · SHA-256: `9ce21e8a1588cc6553a139d9535d92a5529dc54272267c1d558f7b942061abbf`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

