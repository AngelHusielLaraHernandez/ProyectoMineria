# Carpeta: Final/assets/css

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## persona5.css

Ruta: `Final/assets/css/persona5.css` · Bytes: 48156 · SHA-256: `61722d836e0392b8530f1014ab09949f2047e28d464904b5a7c93991bdb37d2b`

````text
/* ==========================================================================
   PHANTOM'S PERSONA — IDENTIDAD AZUL MEDIANOCHE & NEÓN ACCESIBLE (WCAG AA)
   ========================================================================== */

:root {
  --p5-black: var(--bg-primary);
  --p5-surface: var(--bg-panel);
  --p5-red: var(--primary);
  --p5-dark-red: var(--bg-chart);
  --p5-white: var(--text-primary);
  --p5-gray: var(--text-secondary);
  --p5-yellow: var(--accent);
  --p5-cyan: var(--secondary);
  --font-display: 'ComicProyecto', system-ui, -apple-system, sans-serif;
  --font-body: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  color-scheme: dark;
  accent-color: var(--primary-dark, #0E7490);
}

@supports not (accent-color: var(--primary)) {
  input[type="checkbox"],
  input[type="radio"] {
    appearance: none;
    width: 1.1rem;
    height: 1.1rem;
    border: 2px solid var(--primary);
    background-color: var(--bg-primary);
  }
  input[type="checkbox"]:checked,
  input[type="radio"]:checked {
    background-color: var(--primary-dark, #0E7490);
  }
}

/* Base Canvas & Scrollbars */
html,
body,
[data-testid="stAppViewContainer"],
[data-testid="stSidebarContent"],
.stApp {
  --scrollbar-thumb: var(--secondary);
  --scrollbar-track: var(--bg-primary);
  scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-track);
  scrollbar-width: auto;
  scrollbar-gutter: stable;
}

@supports not (scrollbar-color: auto) {
  ::-webkit-scrollbar {
    width: 12px;
    height: 12px;
  }
  ::-webkit-scrollbar-thumb {
    background: var(--scrollbar-thumb);
  }
  ::-webkit-scrollbar-track {
    background: var(--scrollbar-track);
  }
}

html,
body,
[data-testid="stAppViewContainer"],
.stApp {
  background-color: var(--bg-primary) !important;
  background-image:
    radial-gradient(circle at 18% 22%, rgba(0, 207, 255, 0.09) 0%, transparent 38%),
    radial-gradient(circle at 85% 75%, rgba(23, 13, 55, 0.28) 0%, transparent 44%),
    repeating-linear-gradient(
      -28deg,
      rgba(165, 107, 255, 0.025) 0px,
      rgba(165, 107, 255, 0.025) 18px,
      transparent 18px,
      transparent 44px
    ) !important;
  color: var(--text-primary) !important;
  font-family: var(--font-body);
  overflow-x: hidden !important;
}

.stApp :where(h1, h2, h3, h4, h5, h6, p, label, input, textarea, button, select, li, th, td, caption, small),
.stApp [data-testid="stSelectbox"],
.stApp [data-testid="stMultiSelect"],
.stApp [data-testid="stSelectboxVirtualDropdown"],
.stApp [data-testid="stMultiSelectDropdown"],
.stApp [role="listbox"],
.stApp [role="option"] {
  font-family: var(--font-body) !important;
}

.stApp :where(h1, h2, h3, h4) {
  text-wrap: balance;
}

.stApp p {
  text-wrap: pretty;
  line-height: 1.6;
}

/* Display font exclusivamente para títulos estilizados Persona 5 */
.p5-banner-title,
.p5-hero-title,
.sc-role,
.p5-row,
.p5-row .p5-label-base {
  font-family: var(--font-display) !important;
}

.p5-font {
  font-family: var(--font-body);
  font-weight: 800;
  letter-spacing: 0.04em;
  line-height: 1.25;
}

.stApp [data-testid="stMetricValue"] > div,
.p5-kpi-value,
.p5-kpi-note,
.resume-rank-number,
.sc-stat-num,
.p5-prob-header,
table,
td,
th {
  font-variant-numeric: tabular-nums;
}

::selection {
  background: var(--accent);
  color: var(--bg-primary);
}

.stApp :is(input, textarea, select) {
  caret-color: var(--primary);
}

/* Header opaco y área principal con margen superior seguro */
[data-testid="stHeader"] {
  background: var(--bg-primary) !important;
  border-bottom: 2px solid var(--primary);
}

[data-testid="stMainBlockContainer"] {
  padding: clamp(4.25rem, 5.5vw, 5rem) clamp(1.25rem, 3.5vw, 3.75rem) 5rem;
  max-width: 1560px;
}

.stApp [data-testid="stColumn"],
.stApp [data-testid="stPlotlyChart"] {
  min-width: 0;
  max-width: 100%;
}

.stApp [data-testid="stMetricValue"] > div,
.stApp [data-testid="stMetricLabel"] p {
  white-space: normal;
  overflow-wrap: anywhere;
}

/* Fajas laterales decorativas discretas */
.p5-stripe {
  position: fixed;
  right: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: var(--primary);
  opacity: 0.7;
  z-index: 90;
  pointer-events: none;
}

.p5-stripe2 {
  position: fixed;
  right: 8px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: rgba(245, 247, 255, 0.18);
  z-index: 90;
  pointer-events: none;
}

/* ==========================================================================
   TRANSICIÓN DE PÁGINA (solo opt-in con prefers-reduced-motion: no-preference)
   ========================================================================== */
.p5-transition-layer {
  display: none;
  position: fixed;
  inset: 0;
  z-index: 9999;
  pointer-events: none;
  overflow: hidden;
}

@keyframes p5-stripe-sweep {
  0%   { transform: skewX(-16deg) translateY(-120dvh); opacity: 1; }
  42%  { transform: skewX(-16deg) translateY(0dvh); opacity: 1; }
  58%  { transform: skewX(-16deg) translateY(0dvh); opacity: 1; }
  100% { transform: skewX(-16deg) translateY(120dvh); opacity: 0; }
}

@keyframes p5-about-panel-sweep {
  0%   { transform: rotate(-18deg) translateX(-95dvw); opacity: 1; }
  65%  { transform: rotate(-18deg) translateX(2dvw); opacity: 0.96; }
  100% { transform: rotate(-18deg) translateX(0dvw); opacity: 0; }
}

@keyframes p5-resume-card-sweep {
  0%   { transform: translateX(-100dvw); opacity: 1; }
  48%  { transform: translateX(3dvw); opacity: 1; }
  70%  { transform: translateX(0dvw); opacity: 1; }
  100% { transform: translateX(110dvw); opacity: 0; }
}

@keyframes p5-shadow-pop {
  0%   { transform: translateY(-42%) translateX(-10px) scaleX(0) scaleY(1); }
  55%  { transform: translateY(-48%) translateX(-14px) scaleX(1.18) scaleY(1.16); }
  75%  { transform: translateY(-40%) translateX(-9px) scaleX(0.96) scaleY(0.97); }
  100% { transform: translateY(-42%) translateX(-10px) scaleX(1) scaleY(1); }
}

@keyframes p5-row-mount {
  0%   { opacity: 0; transform: translateX(-24px); }
  100% { opacity: 1; transform: translateX(0); }
}

@keyframes sc-bar-slide-in {
  0%   { transform: translateX(-28px); opacity: 0; }
  100% { transform: translateX(0); opacity: 1; }
}

@keyframes sc-right-nav-pop {
  0%   { opacity: 0; transform: scale(0.92) translateY(-6px); }
  100% { opacity: 1; transform: scale(1) translateY(0); }
}

@keyframes resume-card-mount {
  0%   { opacity: 0; transform: translateX(-24px); }
  100% { opacity: 1; transform: translateX(0); }
}

@media (prefers-reduced-motion: no-preference) {
  .p5-transition-layer {
    display: block;
  }

  .p5-trans-stripe {
    position: fixed;
    top: -6dvh;
    height: 112dvh;
    transform-origin: top;
    pointer-events: none;
    animation: p5-stripe-sweep 0.58s cubic-bezier(0.76, 0, 0.24, 1) forwards;
  }

  .p5-trans-panel {
    position: fixed;
    height: 26dvh;
    clip-path: polygon(0 0, 100% 0, calc(100% - 120px) 100%, 0 100%);
    transform-origin: left center;
    pointer-events: none;
    animation: p5-about-panel-sweep 0.54s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  }

  .p5-trans-card {
    position: fixed;
    left: -6dvw;
    width: 78dvw;
    height: 14dvh;
    clip-path: polygon(0 0, 97% 0, 100% 100%, 3% 100%);
    pointer-events: none;
    animation: p5-resume-card-sweep 0.6s cubic-bezier(0.76, 0, 0.24, 1) forwards;
  }
}

/* ==========================================================================
   SIDEBAR & MENÚ PRINCIPAL PERSONA 5 (navegación única sin stSidebarNav)
   ========================================================================== */
[data-testid="stSidebar"] {
  background:
    radial-gradient(circle at 50% 24%, rgba(0, 207, 255, 0.28) 0%, transparent 55%),
    repeating-linear-gradient(-35deg, var(--bg-primary) 0px, var(--bg-primary) 14px, var(--bg-chart-deep) 14px, var(--bg-chart-deep) 28px) !important;
  border-right: 4px solid var(--primary) !important;
  box-shadow: 8px 0px 0px var(--bg-primary) !important;
}

[data-testid="stSidebarContent"] {
  padding-top: 0.75rem !important;
}

.p5-menu-stage {
  position: relative;
  width: 100%;
  min-height: 340px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  background:
    radial-gradient(circle at 75% 42%, rgba(0, 207, 255, 0.38) 0%, rgba(23, 13, 55, 0.28) 45%, rgba(5, 13, 34, 0.96) 80%),
    repeating-linear-gradient(-35deg, var(--bg-primary) 0px, var(--bg-primary) 16px, var(--bg-chart-deep) 16px, var(--bg-chart-deep) 32px);
  border: 3px solid var(--primary);
  box-shadow: 6px 6px 0px var(--bg-primary);
  padding: 5.25rem 0.75rem 2.35rem 0.75rem;
  margin-bottom: 1rem;
  user-select: none;
}

.p5-menu-stage[data-compact="true"] {
  min-height: 315px;
}

.p5-stage-art {
  position: absolute;
  inset: 0;
  height: 100%;
  width: 100%;
  object-fit: cover !important;
  object-position: center;
  pointer-events: none;
  z-index: 2;
  opacity: 0.39;
}

.p5-name-tag {
  position: absolute;
  top: 1rem;
  left: 1rem;
  z-index: 25;
  pointer-events: none;
  font-family: var(--font-body);
  font-weight: 900;
  font-style: italic;
  font-size: 1.35rem;
  line-height: 1.05;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-primary);
  transform: rotate(-4deg);
  transform-origin: left top;
  display: flex;
  flex-direction: column;
  gap: 2px;
  text-shadow: 3px 3px 0 var(--bg-primary), -1px -1px 0 var(--accent);
}

.p5-name-tag span:nth-child(2) {
  margin-left: 14px;
}

.p5-menu {
  position: relative;
  z-index: 20;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 0.65rem;
  width: 100%;
  padding: 0.5rem 0.75rem;
}

.p5-row {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 44px;
  text-decoration: none !important;
  cursor: pointer;
  overflow: visible;
}

@media (prefers-reduced-motion: no-preference) {
  .p5-row {
    animation: p5-row-mount 0.42s cubic-bezier(0.22, 1, 0.36, 1) both;
  }
}

.p5-glow {
  position: absolute;
  inset: -10px -20px;
  background: radial-gradient(ellipse at 50% 50%, rgba(245, 247, 255, 0.4) 0%, transparent 70%);
  opacity: 0;
  transition: opacity 0.2s ease;
  pointer-events: none;
  z-index: 0;
}

.p5-row.active .p5-glow,
.p5-row[aria-current="page"] .p5-glow,
.p5-row:hover .p5-glow {
  opacity: 1;
}

.p5-skew-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  overflow: visible;
  isolation: isolate;
}

.p5-shadow-tri {
  position: absolute;
  top: 50%;
  left: -4%;
  width: 108%;
  height: 112%;
  transform-origin: left center;
  background: rgba(245, 247, 255, 0.92);
  clip-path: polygon(0% 44%, 24% 6%, 82% 0%, 100% 36%, 82% 100%, 18% 94%);
  z-index: 1;
  pointer-events: none;
  transform: translateY(-42%) translateX(-10px) scaleX(0);
}

.p5-row.active .p5-shadow-tri,
.p5-row[aria-current="page"] .p5-shadow-tri,
.p5-row:hover .p5-shadow-tri {
  transform: translateY(-42%) translateX(-10px) scaleX(1);
}

.p5-highlight {
  position: absolute;
  top: 50%;
  left: -4%;
  width: 108%;
  height: 112%;
  transform-origin: left center;
  background: var(--secondary);
  clip-path: polygon(0% 44%, 24% 6%, 82% 0%, 100% 36%, 82% 100%, 18% 94%);
  z-index: 2;
  pointer-events: none;
  transform: translateY(-50%) scaleX(0);
}

.p5-row.active .p5-highlight,
.p5-row[aria-current="page"] .p5-highlight,
.p5-row:hover .p5-highlight {
  transform: translateY(-50%) scaleX(1);
}

@media (prefers-reduced-motion: no-preference) {
  .p5-shadow-tri {
    transition: transform 0.16s ease;
  }
  .p5-row.active .p5-shadow-tri,
  .p5-row[aria-current="page"] .p5-shadow-tri,
  .p5-row:hover .p5-shadow-tri {
    animation: p5-shadow-pop 0.28s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
  }
  .p5-highlight {
    transition: transform 0.2s cubic-bezier(0.22, 1, 0.36, 1);
  }
}

.p5-label-wrap {
  position: relative;
  z-index: 3;
  display: inline-grid;
  place-items: center;
  padding: 0.25rem 0.65rem;
}

.p5-label-base {
  grid-area: 1 / 1;
  font-style: italic;
  line-height: 0.92;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  white-space: nowrap;
  display: block;
  pointer-events: none;
}

.p5-label-dark {
  color: var(--text-primary);
  -webkit-text-stroke: 8px rgba(5, 13, 34, 0.94);
  paint-order: stroke fill;
  opacity: 1;
  transition: opacity 0.1s ease;
}

.p5-label-bright {
  color: var(--bg-primary);
  -webkit-text-stroke: 8px rgba(255, 255, 255, 0.96);
  paint-order: stroke fill;
  opacity: 0;
  transition: opacity 0.1s ease;
}

.p5-row.active .p5-label-dark,
.p5-row[aria-current="page"] .p5-label-dark,
.p5-row:hover .p5-label-dark {
  opacity: 0;
}

.p5-row.active .p5-label-bright,
.p5-row[aria-current="page"] .p5-label-bright,
.p5-row:hover .p5-label-bright {
  opacity: 1;
}

.p5-hint {
  position: absolute;
  bottom: 0.5rem;
  right: 0.65rem;
  z-index: 20;
  display: flex;
  gap: 0.45rem;
  align-items: center;
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  color: var(--text-secondary);
}

.p5-hint-key {
  border: 1px solid rgba(200, 205, 235, 0.55);
  padding: 1px 5px;
  font-size: 0.68rem;
  color: var(--text-primary);
}

/* Audio unificado en barra lateral */
.p5-audio-section {
  border-top: 2px solid var(--primary);
  padding-top: 0.65rem;
  margin-top: 0.25rem;
  margin-bottom: 0.45rem;
}

.p5-audio-heading {
  font-family: var(--font-body) !important;
  font-size: 0.95rem !important;
  font-weight: 800;
  color: var(--accent) !important;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  text-shadow: none !important;
  margin: 0 !important;
}

.p5-bgm-note {
  font-size: 0.82rem;
  color: var(--text-secondary);
  margin: 0.25rem 0 0.45rem 0;
}

[data-testid="stSidebar"] [data-testid="stAudio"] {
  margin-top: 0.15rem;
}

/* ==========================================================================
   HERO STAGE (INICIO)
   ========================================================================== */
.p5-hero {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1.5rem;
  background:
    radial-gradient(circle at 78% 45%, rgba(0, 207, 255, 0.34) 0%, rgba(23, 13, 55, 0.28) 42%, rgba(5, 13, 34, 0.97) 78%),
    repeating-linear-gradient(-32deg, var(--bg-primary) 0px, var(--bg-primary) 16px, var(--bg-chart-deep) 16px, var(--bg-chart-deep) 32px);
  border: 3px solid var(--primary);
  border-left: 9px solid var(--primary);
  box-shadow: 8px 8px 0px var(--bg-primary), -2px -2px 0px var(--text-primary);
  padding: 1.5rem 1.85rem;
  margin-bottom: 1.5rem;
  overflow: hidden;
}

.p5-hero::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  width: 64px;
  height: 100%;
  background: linear-gradient(135deg, transparent 49%, rgba(0, 207, 255, 0.22) 50%);
  pointer-events: none;
}

.p5-hero-badge {
  display: inline-block;
  background: var(--accent);
  color: var(--bg-primary);
  font-family: var(--font-body);
  font-weight: 900;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  padding: 0.22rem 0.85rem;
  box-shadow: 4px 4px 0px var(--bg-primary);
  margin-bottom: 0.6rem;
  font-size: 0.9rem;
}

.p5-hero-title {
  font-size: clamp(1.85rem, 3.3vw, 2.95rem);
  line-height: 1.05;
  color: var(--text-primary);
  text-shadow: 4px 4px 0px var(--bg-primary), -2px -2px 0px var(--primary);
  margin: 0.2rem 0 0.7rem 0;
}

.p5-hero-sub,
.p5-hero-lead {
  font-family: var(--font-body);
  font-size: 1rem;
  line-height: 1.6;
  color: var(--text-primary);
  max-width: 72ch;
  margin: 0;
}

.p5-hero-img {
  width: 43%;
  min-width: 0;
  aspect-ratio: 16 / 9;
  object-fit: cover !important;
  border: 1px solid var(--primary);
}

/* ==========================================================================
   TARJETAS INFORMATIVAS / VECINOS (.sc-bar)
   ========================================================================== */
.sc-root {
  container-type: inline-size;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 0.65rem;
  margin: 1rem 0 1.6rem 0;
  padding: 0.5rem 0 1rem;
  width: 100%;
}

.sc-bar-outer {
  position: relative;
  width: 100%;
  max-width: 100%;
  box-sizing: border-box;
}

@media (prefers-reduced-motion: no-preference) {
  .sc-bar-outer {
    animation: sc-bar-slide-in 0.45s cubic-bezier(0.22, 1, 0.36, 1) both;
  }
}

.sc-bar-outer:nth-child(2) { animation-delay: 75ms; }
.sc-bar-outer:nth-child(3) { animation-delay: 150ms; }
.sc-bar-outer:nth-child(4) { animation-delay: 225ms; }
.sc-bar-outer:nth-child(5) { animation-delay: 300ms; }

.sc-bar {
  position: relative;
  width: 100%;
  min-height: 76px;
  background: var(--bg-chart-deep);
  border: 1px solid rgba(200, 205, 235, 0.25);
  border-left: 6px solid var(--primary);
  box-shadow: 0 6px 22px rgba(5, 13, 34, 0.72);
  z-index: 1;
  overflow: hidden;
  transition: border-color 0.2s ease, background 0.2s ease;
}

.sc-bar-red {
  position: absolute;
  inset: 0;
  background: var(--primary);
  clip-path: polygon(48% 0, 100% 0, 100% 100%, calc(48% - 14px) 100%);
  opacity: 0;
  transition: opacity 0.2s ease;
  z-index: 0;
  pointer-events: none;
}

.sc-bar-outer.active .sc-bar-red,
.sc-bar-outer:hover .sc-bar-red {
  opacity: 1;
}

.sc-bar-fill {
  position: absolute;
  inset: 0;
  width: 100%;
  background: var(--text-primary);
  clip-path: polygon(100% 0, 100% 0, calc(100% - 32px) 100%, calc(100% - 32px) 100%);
  z-index: 0;
}

@media (prefers-reduced-motion: no-preference) {
  .sc-bar-fill {
    transition: clip-path 0.32s cubic-bezier(0.22, 1, 0.36, 1);
  }
}

.sc-bar-outer.active .sc-bar-fill,
.sc-bar-outer:hover .sc-bar-fill {
  clip-path: polygon(18% 0, 100% 0, calc(100% - 14px) 100%, calc(18% + 110px) 100%);
}

.sc-bar-shade {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 72%;
  width: 6%;
  background: linear-gradient(90deg, rgba(5, 13, 34, 0.16) 0%, rgba(5, 13, 34, 0) 100%);
  z-index: 1;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.25s ease;
}

.sc-bar-outer.active .sc-bar-shade,
.sc-bar-outer:hover .sc-bar-shade {
  opacity: 1;
}

.sc-root .sc-bar .sc-char {
  flex: 0 0 clamp(120px, 21cqw, 210px);
  width: clamp(120px, 21cqw, 210px);
  aspect-ratio: 16 / 10;
  object-fit: cover !important;
  object-position: center;
  border: 1px solid var(--primary);
}

.sc-vecino-arte {
  flex: 0 0 auto;
  width: clamp(112px, 19cqw, 190px);
  margin: 0;
}

.sc-vecino-arte img {
  display: block;
  width: 100%;
  aspect-ratio: 16 / 9;
  object-fit: cover !important;
  border: 1px solid var(--primary);
}

.sc-vecino-organizacion {
  display: grid;
  gap: 0.3rem;
  padding: 0.75rem;
  border: 1px solid var(--primary);
  background: var(--bg-primary);
  color: var(--text-primary);
  overflow-wrap: anywhere;
}

.sc-bar-content {
  position: relative;
  z-index: 4;
  min-height: inherit;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.35rem 1rem 1.15rem;
  gap: 1rem;
}

.sc-role {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  font-size: 2.25rem;
  letter-spacing: -0.02em;
  color: var(--text-primary);
  transform: rotate(-18deg);
  user-select: none;
  line-height: 1;
  padding: 0 0.75rem 0 0.25rem;
  text-shadow: 2px 2px 0 var(--bg-primary);
}

.sc-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 0.25rem;
  padding: 0.5rem 0.75rem;
  background: var(--bg-chart-deep);
}

.sc-bar-outer.active .sc-main,
.sc-bar-outer:hover .sc-main,
.sc-bar-outer.active .sc-stats,
.sc-bar-outer:hover .sc-stats {
  background: var(--text-primary);
}

.sc-label {
  font-family: var(--font-body);
  font-size: 1.25rem !important;
  font-weight: 800;
  letter-spacing: 0.03em !important;
  line-height: 1.25 !important;
  color: var(--accent) !important;
  margin-bottom: 0.15rem !important;
  white-space: normal !important;
}

.sc-subdesc {
  font-family: var(--font-body);
  font-size: 0.94rem !important;
  line-height: 1.5 !important;
  color: var(--text-primary) !important;
}

.sc-bar-outer.active .sc-label,
.sc-bar-outer:hover .sc-label,
.sc-bar-outer.active .sc-subdesc,
.sc-bar-outer:hover .sc-subdesc {
  color: var(--bg-primary) !important;
}

.sc-stats {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.4rem 0.75rem;
  flex-shrink: 0;
  background: var(--bg-chart-deep);
}

@container (max-width: 760px) {
  .sc-bar-content {
    flex-wrap: wrap;
    align-items: flex-start;
  }
  .sc-main {
    flex-basis: 100%;
    margin-left: 0;
    padding-left: 0.75rem;
  }
  .sc-stats {
    flex-wrap: wrap;
    max-width: 100%;
  }
  .sc-root .sc-bar .sc-char {
    flex: 0 0 auto;
    width: min(100%, 300px);
  }
  .sc-vecino-arte {
    width: min(100%, 235px);
  }
}

.sc-stat {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.sc-stat-top {
  display: flex;
  align-items: baseline;
  gap: 0.35rem;
}

.sc-stat-tag {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  padding: 1px 6px;
  border: 1px solid var(--primary);
  color: var(--primary);
  line-height: 1.3;
  background: var(--bg-primary);
}

.sc-stat-num {
  font-family: var(--font-body);
  font-size: 1.45rem;
  font-weight: 800;
  line-height: 1.1;
  color: var(--text-primary);
}

.sc-bar-outer.active .sc-stat-num,
.sc-bar-outer:hover .sc-stat-num {
  color: var(--bg-primary);
}

.sc-stat-bars {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 1px;
  margin-top: 2px;
}

.sc-stat-bar-color {
  height: 3px;
  width: 100%;
  background: var(--primary);
}

.sc-stat-bar-black {
  height: 2px;
  width: 100%;
  background: var(--bg-primary);
}

/* ==========================================================================
   CABECERA LB / RB DE SECCIÓN
   ========================================================================== */
.sc-right-nav-bar {
  display: inline-flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.6rem;
  max-width: 100%;
  padding: 0.5rem 1.1rem;
  background: var(--bg-primary);
  border: 2px solid var(--text-primary);
  box-shadow: 6px 5px 0 var(--primary);
  margin: 0.4rem 0 1.1rem 0;
}

@media (prefers-reduced-motion: no-preference) {
  .sc-right-nav-bar {
    animation: sc-right-nav-pop 0.35s cubic-bezier(0.22, 1, 0.36, 1) both;
  }
}

.sc-right-nav-bar .sc-nav-btn {
  font-family: var(--font-body);
  font-size: 0.95rem;
  font-weight: 900;
  letter-spacing: 0.08em;
  line-height: 1.1;
  color: var(--bg-primary);
  background: var(--primary);
  padding: 0.25rem 0.55rem;
}

.sc-right-nav-bar .sc-nav-label {
  font-family: var(--font-body);
  font-size: clamp(0.95rem, 1.5vw, 1.3rem);
  font-weight: 800;
  letter-spacing: 0.08em;
  line-height: 1.25;
  color: var(--text-primary);
  min-width: 0;
  overflow-wrap: anywhere;
}

.sc-right-nav-bar .sc-nav-arrow {
  font-size: 1.05rem;
  color: var(--accent);
  display: inline-block;
}

/* ==========================================================================
   KPI CONFIDANT CARDS & TAB PANEL (.resume-grid)
   ========================================================================== */
.resume-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 1.75rem;
  align-items: start;
  margin: 1rem 0 1.8rem 0;
  padding: 0.25rem 0 1.25rem;
}

.resume-grid > *,
.sp-shell > * {
  min-width: 0;
}

.resume-stack {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.resume-list-tag {
  font-family: var(--font-body);
  font-weight: 900;
  font-style: italic;
  font-size: clamp(1.85rem, 3vw, 2.75rem);
  line-height: 1.05;
  color: var(--text-primary);
  letter-spacing: 0.05em;
  margin: 0 0 0.25rem 0.25rem;
  text-shadow: 3px 3px 0 var(--bg-primary), -1px -1px 0 var(--primary);
}

.resume-card-wrap {
  position: relative;
  cursor: pointer;
}

@media (prefers-reduced-motion: no-preference) {
  .resume-card-wrap {
    animation: resume-card-mount 0.38s cubic-bezier(0.22, 1, 0.36, 1) both;
  }
}

.resume-card-wrap:nth-child(2) { animation-delay: 50ms; }
.resume-card-wrap:nth-child(3) { animation-delay: 100ms; }
.resume-card-wrap:nth-child(4) { animation-delay: 150ms; }
.resume-card-wrap:nth-child(5) { animation-delay: 200ms; }

.resume-card {
  position: relative;
  min-height: 108px;
  height: auto;
  background: var(--bg-primary);
  border: 1px solid rgba(200, 205, 235, 0.25);
  border-inline-start: 6px solid transparent;
  padding: 0.85rem 1.25rem 0.85rem 4.65rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 0.55rem;
  box-shadow: 0 6px 0 rgba(5, 13, 34, 0.85);
  transition: background 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
}

@media (prefers-reduced-motion: no-preference) {
  .resume-card {
    transition: transform 0.2s ease, background 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
  }
}

.resume-card-wrap.active .resume-card,
.resume-card-wrap[aria-selected="true"] .resume-card,
.resume-card-wrap:hover .resume-card {
  background: var(--text-primary);
  border-color: var(--primary-dark, #0E7490);
  border-inline-start: 6px solid var(--primary-dark, #0E7490);
  box-shadow: 8px 6px 0 var(--primary);
}

@media (prefers-reduced-motion: no-preference) {
  .resume-card-wrap.active .resume-card,
  .resume-card-wrap[aria-selected="true"] .resume-card,
  .resume-card-wrap:hover .resume-card {
    transform: translateX(6px);
  }
}

.resume-badge {
  position: absolute;
  top: 0.75rem;
  left: 0.65rem;
  width: 3rem;
  height: 3.75rem;
  background: var(--bg-primary);
  border: 2px solid var(--text-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3;
}

.resume-card-wrap.active .resume-badge,
.resume-card-wrap[aria-selected="true"] .resume-badge,
.resume-card-wrap:hover .resume-badge {
  background: var(--bg-primary);
  border-color: var(--primary-dark, #0E7490);
}

.resume-badge-text {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: 1.35rem;
  color: var(--text-primary);
  letter-spacing: 0.04em;
}

.resume-card-inner {
  position: relative;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.resume-title {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.3rem, 2.2vw, 1.85rem);
  line-height: 1.1;
  letter-spacing: 0.03em;
  color: var(--text-primary);
  min-width: 0;
  overflow-wrap: anywhere;
}

.resume-card-wrap.active .resume-title,
.resume-card-wrap[aria-selected="true"] .resume-title,
.resume-card-wrap:hover .resume-title {
  color: var(--bg-primary);
}

.resume-rank {
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
  flex-shrink: 0;
}

.resume-rank-label {
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 0.9rem;
  letter-spacing: 0.1em;
  color: var(--primary);
}

.resume-card-wrap.active .resume-rank-label,
.resume-card-wrap[aria-selected="true"] .resume-rank-label,
.resume-card-wrap:hover .resume-rank-label {
  color: var(--primary-dark, #0E7490);
}

.resume-rank-number {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.35rem, 2.2vw, 1.9rem);
  line-height: 1.05;
  color: var(--text-primary);
}

.resume-card-wrap.active .resume-rank-number,
.resume-card-wrap[aria-selected="true"] .resume-rank-number,
.resume-card-wrap:hover .resume-rank-number {
  color: var(--bg-primary);
}

.resume-subtitle-bar {
  position: relative;
  width: 100%;
  min-height: 32px;
  height: auto;
  background: var(--text-primary);
  display: flex;
  align-items: center;
  padding: 0.35rem 0.75rem;
}

.resume-card-wrap.active .resume-subtitle-bar,
.resume-card-wrap[aria-selected="true"] .resume-subtitle-bar,
.resume-card-wrap:hover .resume-subtitle-bar {
  background: var(--bg-primary);
}

.resume-subtitle {
  font-family: var(--font-body);
  font-weight: 600;
  font-size: 0.9rem;
  line-height: 1.35;
  color: var(--bg-primary);
  white-space: normal;
}

.resume-card-wrap.active .resume-subtitle,
.resume-card-wrap[aria-selected="true"] .resume-subtitle,
.resume-card-wrap:hover .resume-subtitle {
  color: var(--text-primary);
}

.resume-detail-panel {
  position: relative;
  padding: clamp(1.2rem, 2.2vw, 1.75rem);
  background: linear-gradient(180deg, rgba(23, 13, 55, 0.96) 0%, rgba(16, 11, 41, 0.98) 100%);
  border: 1px solid rgba(200, 205, 235, 0.25);
  box-shadow: 10px 10px 0 rgba(0, 207, 255, 0.72);
  overflow: hidden;
}

.resume-detail-top {
  position: relative;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 0.85rem;
  min-height: 70px;
  padding: 0.85rem 1.1rem;
  background: var(--text-primary);
  color: var(--bg-primary);
  box-shadow: 6px 0 0 rgba(0, 207, 255, 0.88);
}

.resume-detail-top-index {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: 1.65rem;
  line-height: 1;
  color: var(--bg-primary);
}

.resume-detail-top-title {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.15rem, 1.8vw, 1.55rem);
  line-height: 1.15;
  color: var(--bg-primary);
}

.resume-detail-top-progress {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.15rem, 1.7vw, 1.5rem);
  line-height: 1;
  color: var(--primary-dark, #0E7490);
}

.resume-detail-list {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 0.55rem;
  margin-top: 1rem;
}

.resume-detail-row {
  display: grid;
  grid-template-columns: 1.75rem minmax(0, 1fr);
  align-items: center;
  gap: 0.65rem 0.75rem;
  min-height: 48px;
  padding: 0.8rem 1rem;
  background: rgba(5, 13, 34, 0.96);
  border: 1px solid rgba(200, 205, 235, 0.16);
  transition: background 0.16s ease;
}

.resume-detail-row:hover {
  background: rgba(0, 207, 255, 0.14);
}

.resume-detail-row-index {
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 1.05rem;
  color: var(--primary);
}

.resume-detail-row-title {
  font-family: var(--font-body);
  font-weight: 700;
  font-size: 1rem;
  line-height: 1.45;
  color: var(--text-primary);
}

.resume-detail-status {
  grid-column: 2;
  justify-self: start;
  max-width: 100%;
  overflow-wrap: anywhere;
  font-family: var(--font-body);
  font-weight: 700;
  font-size: 0.9rem;
  line-height: 1.35;
  color: var(--bg-primary);
  background: var(--text-primary);
  padding: 0.35rem 0.7rem;
}

/* ==========================================================================
   ALGORITHM LOG / TABLIST DE MODELOS (.sp-shell)
   ========================================================================== */
.sp-shell {
  display: grid;
  grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
  gap: 1.75rem;
  margin: 1rem 0 1.6rem 0;
  padding: 0.25rem 0 1.25rem;
}

.sp-left {
  display: flex;
  flex-direction: column;
  gap: 0.65rem;
}

.sp-title {
  font-family: var(--font-body);
  font-weight: 900;
  font-style: italic;
  font-size: clamp(1.85rem, 3vw, 2.75rem);
  color: var(--text-primary);
  line-height: 1.05;
  letter-spacing: 0.04em;
  text-shadow: 3px 3px 0 var(--bg-primary), -1px -1px 0 var(--primary);
  margin-bottom: 0.25rem;
}

.sp-item {
  position: relative;
  display: grid;
  grid-template-columns: clamp(3.5rem, 7vw, 6.5rem) minmax(0, 1fr);
  align-items: center;
  gap: 0.75rem;
  min-height: 76px;
  background: rgba(5, 13, 34, 0.96);
  border: 1px solid rgba(200, 205, 235, 0.22);
  border-inline-start: 6px solid transparent;
  box-shadow: 0 6px 14px rgba(5, 13, 34, 0.45);
  padding: 1rem 1.25rem;
  cursor: pointer;
  transition: background 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
}

.sp-item-art {
  display: block;
  width: 100%;
  aspect-ratio: 4 / 3;
  object-fit: cover !important;
  border: 1px solid var(--primary);
}

@media (prefers-reduced-motion: no-preference) {
  .sp-item {
    transition: transform 0.2s ease, background 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
  }
}

.sp-item.active,
.sp-item[aria-selected="true"],
.sp-item:hover {
  background: var(--text-primary);
  border-color: var(--primary-dark, #0E7490);
  border-inline-start: 6px solid var(--primary-dark, #0E7490);
  box-shadow: 7px 7px 0 var(--primary);
}

@media (prefers-reduced-motion: no-preference) {
  .sp-item.active,
  .sp-item[aria-selected="true"],
  .sp-item:hover {
    transform: translateX(6px);
  }
}

.sp-item-title {
  font-family: var(--font-body);
  font-weight: 800;
  font-size: clamp(1.1rem, 1.6vw, 1.45rem);
  line-height: 1.2;
  color: var(--text-primary);
  overflow-wrap: anywhere;
}

.sp-item.active .sp-item-title,
.sp-item[aria-selected="true"] .sp-item-title,
.sp-item:hover .sp-item-title {
  color: var(--bg-primary);
}

.sp-item-stack {
  font-family: var(--font-body);
  font-weight: 600;
  font-size: 0.92rem;
  line-height: 1.5;
  color: var(--secondary);
  margin-top: 0.25rem;
}

.sp-item.active .sp-item-stack,
.sp-item[aria-selected="true"] .sp-item-stack,
.sp-item:hover .sp-item-stack {
  color: var(--bg-primary);
}

.sp-right {
  position: relative;
  background: linear-gradient(180deg, rgba(5, 13, 34, 0.97) 0%, rgba(16, 11, 41, 0.98) 100%);
  border: 1px solid rgba(200, 205, 235, 0.22);
  box-shadow: 10px 10px 0 var(--primary);
  padding: clamp(1.2rem, 2.2vw, 1.85rem);
  overflow: hidden;
}

.sp-tag {
  display: inline-block;
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 0.85rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  background: var(--text-primary);
  color: var(--bg-primary);
  padding: 0.25rem 0.75rem;
}

.sp-right-title {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.5rem, 2.6vw, 2.15rem);
  line-height: 1.15;
  color: var(--text-primary);
  margin-top: 0.85rem;
  overflow-wrap: anywhere;
}

.sp-right-summary {
  margin-top: 0.85rem;
  font-family: var(--font-body);
  font-size: 1rem;
  line-height: 1.6;
  color: var(--text-primary);
}

.sp-link {
  display: block;
  margin-top: 1.1rem;
  font-family: var(--font-body);
  font-weight: 700;
  font-size: 0.9rem;
  line-height: 1.5;
  color: var(--bg-primary);
  background: var(--primary);
  padding: 0.85rem 1rem;
  overflow-wrap: anywhere;
}

/* ==========================================================================
   ENCABEZADOS, BANNERS, TARJETAS Y KPIs
   ========================================================================== */
h1,
h2,
h3 {
  font-family: var(--font-body);
  letter-spacing: 0.02em;
  color: var(--text-primary) !important;
  text-shadow: 2px 2px 0px var(--bg-primary);
}

.p5-banner {
  position: relative;
  display: block;
  width: 100%;
  box-sizing: border-box;
  background: linear-gradient(110deg, var(--bg-panel) 0%, var(--purple-banner, #3B2386) 68%, var(--bg-chart) 100%);
  color: var(--text-primary);
  padding: 0.95rem 1.5rem;
  margin: 1.75rem 0 1.2rem 0;
  border: 2px solid var(--border-purple);
  border-left: 8px solid var(--primary);
  box-shadow: 6px 6px 0px var(--bg-primary);
}

.p5-banner::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(125deg, transparent 86%, rgba(0, 207, 255, 0.24) 86%);
  pointer-events: none;
}

.p5-banner-title {
  position: relative;
  z-index: 1;
  font-size: clamp(1.35rem, 2.2vw, 1.95rem);
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--text-primary) !important;
  text-shadow: 3px 3px 0px var(--bg-primary);
  margin: 0;
}

.p5-banner-sub {
  position: relative;
  z-index: 1;
  font-family: var(--font-body);
  font-weight: 700;
  font-size: 0.96rem;
  letter-spacing: 0.06em;
  color: var(--accent);
  text-transform: uppercase;
  margin: 0.3rem 0 0 0;
}

.p5-card {
  width: 100%;
  box-sizing: border-box;
  background: var(--bg-panel);
  border: 2px solid var(--primary);
  box-shadow: 6px 6px 0px var(--bg-primary);
  padding: 1.25rem 1.4rem;
  margin-bottom: 1.15rem;
  position: relative;
}

.p5-card-accent {
  width: 100%;
  box-sizing: border-box;
  background: linear-gradient(145deg, var(--bg-chart) 0%, var(--bg-chart-deep) 100%);
  border: 2px solid var(--text-primary);
  border-left: 7px solid var(--primary);
  box-shadow: 6px 6px 0px var(--primary);
  padding: 1.2rem 1.4rem;
  margin-bottom: 1.15rem;
}

.p5-callout-warning {
  width: 100%;
  box-sizing: border-box;
  background: linear-gradient(135deg, var(--bg-chart-deep) 0%, var(--bg-chart) 100%);
  border: 2px solid var(--primary);
  border-left: 9px solid var(--accent);
  box-shadow: 8px 8px 0px var(--bg-primary);
  padding: 1.2rem 1.45rem;
  margin: 1.2rem 0;
}

.p5-callout-title {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: 1.25rem;
  color: var(--accent);
  letter-spacing: 0.05em;
  text-transform: uppercase;
  margin-bottom: 0.45rem;
}

/* Grid de 4 KPIs (sin cortar palabras largas como RandomForestClassifier) */
.p5-kpi-grid {
  display: grid !important;
  grid-template-columns: repeat(auto-fit, minmax(235px, 1fr)) !important;
  gap: 1rem !important;
}

.p5-kpi-card {
  position: relative;
  background: linear-gradient(155deg, var(--bg-primary) 0%, var(--bg-chart-deep) 100%);
  border: 2px solid var(--primary);
  border-top: 4px solid var(--accent);
  box-shadow: 6px 6px 0px var(--bg-primary);
  padding: 1rem 1.15rem !important;
  overflow-wrap: break-word !important;
  transition: border-color 0.18s ease, box-shadow 0.18s ease;
}

.p5-kpi-card:hover {
  border-color: var(--text-primary);
  box-shadow: 8px 8px 0px var(--primary);
}

@media (prefers-reduced-motion: no-preference) {
  .p5-kpi-card {
    transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
  }
  .p5-kpi-card:hover {
    transform: translateY(-3px);
  }
}

.p5-kpi-label {
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 0.9rem;
  letter-spacing: 0.08em;
  color: var(--accent);
  text-transform: uppercase;
  margin-bottom: 0.35rem;
}

.p5-kpi-value {
  font-family: var(--font-body);
  font-weight: 900;
  font-size: clamp(1.05rem, 1.35vw, 1.35rem) !important;
  line-height: 1.2 !important;
  word-break: normal !important;
  overflow-wrap: break-word !important;
  hyphens: none !important;
  color: var(--text-primary);
}

.p5-kpi-note {
  font-family: var(--font-body);
  font-size: 0.86rem;
  color: var(--text-secondary);
  line-height: 1.5;
  margin-top: 0.35rem;
}

/* ==========================================================================
   BOTONES, FORMULARIOS, SELECTORES STREAMLIT 1.67.0 Y PESTAÑAS
   ========================================================================== */
.stButton > button,
.stDownloadButton > button,
[data-testid="stFormSubmitButton"] > button {
  min-height: 44px;
  background-color: var(--bg-primary) !important;
  color: var(--text-primary) !important;
  border: 2px solid var(--primary) !important;
  box-shadow: 5px 5px 0px var(--primary) !important;
  font-family: var(--font-body) !important;
  font-size: 1rem !important;
  font-weight: 800 !important;
  letter-spacing: 0.06em !important;
  text-transform: uppercase !important;
  padding: 0.6rem 1.35rem !important;
  border-radius: 2px !important;
  transition: background-color 0.16s ease, color 0.16s ease, box-shadow 0.16s ease !important;
  cursor: pointer !important;
}

.stButton > button:hover,
.stDownloadButton > button:hover,
[data-testid="stFormSubmitButton"] > button:hover {
  background-color: var(--text-primary) !important;
  color: var(--bg-primary) !important;
  border-color: var(--primary-dark, #0E7490) !important;
  box-shadow: 7px 7px 0px var(--primary) !important;
}

@media (prefers-reduced-motion: no-preference) {
  .stButton > button,
  .stDownloadButton > button,
  [data-testid="stFormSubmitButton"] > button {
    transition: transform 0.16s ease, background-color 0.16s ease, color 0.16s ease, box-shadow 0.16s ease !important;
  }
  .stButton > button:hover,
  .stDownloadButton > button:hover,
  [data-testid="stFormSubmitButton"] > button:hover {
    transform: translate(-1px, -2px);
  }
}

.stButton > button:hover *,
.stDownloadButton > button:hover *,
[data-testid="stFormSubmitButton"] > button:hover * {
  color: var(--bg-primary) !important;
}

[data-testid="stForm"] {
  background: linear-gradient(155deg, var(--bg-primary) 0%, var(--bg-chart-deep) 100%) !important;
  border: 3px solid var(--primary) !important;
  box-shadow: 8px 8px 0px var(--bg-primary) !important;
  border-radius: 2px !important;
  padding: 1.5rem !important;
}

/* Selectores reales de Streamlit 1.67.0 (reemplazan [data-baseweb=*]) */
[data-testid="stSelectboxVirtualDropdown"],
[data-testid="stMultiSelectDropdown"],
[data-testid="stPopoverBody"] {
  background: var(--bg-panel) !important;
  color: var(--text-primary) !important;
  border: 1px solid var(--border-primary) !important;
}

[data-testid="stSelectboxVirtualDropdown"] [role="option"],
[data-testid="stMultiSelectDropdown"] [role="option"] {
  color: var(--text-primary);
}

[data-testid="stSelectboxVirtualDropdown"] [role="option"][aria-selected="true"],
[data-testid="stMultiSelectDropdown"] [role="option"][aria-selected="true"] {
  background: rgba(0, 207, 255, 0.16);
  border-left: 3px solid var(--primary);
}

[data-testid="stMultiSelectTagsContainer"] {
  gap: 0.35rem;
}

/* Mantener cifras de deslizadores en una sola línea */
.stApp [data-testid="stSlider"] [data-testid="stMarkdownContainer"] p {
  white-space: nowrap;
  word-break: normal;
  overflow-wrap: normal;
}

.stApp [data-testid="stSlider"] label [data-testid="stMarkdownContainer"] p {
  white-space: normal;
}

/* Tabs nativos de Streamlit accesibles */
[data-testid="stTabs"] [role="tablist"] {
  gap: 0.4rem;
  flex-wrap: wrap;
  height: auto;
  padding: 0.25rem 0;
}

[data-testid="stTabs"] [role="tab"] {
  position: relative;
  min-height: 44px;
  padding: 0.6rem 1.1rem;
  white-space: normal;
  color: var(--text-secondary);
  font-weight: 600;
}

[data-testid="stTabs"] [role="tab"][aria-selected="true"] {
  color: var(--text-primary);
  background: rgba(21, 37, 74, 0.72);
}

[data-testid="stTabs"] [role="tab"][aria-selected="true"]::after {
  content: "";
  position: absolute;
  inset: auto 0 0;
  border-bottom: 3px solid var(--primary);
}

[data-testid="stTabs"] [role="tabpanel"] {
  padding-top: 1.25rem;
}

/* Indicadores de foco claros y nunca recortados por clip-path */
.stApp :is(button, input, textarea, select, a, summary, [role="tab"]):focus-visible,
.resume-card-wrap:focus-visible,
.sp-item:focus-visible,
.p5-row:focus-visible {
  outline: 3px solid var(--accent) !important;
  outline-offset: 3px !important;
}

[hidden] {
  display: none !important;
}

/* Contenedor de gráficas Plotly */
.stApp [data-testid="stPlotlyChart"] {
  border: 1px solid var(--border-purple);
  border-radius: 10px;
  overflow: hidden;
  background: var(--bg-chart-deep);
}

/* ==========================================================================
   PROBABILIDADES, ALERTAS CRÍTICAS Y PIE LEGAL
   ========================================================================== */
.p5-prob-row {
  margin-bottom: 0.85rem;
}

.p5-prob-header {
  display: flex;
  justify-content: space-between;
  font-family: var(--font-body);
  font-weight: 800;
  font-size: 1.05rem;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  margin-bottom: 0.3rem;
}

.p5-prob-track {
  width: 100%;
  height: 22px;
  background: var(--bg-primary);
  border: 2px solid var(--text-primary);
  box-shadow: 4px 4px 0px var(--bg-primary);
  overflow: hidden;
  position: relative;
}

.p5-prob-fill {
  height: 100%;
  background: repeating-linear-gradient(
    -45deg,
    var(--primary),
    var(--primary) 12px,
    var(--primary-dark, #0E7490) 12px,
    var(--primary-dark, #0E7490) 24px
  );
  border-right: 3px solid var(--accent);
}

@media (prefers-reduced-motion: no-preference) {
  .p5-prob-fill {
    transition: width 0.3s ease;
  }
}

.p5-critical-alert {
  background: linear-gradient(135deg, var(--bg-primary) 0%, var(--bg-chart) 68%, var(--bg-panel) 100%);
  border: 4px solid var(--accent);
  box-shadow: 10px 10px 0px var(--bg-primary);
  padding: 1.75rem;
  margin: 1.5rem 0;
}

.p5-critical-title {
  font-family: var(--font-body) !important;
  font-weight: 900;
  font-size: clamp(1.5rem, 3vw, 2.25rem);
  color: var(--accent) !important;
  text-shadow: 3px 3px 0px var(--bg-primary);
  margin: 0 0 0.75rem 0;
}

.p5-legal-footer {
  background: var(--bg-primary);
  border: 2px solid var(--text-secondary);
  border-left: 6px solid var(--primary);
  box-shadow: 5px 5px 0px var(--bg-primary);
  padding: 0.9rem 1.2rem;
  margin-top: 1.5rem;
  font-style: italic;
  color: var(--text-secondary);
  font-size: 0.94rem;
}

/* ==========================================================================
   RESPONSIVIDAD Y PREFERENCIAS DE CONTRASTE DEL SISTEMA
   ========================================================================== */
@media (max-width: 1100px) {
  .resume-grid,
  .sp-shell {
    grid-template-columns: minmax(0, 1fr);
  }
}

@media (max-width: 900px) {
  .p5-hero {
    flex-direction: column;
    align-items: flex-start;
  }
  .p5-hero-img {
    width: min(100%, 480px);
  }
  .sc-main {
    margin-left: 0;
    padding-left: 0.75rem;
  }
}

@media (max-width: 800px) {
  .stApp [data-testid="stHorizontalBlock"] {
    flex-wrap: wrap;
  }
  .stApp [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {
    flex: 1 1 100%;
    width: 100%;
  }
  .stApp .st-key-dashboard_indicadores [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {
    flex: 1 1 calc(50% - 0.5rem);
    width: calc(50% - 0.5rem);
  }
  .st-key-dashboard_indicadores [data-testid="stMetricValue"] > div {
    font-size: 1.25rem;
  }
}

@media (max-width: 640px) {
  [data-testid="stMainBlockContainer"] {
    padding: 4.1rem 1rem 3.5rem;
  }
  .stApp h1 {
    font-size: clamp(1.5rem, 6.2vw, 2rem) !important;
    line-height: 1.2 !important;
    overflow-wrap: anywhere;
  }
  .p5-banner {
    padding: 0.8rem 1rem;
  }
  .p5-banner-title {
    font-size: clamp(1.1rem, 4vw, 1.45rem);
    overflow-wrap: anywhere;
  }
  .p5-banner-sub {
    font-size: 0.85rem;
    letter-spacing: 0.04em;
  }
  .sc-bar-content {
    flex-wrap: wrap;
    padding: 0.9rem;
    gap: 0.75rem;
  }
  .sc-main {
    padding-left: 0.5rem;
  }
  .sc-stats {
    flex-wrap: wrap;
  }
  .sc-label {
    font-size: 1.15rem !important;
  }
  .sc-subdesc {
    font-size: 0.92rem !important;
  }
  .p5-hero {
    padding: 1.25rem;
  }
  .resume-card {
    padding: 0.85rem 1rem 0.85rem 4.35rem;
  }
}

@media (prefers-contrast: more) {
  html,
  body,
  [data-testid="stAppViewContainer"],
  [data-testid="stSidebarContent"],
  .stApp {
    --scrollbar-thumb: #ffffff;
    --scrollbar-track: #000000;
  }
  :root {
    --bg-primary: #000000;
    --bg-panel: #0a1026;
    --text-primary: #ffffff;
    --text-secondary: #f0f4ff;
  }
  .p5-card,
  .p5-card-accent,
  .p5-callout-warning,
  .p5-kpi-card,
  .resume-card,
  .sp-item,
  .sc-bar,
  .p5-banner {
    border-color: #ffffff !important;
  }
}

@media (forced-colors: active) {
  :root {
    color-scheme: light dark;
  }
  .p5-menu-stage,
  .p5-hero,
  .p5-banner,
  .p5-card,
  .p5-card-accent,
  .p5-callout-warning,
  .p5-kpi-card,
  .resume-card,
  .resume-detail-panel,
  .sp-item,
  .sp-right,
  .sc-bar,
  .p5-critical-alert,
  .p5-legal-footer,
  [data-testid="stForm"],
  [data-testid="stPlotlyChart"] {
    border: 2px solid CanvasText !important;
    box-shadow: none !important;
    background: Canvas !important;
    color: CanvasText !important;
  }
  .p5-row[aria-current="page"],
  .resume-card-wrap[aria-selected="true"] .resume-card,
  .sp-item[aria-selected="true"],
  [data-testid="stTabs"] [role="tab"][aria-selected="true"] {
    border: 2px solid Highlight !important;
    border-inline-start: 6px solid Highlight !important;
  }
  .stButton > button,
  .stDownloadButton > button,
  [data-testid="stFormSubmitButton"] > button {
    border: 2px solid ButtonText !important;
    background: ButtonFace !important;
    color: ButtonText !important;
  }
  :focus-visible {
    outline: 3px solid Highlight !important;
    outline-offset: 3px !important;
  }
}

````

