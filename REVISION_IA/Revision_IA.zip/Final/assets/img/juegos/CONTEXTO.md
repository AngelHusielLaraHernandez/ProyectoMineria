# Carpeta: Final/assets/img/juegos

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## CREDITOS.md

Ruta: `Final/assets/img/juegos/CREDITOS.md` · Bytes: 1347 · SHA-256: `92a6b49936f14d3e55bd2b20b8286f1a9915c4563d2c0321d8af6e28e44b05f3`

````text
# Imagenes de videojuegos

- Halo Infinite, arte de lanzamiento de [Xbox Wire](https://news.xbox.com/en-us/2021/12/08/halo-infinite-available-now-with-xbox-game-pass/).
- God of War Ragnarök, arte de [Santa Monica Studio y PlayStation.Blog](https://blog.playstation.com/2022/09/13/the-god-of-war-ragnarok-story-trailer-is-now-live/).
- The Legend of Zelda: Tears of the Kingdom y arte de Link de [Nintendo](https://www.nintendo.com/us/store/products/the-legend-of-zelda-tears-of-the-kingdom-switch/).
- Super Mario Odyssey, arte oficial de [Nintendo](https://www.nintendo.com/us/store/products/super-mario-odyssey-switch/).
- Marvel's Spider-Man 2, arte de [Insomniac Games y PlayStation.Blog](https://blog.playstation.com/?p=381026).
- Hogwarts Legacy, arte de Warner Bros. Games y Avalanche Software en [Steam](https://store.steampowered.com/app/990080/Hogwarts_Legacy/).
- Bloodborne PSX, imagen publicada por [LWMedia en itch.io](https://b0tster.itch.io/bbpsx).
- Wo Long: Fallen Dynasty, arte de KOEI TECMO GAMES en [Steam](https://store.steampowered.com/app/1448440/Wo_Long_Fallen_Dynasty/).
- Limbus Company, arte de Project Moon en [Steam](https://store.steampowered.com/app/1973530/Limbus_Company/).
- Citizen Sleeper, arte de Jump Over The Age y Fellow Traveller en [Steam](https://store.steampowered.com/app/1578650/Citizen_Sleeper/).

````

## bloodborne-psx.webp

Ruta: `Final/assets/img/juegos/bloodborne-psx.webp` · Bytes: 27282 · SHA-256: `9811f99b2dc4155f3dfb9201c760d7996b44111c22e51cd12d5497fd030ac75c`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## citizen-sleeper.webp

Ruta: `Final/assets/img/juegos/citizen-sleeper.webp` · Bytes: 69626 · SHA-256: `74ee4bb4585c597db1a92163409b034d4a6a0c471f5636ca89539743fef2a164`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## god-of-war.webp

Ruta: `Final/assets/img/juegos/god-of-war.webp` · Bytes: 57264 · SHA-256: `84fda966be1b12e1fcd1ee8d521dc801b7321a76de9d9c469d4033163b0b7cd4`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## halo.webp

Ruta: `Final/assets/img/juegos/halo.webp` · Bytes: 92976 · SHA-256: `d02360e152b78b30daecd1765ee6b29935ef9f4c354b74239a982dda7d3d45ec`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## hogwarts.webp

Ruta: `Final/assets/img/juegos/hogwarts.webp` · Bytes: 37730 · SHA-256: `dc140a0df594a295c3201c4b2ceb8df863e5745327d2dc7821fc82e73ed3430b`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## limbus.webp

Ruta: `Final/assets/img/juegos/limbus.webp` · Bytes: 39408 · SHA-256: `0042c518ca0dd08c474bd5ed3842e249efa70f783b8f684d5ce71ddd2d30a10a`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## link.webp

Ruta: `Final/assets/img/juegos/link.webp` · Bytes: 134824 · SHA-256: `e08a9bf52276186ae19f533408e3c8d5d53ea7138693e1440d4bb2c316e85bf3`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## mario.webp

Ruta: `Final/assets/img/juegos/mario.webp` · Bytes: 126826 · SHA-256: `efa337605ef029c9eb2419a1ca98d22bc5ba06b07fc904b013f263b035e0fbc7`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## spider-man.webp

Ruta: `Final/assets/img/juegos/spider-man.webp` · Bytes: 32208 · SHA-256: `bfdfd47929144cb16a7e53e1ec43d5a481f4bfffb800b2f9f7dea9cc60a331cc`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## wo-long.webp

Ruta: `Final/assets/img/juegos/wo-long.webp` · Bytes: 24570 · SHA-256: `56f994cf7f947b7678d51af43d98ea222fcc5046efdcc6e4cc04f750f35e7cbb`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## zelda.webp

Ruta: `Final/assets/img/juegos/zelda.webp` · Bytes: 95330 · SHA-256: `e0c77f05cda0ee34a2d01590d84fed18a34d19c8f0b7b2af10b3d06cecbce56f`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

