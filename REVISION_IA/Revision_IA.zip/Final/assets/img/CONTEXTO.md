# Carpeta: Final/assets/img

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## hero.png

Ruta: `Final/assets/img/hero.png` · Bytes: 44919 · SHA-256: `72a860570eddf1dd9988f26c7106c67be286bc9f2fd3303c465ce87edb1ae6cd`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## newsign.png

Ruta: `Final/assets/img/newsign.png` · Bytes: 1447783 · SHA-256: `e5da344c670df19928efc325e1129d001742104b49023cb33e3899fa073becd7`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

