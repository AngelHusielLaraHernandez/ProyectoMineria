# Carpeta: Final/assets

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `Final/assets/BITACORA_UNIFICADA.md` · Bytes: 710 · SHA-256: `f3f94b84daec26a305caf49747d26cf3d0b37ac85160669057b471dc796c7ea4`

````text
# Recursos de la aplicación

- Las hojas de estilo, scripts, imágenes, fuentes y sonidos de esta carpeta se cargan desde la web. Se retiró la carpeta separada de fuentes que ya no se cargaba.

## Imagenes de videojuegos

Se reemplazo el arte de Persona en la web con imagenes de Halo Infinite, Zelda, God of War, Super Mario Odyssey y Spider-Man 2. El menu ajusta la imagen al ancho y alto del panel. Los creditos estan junto a los recursos.

## Ilustraciones de las tarjetas

Se añadieron las cinco portadas del ejemplo de Predicción y se ilustraron las cinco entradas de la bitácora de algoritmos. Cuando un título no tiene portada local, la tarjeta identifica su imagen como ilustración decorativa.

````

