# Carpeta: Final

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## .gitignore

Ruta: `Final/.gitignore` · Bytes: 90 · SHA-256: `658d308e80f75dd757ed5f3db735c1d93221874cb4f847a155258e80c8b1693f`

````text
.venv/
.venv314/
__pycache__/
.pytest_cache/
.cache/
.impeccable/
.streamlit/secrets.toml

````

## .python-version

Ruta: `Final/.python-version` · Bytes: 5 · SHA-256: `a876e0b10411037a012498b9fe18d9bc1df32ed8b722a13564dc944ddcfd9135`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## BITACORA_UNIFICADA.md

Ruta: `Final/BITACORA_UNIFICADA.md` · Bytes: 245 · SHA-256: `b2e9f5a497260a5de2e0cc432144c40b2e6e72e7f59772a8d53552166f8a1da7`

````text
# Aplicación y análisis

- Esta carpeta reúne la app de Streamlit, el análisis, el modelo y las pruebas. El comando de arranque está en el README.
- La bitácora de ejecución y auditoría está en [reports](reports/BITACORA_UNIFICADA.md).

````

## DESIGN.md

Ruta: `Final/DESIGN.md` · Bytes: 2336 · SHA-256: `ed363969fb5d3666c3e606e472dc113bbcedea6d10e27fe4b1ba82781bb947a9`

````text
# Interfaz del Observatorio de Videojuegos (Identidad Persona 5 accesible)

Modo: consulta e inferencia académica con temática visual oscura Persona 5 (azul medianoche y neón cian/morado). La navegación principal reside exclusivamente en la barra lateral personalizada (`showSidebarNavigation = false` en `.streamlit/config.toml`), con encabezados semánticos y tareas delimitadas por página.
Las tablas, selectores y formularios conservan la semántica nativa, teclado, foco visible (`:focus-visible` sin recorte de `clip-path`) y adaptación responsiva de Streamlit. Los gráficos muestran unidades, marcadores/símbolos diferenciados y margen superior suficiente para no quedar cubiertos por la barra de herramientas.

## Tokens y tipografía

- **Tipografía**: `'ComicProyecto'` (`Persona5main.ttf`) reservada exclusivamente para encabezados display (`.p5-banner-title`, `.p5-hero-title`, `.sc-role`, `.p5-row`); `sans-serif` del sistema con `tabular-nums` en cuerpo, tablas, formularios, tarjetas KPI y ejes/hover de Plotly.
- **Paleta y contraste WCAG AA (>= 4.5:1)**:
  - Fondo principal `#050D22`, panel `#15254A`, lienzo de gráficas `#170D37` / `#100B29`.
  - Acento cian neón `#00CFFF` sobre fondos oscuros (10.46:1); variante `#0E7490` para rellenos interactivos con texto blanco (`primaryColor` en `config.toml`, 5.36:1) y cifras sobre fondos claros (5.01:1).
  - Acentos secundarios `#8B9CFF`, `#A56BFF`, `#3B2386` (gradiente de banners), `#FFD166`, texto `#F5F7FF` y secundario `#C8CDEB`.
- **Movimiento y preferencias del sistema**: Transiciones de página ejecutadas únicamente al cambiar de vista (`session_state`), animaciones activadas de forma explícita con `@media (prefers-reduced-motion: no-preference)`, barras de desplazamiento adaptadas (`scrollbar-color`, `scrollbar-width: auto`, `scrollbar-gutter: stable`) y soporte para `@media (prefers-contrast: more)` y `@media (forced-colors: active)`.

## Estados y evidencia

Filtros con estado vacío; errores de preparación con recuperación explícita (`CRITICAL ALERT / MISSION FAILED`); audio unificado y accesible en la barra lateral sin paneles flotantes superpuestos; predicción solicitada mediante formulario.
Se prueban las cuatro páginas, búsqueda vacía, caché de recursos y predicción con valores ausentes mediante `AppTest` y `pytest`.

````

## PRODUCT.md

Ruta: `Final/PRODUCT.md` · Bytes: 1234 · SHA-256: `c88579d2a909bad19da573db71b4a7870a3af96cd0faa323661086a1544c2179`

````text
# Observatorio de videojuegos

## Platform
web

## Stack
Python y Streamlit (`1.67.0`), indicados por el usuario. Datos y modelos locales, sin APIs necesarias para reproducir.

## Propósito y evidencia
Consultar valoración, actividad, interés, perfiles de mercado y clasificación relativa de popularidad.
Fuente indicada: Backloggd vía Kaggle, Arnab Chaki, con agregados locales. La atribución no sustituye la verificación de licencia.
El maestro designado `games_curated.csv` contiene 42 columnas y 1,117 registros; sus estimaciones se distinguen de la crítica marcada como Metacritic.

## Restricciones confirmadas
No inventar datos, usar semilla 42, rutas portables, comentarios y mensajes visibles en español.
Conservar el trabajo anterior en `Proyecto/` y desarrollar aquí. No inferir escala ni funciones de `Team`.

## Identidad y criterios visuales
Uso académico para explorar y presentar hallazgos con estética oscura inspirada en Persona 5 (`Final/DESIGN.md`), navegación personalizada en barra lateral y controles nativos de Streamlit.
Se priorizan legibilidad, contraste WCAG AA (>= 4.5:1), ausencia de solapamientos, respeto a `prefers-reduced-motion` y acceso claro a metodología sobre efectos decorativos.

````

## README.md

Ruta: `Final/README.md` · Bytes: 8252 · SHA-256: `b7f2f1a2a95a720561712406b02b78fff88df61929b9ef4dec8e77232152add8`

````text
# Observatorio de Videojuegos — Edición Phantom Thieves (Persona 5 UI)

Proyecto de minería de datos sobre un catálogo curado de videojuegos de Backloggd y Metacritic (1,117 registros, 1,114 elegibles). Contiene un pipeline reproducible (inspección, limpieza, clustering, clasificación) y una app Streamlit con estética Persona 5.

> Alcance: popularidad **relativa** (interacciones en Backloggd) y brecha usuarios–prensa. No mide ventas ni éxito comercial. Resultados y límites: [`reports/evaluacion.md`](reports/evaluacion.md).

## 1. Ejecución rápida

```bash
cd Final
python3.14 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
.venv/bin/python -m streamlit run app.py   # http://localhost:8501
.venv/bin/python -m pytest -q              # pruebas (143 en tests/)
```
> [!NOTE]
> Para regenerar datos, clústeres, modelos, comparativos y manifiesto son equivalentes ambos comandos desde `Final/`: `.venv/bin/python src/run_all.py` o `.venv/bin/python -m src.pipeline`. En el `.venv` local los paquetes de `site-packages` se reutilizaron sin acceso al índice PyPI (`pip check` pasa), por lo que `.venv/bin/` no contiene los wrappers CLI `pytest` ni `streamlit` registrados en `RECORD`; usa siempre `python -m streamlit` y `python -m pytest`.

`requirements.txt` fija las versiones (`scikit-learn==1.9.1`, igual que `models/metadata.json`). `requirements-lock.txt` guarda el entorno completo. El entorno `.venv` y el modelo se verificaron con Python 3.14.6. `pip check` pasa. La versión menor figura en `.python-version`. [Metadatos del modelo](models/metadata.json).

## 2. Código fuente (`src/`)

| Archivo | Función |
|---|---|
| `pipeline.py` y `run_all.py` | Orquesta 01 → 02 → 03 → `metodos_clase` → `analisis_integral` → 04 → `comparativo_integral` y escribe `reports/manifest.json` con hashes y `huella_pipeline()` (hash de `src/*.py` + `requirements.txt`). Equivalentes: `python src/run_all.py` y `python -m src.pipeline`. |
| `01_inspeccion.py` | Esquema, procedencia de notas, seis figuras EDA → `reports/inspeccion.md/json`, `figures/`. |
| `02_limpieza.py` | Valida el maestro, genera `dataset_depurado.csv`, `generos_largo.csv` y `limpieza_log.md`. |
| `procedencia.py` | Reconstruye 1,512 → 1,117 filas, descartes y conflictos históricos (117, 140, 296). |
| `03_clustering.py`, `metodos_clase.py`, `analisis_integral.py` | Correlaciones (Pearson/Spearman, mín. 20 pares, corrección BH), K-Means k = 2…10, DBSCAN, Ward, GMM BIC, PCA y tablas normalizadas en `reports/tables/`. |
| `comparar_weka.py` | K-Means de **Weka 3.8.6 (CLI)** sobre el mismo espacio (`--descargar` baja los JAR) → `reports/weka/`. |
| `comparativo_integral.py` | Contrasta Python (CV anidada) con las corridas gráficas de **Weka 3.8.7 (Explorer GUI)**, registra el descarte de Orange y genera `tables/comparativo_herramientas.csv` y `reports/verificacion_weka_orange.md` sin sobrescribir `reports/BITACORA_UNIFICADA.md`. |
| `objetivo.py` | Define el índice de popularidad (promedio de rangos percentiles de Plays, Wishlist, Backlogs) y los terciles, ajustados solo con entrenamiento. |
| `features.py` | Preprocesamiento: géneros multi-hot, estudio, década, notas con mediana. |
| `04_modelo.py`, `evaluacion_anidada.py`, `05_revision_predicciones.py` | Compara Dummy, CategoricalNB, CART, Random Forest y MLP en CV anidada de 10 pliegues por 5 repeticiones y prueba reservada; guarda el bosque como modelo activo. |
| `inferencia.py`, `similitud.py` | Contrato crudo de predicción y `NearestNeighbors` en el espacio predictivo, solo con entrenamiento. |
| `config.py`, `data.py`, `analysis.py`, `modeling.py` | Rutas, carga con caché y adaptadores para la app. |
| `ui.py`, `visualizacion.py` | Tema Persona 5 accesible: CSS, fuente en Base64, menú lateral, audio, carga validada por manifiesto y tema Plotly. |

## 3. Datos, modelos y reportes

- `data/raw/games_curated.csv`: maestro inmutable (42 columnas).
- `data/historical/`: antecedente de 1,512 filas, solo para auditoría.
- `data/clean/`: `dataset_depurado.csv`, `dataset_con_clusters.csv`, `generos_largo.csv`, `juegos_modelo.csv` y exportaciones para Weka/Orange.
- `data/export/`: `clustering.*` y `clasificacion.*` (CSV, ARFF, TAB) usados en Weka 3.8.7 Explorer.
- `models/`: `modelo_popularidad.joblib` (Pipeline portátil con cloudpickle), `vecinos_popularidad.joblib`, `clustering_03.joblib`, `metadata.json`, `referencias_folds.json`.
- `reports/`: `evaluacion.md` (evaluación final), `inspeccion.md`, `limpieza_log.md`, `clustering.md`, `modelo.md`, `hallazgos.md`, `comparacion_weka.md`, `weka/` (corridas CLI de **Weka 3.8.6** y evidencias gráficas de **Weka 3.8.7 Explorer**), `orange/` (diagnóstico de cierres), `verificacion_weka_orange.md`, `BITACORA_UNIFICADA.md`, `tables/comparativo_herramientas.csv`, `manifest.json`.
- `tests/`: pruebas de limpieza, clustering, modelo, auditorías y pipeline (`pytest.ini` fija `testpaths = tests`).

## 4. Aplicación web

| Página | Archivo | Contenido |
|---|---|---|
| Inicio | `app.py` | Presentación, KPIs del catálogo (`1,117` maestro / `1,114` elegibles), explorador rápido con descarga CSV y aviso de limitaciones. |
| Exploración | `pages/1_Exploracion.py` | Filtros globales, indicadores y cuatro pestañas: *Señales de actividad*, *Recepción y brecha*, *Segmentación (Clustering)* (K-Means, Ward, dendrograma, DBSCAN y PCA) y *Riesgo comercial (GaaS)*, con descarga CSV. |
| Predicción | `pages/2_Prediccion.py` | Formulario (incluye década `-1` para fechas no interpretables), brecha contextual del género, probabilidades (`bajo`/`medio`/`alto`, sin calibrar) y 5 vecinos cercanos de entrenamiento. |
| Acerca del modelo | `pages/3_Acerca_del_modelo.py` | Ficha del bosque activo, comparación en CV anidada `10×5`, contrastes, matriz de confusión, importancia Gini, desempeño por clase con diagnóstico de ausencia y fiabilidad. |

Recursos: `assets/css/persona5.css`, `assets/js/interacciones.js`, `assets/fonts/Persona5main.ttf`, `assets/audio/` (control unificado en barra lateral para BGM y SFX), `assets/img/`. El tema oscuro alineado con `PALETA` (`showSidebarNavigation = false`) está en `.streamlit/config.toml` y `../.streamlit/config.toml`. Los modelos y datos se cachean con `@st.cache_resource` y `@st.cache_data`. Todas las rutas usan `pathlib.Path` relativo a `Final/`. Si falta un artefacto o cambia `huella_pipeline()`, la app indica ejecutar `python -m src.pipeline` (equivalente a `python src/run_all.py`).

## 5. Resultados y despliegue

La MLP tuvo mayor F1 macro medio en CV anidada (`0.5538` vs. `0.5495`). Random Forest tuvo menor dispersión y sigue activo (`F1 = 0.5577` y exactitud `56.76 %` en `n = 222` de prueba). Los contrastes de esa pareja son inconclusos (`p >= 0.3876`). Los resultados de la MLP en prueba pertenecen a la corrida histórica. [Comparativo externo](reports/tables/comparativo_modelos.csv), [contrastes](reports/tables/comparacion_estadistica.csv) y [prueba del bosque](reports/tables/metricas_prueba.csv).

Los cortes globales son descriptivos. El Pipeline y las referencias de evaluación se ajustan con los datos de entrenamiento de cada pliegue. El modelo ofrece una estimación orientativa de interacciones de Backloggd y puede desfavorecer géneros de nicho. El estudio carece de ventas observadas.

Para simular el arranque de Community Cloud desde la raíz Git, ejecuta `Final/.venv/bin/python -m streamlit run Final/app.py`. La entrada usa `Final/requirements.txt` y la configuración de la raíz. La guía enlaza la documentación oficial, la selección de Python y la revisión de derechos.

En **Exploración → pestaña Riesgo comercial (GaaS)** se pueden consultar casos documentados por las editoras. La tabla respalda también las secciones de evidencia comercial del PDF. [Casos y fuentes](reports/tables/evidencia_comercial.csv) · [Diseño de comparación por género](reports/riesgo_comercial.md).

- No hay despliegue público (ver `reports/despliegue.md`).
- Orange no tiene corridas verificadas. Weka sí (ver `reports/weka/BITACORA_UNIFICADA.md`).
- No editar `src/*.py` ni `requirements.txt` sin regenerar el pipeline, porque su hash se registra en el manifiesto.

````

## app.py

Ruta: `Final/app.py` · Bytes: 25004 · SHA-256: `506752c548c107b2b1d9fb0513412ca19f8f5982f51bf3a8d0efa5683bf56180`

````text
"""Página de inicio del Observatorio de Videojuegos."""
import importlib
import json
import sys
import streamlit as st

import src.data as _data

if getattr(_data, '_MOD_VERSION', None) != 'p5-v11-arte':
    if 'src.config' in sys.modules:
        importlib.reload(sys.modules['src.config'])
    _data = importlib.reload(_data)
    _data.asegurar_modulos_vigentes(config_recargado=True)
else:
    _data.asegurar_modulos_vigentes()

from src.config import REPORTS, SIGNALS
from src.ui import (
    asset_b64,
    read_report,
    render_html,
    render_lb_rb_nav,
    resources,
    section_banner,
    setup,
)

setup(
    'Observatorio de Videojuegos',
    'Actividad y calificaciones en Backloggd y Metacritic',
    transition='default',
    menu_idx=0,
    compact_menu=False,
)

df, bundle, analysis = resources()
metricas_modelo = bundle['metricas']
linaje = read_report('tables/procedencia_datos.csv').set_index('etapa')
n_maestro = int(linaje.loc['Maestro curado', 'filas'])
n_antecedente = int(linaje.loc['Antecedente enriquecido', 'filas'])
n_elegibles = int(df['elegible_analisis'].sum())
n_fechas_no_interp = (
    int(df['fecha_no_interpretable'].sum())
    if 'fecha_no_interpretable' in df
    else int(df['decada'].isna().sum())
)
asociacion = read_report('tables/correlacion_catalogo.csv').iloc[0]
catalogo = json.loads((REPORTS / 'tables/catalogo_resumen.json').read_text(encoding='utf-8'))
umbral_pares = read_report('tables/parametros_clustering.csv').iloc[0].minimo_pares_correlacion
preparador = bundle['pipeline'].named_steps['preparar'].named_transformers_
decadas = [int(x) for x in preparador['decada'].named_steps['codificar'].categories_[0] if x >= 0]

st.page_link('pages/1_Exploracion.py', label='Abrir panel interactivo de exploración')
st.info(
    'La predicción toma como referencia los juegos registrados en Backloggd y puede representar menos a los '
    'géneros de nicho. '
    'Los casos publicados por editoras se pueden consultar en Exploración.'
)

# ---------------------------------------------------------------------------
# 1. CABECERA PRINCIPAL
# ---------------------------------------------------------------------------
halo_b64 = asset_b64('img/juegos/halo.webp')
hero_img_html = (
    f'<img class="p5-hero-img" src="data:image/webp;base64,{halo_b64}" alt="Master Chief en Halo Infinite"/>'
    if halo_b64 else ''
)

render_html(
    f"""
    <div class="p5-hero">
        <div>
            <div class="p5-hero-title">Notas y popularidad de los videojuegos</div>
            <p class="p5-hero-sub">
                Comparamos las notas de los jugadores con las de la prensa. Después revisamos qué juegos
                aparecen más como jugados, cuáles siguen pendientes y cuáles están en las listas de deseos.
            </p>
        </div>
        {hero_img_html}
    </div>
    """
)

# ---------------------------------------------------------------------------
# 2. PROPÓSITO DEL PROYECTO
# ---------------------------------------------------------------------------
render_lb_rb_nav('QUÉ REVISAMOS')

zelda_b64 = asset_b64('img/juegos/zelda.webp')
kratos_b64 = asset_b64('img/juegos/god-of-war.webp')
mario_b64 = asset_b64('img/juegos/mario.webp')

render_html(
    f"""
    <div class="sc-root" role="region" aria-label="Temas del observatorio">
        <!-- BAR 1: LÍDER // INDUSTRIA -->
        <div class="sc-bar-outer active">
            <div class="sc-bar-red"></div>
            <div class="sc-bar">
                <div class="sc-bar-fill"></div>
                <div class="sc-bar-shade"></div>
                <div class="sc-bar-content">
                    <img class="sc-char sc-art-zelda" src="data:image/webp;base64,{zelda_b64}" alt=""/>
                    <div class="sc-main">
                        <div class="sc-label">ACTIVIDAD E INTERÉS</div>
                        <div class="sc-subdesc">
                            Para el análisis usamos {n_elegibles:,} de los {n_maestro:,} juegos del catálogo. Separamos los que la gente marcó como jugados de los que guardó en pendientes o en su lista de deseos.
                        </div>
                    </div>
                    <div class="sc-stats">
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--primary);border-color:var(--primary);">ANTES</span>
                                <span class="sc-stat-num">{n_antecedente:,}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--primary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--secondary);border-color:var(--secondary);">CATÁLOGO</span>
                                <span class="sc-stat-num">{n_maestro:,}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--secondary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- BAR 2: ALIADO // BRECHA USUARIOS VS CRÍTICA -->
        <div class="sc-bar-outer">
            <div class="sc-bar-red"></div>
            <div class="sc-bar">
                <div class="sc-bar-fill"></div>
                <div class="sc-bar-shade"></div>
                <div class="sc-bar-content">
                    <img class="sc-char sc-art-kratos" src="data:image/webp;base64,{kratos_b64}" alt=""/>
                    <div class="sc-main">
                        <div class="sc-label">NOTAS DE JUGADORES Y PRENSA</div>
                        <div class="sc-subdesc">
                            En los {int(asociacion.n):,} juegos con las dos notas, cuando una sube la otra suele subir también. En Exploración se puede ver cuánto se separan por género y por organización.
                        </div>
                    </div>
                    <div class="sc-stats">
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--primary);border-color:var(--primary);">PARES</span>
                                <span class="sc-stat-num">{int(asociacion.n):,}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--primary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--accent);border-color:var(--accent);">PEARSON</span>
                                <span class="sc-stat-num">{asociacion.pearson_r:.3f}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--accent);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- BAR 3: ALIADO // RIESGOS GAAS E INFERENCIA -->
        <div class="sc-bar-outer">
            <div class="sc-bar-red"></div>
            <div class="sc-bar">
                <div class="sc-bar-fill"></div>
                <div class="sc-bar-shade"></div>
                <div class="sc-bar-content">
                    <img class="sc-char sc-art-mario" src="data:image/webp;base64,{mario_b64}" alt=""/>
                    <div class="sc-main">
                        <div class="sc-label">ESTIMACIÓN DE POPULARIDAD</div>
                        <div class="sc-subdesc">
                            En Predicción puedes cambiar los datos de un lanzamiento, ver qué nivel estima el modelo y consultar cinco juegos parecidos.
                        </div>
                    </div>
                    <div class="sc-stats">
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--primary);border-color:var(--primary);">F1 PRUEBA</span>
                                <span class="sc-stat-num">{metricas_modelo['metricas']['f1_macro']:.3f}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--primary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--secondary);border-color:var(--secondary);">VECINOS</span>
                                <span class="sc-stat-num">TOP 5</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--secondary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    """
)

# ---------------------------------------------------------------------------
# 2. MÉTRICAS GENERALES (INDICADORES) — TARJETAS Y PANEL DE DETALLE
# ---------------------------------------------------------------------------
rango_temporal = f"{catalogo['anio_min']}–{catalogo['anio_max']}"
generos_unicos = sorted({g for row in df['generos'] for g in row})
top_generos = catalogo['top_generos']
top_org = catalogo['top_organizaciones']

def formato_grupo(fila):
    return f"{fila['grupo']} ({fila['n']})"

render_html(
    f"""
    <div class="resume-grid">
        <div class="resume-stack">
            <div class="resume-list-tag">LISTA // INDICADORES</div>

            <div class="resume-card-wrap active" data-detail-target="kpi-1">
                <div class="resume-card">
                    <div class="resume-badge"><div class="resume-badge-text">I</div></div>
                    <div class="resume-card-inner">
                        <div class="resume-title">CATÁLOGO</div>
                        <div class="resume-rank">
                            <div class="resume-rank-label">JUEGOS</div>
                            <div class="resume-rank-number">{len(df):,}</div>
                        </div>
                    </div>
                    <div class="resume-subtitle-bar">
                        <div class="resume-subtitle">{n_elegibles:,} JUEGOS INCLUIDOS EN EL ANÁLISIS</div>
                    </div>
                </div>
            </div>

            <div class="resume-card-wrap" data-detail-target="kpi-2">
                <div class="resume-card">
                    <div class="resume-badge"><div class="resume-badge-text">II</div></div>
                    <div class="resume-card-inner">
                        <div class="resume-title">HORIZONTE</div>
                        <div class="resume-rank">
                            <div class="resume-rank-label">RANGO</div>
                            <div class="resume-rank-number">{rango_temporal}</div>
                        </div>
                    </div>
                    <div class="resume-subtitle-bar">
                        <div class="resume-subtitle">COBERTURA HISTÓRICA {rango_temporal}</div>
                    </div>
                </div>
            </div>

            <div class="resume-card-wrap" data-detail-target="kpi-3">
                <div class="resume-card">
                    <div class="resume-badge"><div class="resume-badge-text">III</div></div>
                    <div class="resume-card-inner">
                        <div class="resume-title">GÉNEROS</div>
                        <div class="resume-rank">
                            <div class="resume-rank-label">TOTAL</div>
                            <div class="resume-rank-number">{catalogo['n_generos']}</div>
                        </div>
                    </div>
                    <div class="resume-subtitle-bar">
                        <div class="resume-subtitle">MULTI-ETIQUETA CON {len(preparador['generos'].vocabulario_)} GÉNEROS FRECUENTES EN EL MODELO</div>
                    </div>
                </div>
            </div>

            <div class="resume-card-wrap" data-detail-target="kpi-4">
                <div class="resume-card">
                    <div class="resume-badge"><div class="resume-badge-text">IV</div></div>
                    <div class="resume-card-inner">
                        <div class="resume-title">ESTUDIOS</div>
                        <div class="resume-rank">
                            <div class="resume-rank-label">EQUIPOS</div>
                            <div class="resume-rank-number">{catalogo['n_organizaciones']:,}</div>
                        </div>
                    </div>
                    <div class="resume-subtitle-bar">
                        <div class="resume-subtitle">ESTUDIOS Y EDITORAS EN BACKLOGGD</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PANELES DE DETALLE DINÁMICOS -->
        <div>
            <div class="resume-detail-panel" data-detail-id="kpi-1" style="display:block;">
                <div class="resume-detail-top">
                    <div class="resume-detail-top-index">01</div>
                    <div class="resume-detail-top-title">LOS JUEGOS DEL CATÁLOGO</div>
                    <div class="resume-detail-top-progress">{n_maestro:,}</div>
                </div>
                <div class="resume-detail-list">
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">01</div>
                        <div class="resume-detail-row-title">Registros antes de revisar los repetidos</div>
                        <div class="resume-detail-status">{n_antecedente:,} FILAS</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">02</div>
                        <div class="resume-detail-row-title">Títulos Únicos por Nombre y Fecha</div>
                        <div class="resume-detail-status">{n_maestro:,} JUEGOS</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">03</div>
                        <div class="resume-detail-row-title">Juegos que usamos para el análisis</div>
                        <div class="resume-detail-status">{metricas_modelo['n_cohorte']:,} CASOS</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">04</div>
                        <div class="resume-detail-row-title">Juegos con las dos notas</div>
                        <div class="resume-detail-status">{int(asociacion.n):,} PARES</div>
                    </div>
                </div>
            </div>

            <div class="resume-detail-panel" data-detail-id="kpi-2" style="display:none;">
                <div class="resume-detail-top">
                    <div class="resume-detail-top-index">02</div>
                    <div class="resume-detail-top-title">COBERTURA TEMPORAL</div>
                    <div class="resume-detail-top-progress">{rango_temporal}</div>
                </div>
                <div class="resume-detail-list">
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">01</div>
                        <div class="resume-detail-row-title">Rango Observado en Dataset</div>
                        <div class="resume-detail-status">{rango_temporal}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">02</div>
                        <div class="resume-detail-row-title">Horizonte Analítico del Proyecto</div>
                        <div class="resume-detail-status">{rango_temporal}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">03</div>
                        <div class="resume-detail-row-title">Décadas Codificadas One-Hot</div>
                        <div class="resume-detail-status">{decadas[0]}s a {decadas[-1]}s</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">04</div>
                        <div class="resume-detail-row-title">Fechas no Interpretables</div>
                        <div class="resume-detail-status">{n_fechas_no_interp} CASOS · DÉCADA -1</div>
                    </div>
                </div>
            </div>

            <div class="resume-detail-panel" data-detail-id="kpi-3" style="display:none;">
                <div class="resume-detail-top">
                    <div class="resume-detail-top-index">03</div>
                    <div class="resume-detail-top-title">TAXONOMÍA DE GÉNEROS</div>
                    <div class="resume-detail-top-progress">{catalogo['n_generos']} GÉN</div>
                </div>
                <div class="resume-detail-list">
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">01</div>
                        <div class="resume-detail-row-title">Género con más juegos en el catálogo ({n_maestro:,})</div>
                        <div class="resume-detail-status">{formato_grupo(top_generos[0])}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">02</div>
                        <div class="resume-detail-row-title">Segundo y Tercer Género</div>
                        <div class="resume-detail-status">{' / '.join(map(formato_grupo, top_generos[1:]))}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">03</div>
                        <div class="resume-detail-row-title">Umbral de Correlación por Grupo</div>
                        <div class="resume-detail-status">MÍNIMO {umbral_pares} PARES</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">04</div>
                        <div class="resume-detail-row-title">Codificación en Clasificador</div>
                        <div class="resume-detail-status">MULTI-ETIQUETA + OTRO</div>
                    </div>
                </div>
            </div>

            <div class="resume-detail-panel" data-detail-id="kpi-4" style="display:none;">
                <div class="resume-detail-top">
                    <div class="resume-detail-top-index">04</div>
                    <div class="resume-detail-top-title">ESTUDIOS Y EDITORAS</div>
                    <div class="resume-detail-top-progress">{catalogo['n_organizaciones']} ORG</div>
                </div>
                <div class="resume-detail-list">
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">01</div>
                        <div class="resume-detail-row-title">Organización con más juegos ({n_maestro:,})</div>
                        <div class="resume-detail-status">{formato_grupo(top_org[0])}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">02</div>
                        <div class="resume-detail-row-title">Siguientes por Volumen</div>
                        <div class="resume-detail-status">{' / '.join(map(formato_grupo, top_org[1:]))}</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">03</div>
                        <div class="resume-detail-row-title">Frecuencia Mínima en Modelo</div>
                        <div class="resume-detail-status">&gt;= {preparador['estudio'].min_frecuencia} TÍTULOS</div>
                    </div>
                    <div class="resume-detail-row">
                        <div class="resume-detail-row-index">04</div>
                        <div class="resume-detail-row-title">Organizaciones con pocos juegos en el catálogo</div>
                        <div class="resume-detail-status">OPCIÓN «OTRO»</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    """
)

# ---------------------------------------------------------------------------
# 3. EXPLORADOR DEL CATÁLOGO
# ---------------------------------------------------------------------------
section_banner('Busca un juego en el catálogo', 'Filtra por género o escribe parte del título')

a, b = st.columns([2, 1])
query = a.text_input('Buscar título', placeholder='Escribe parte del nombre (ej. Halo, Zelda, Elden Ring)')
genre = b.selectbox('Género', ['Todos', *generos_unicos])

view = df[df['Title'].str.contains(query, case=False, regex=False, na=False)]
if genre != 'Todos':
    view = view[view['generos'].map(lambda row: genre in row)]

labels = {
    'popularidad_indice': 'Índice de popularidad',
    'critica_verificada_csv': 'Nota de prensa (Metacritic)',
    'Rating': 'Valoración de usuarios (0–5)',
    'Plays': 'Marcados como jugados',
    'Playing': 'Jugando actualmente',
    'Backlogs': 'Pendientes',
    'Wishlist': 'Lista de deseos',
}
order = st.selectbox(
    'Ordenar por',
    ['popularidad_indice', *SIGNALS, 'Rating', 'critica_verificada_csv'],
    format_func=labels.get,
)

st.caption(f'Se muestran {len(view):,} de {len(df):,} juegos del catálogo.')

shown = view.sort_values(order, ascending=False)[
    [
        'id_juego',
        'Title',
        'conflicto_historico_pendiente',
        'anio',
        'Rating',
        'critica_verificada_csv',
        *SIGNALS,
        'popularidad_indice',
    ]
]

if len(shown):
    columnas_visibles = [
        'Title',
        'anio',
        'Rating',
        'critica_verificada_csv',
        *SIGNALS,
        'popularidad_indice',
    ]
    st.dataframe(
        shown,
        hide_index=True,
        width='stretch',
        column_order=columnas_visibles,
        column_config={
            'Title': 'Videojuego',
            'anio': st.column_config.NumberColumn('Año', format='%d'),
            'Rating': st.column_config.NumberColumn('Usuarios (0–5)', format='%.2f'),
            'critica_verificada_csv': st.column_config.NumberColumn('Nota de prensa', format='%d'),
            'Plays': st.column_config.NumberColumn('Marcados como jugados', format='%d'),
            'Playing': st.column_config.NumberColumn('Jugando actualmente', format='%d'),
            'Backlogs': st.column_config.NumberColumn('Pendientes', format='%d'),
            'Wishlist': st.column_config.NumberColumn('Lista de deseos', format='%d'),
            'popularidad_indice': st.column_config.NumberColumn('Índice de popularidad', format='%.3f'),
        },
    )
    st.download_button(
        'Descargar esta consulta (CSV)',
        shown.to_csv(index=False).encode('utf-8'),
        'consulta_catalogo_videojuegos.csv',
        'text/csv',
    )
else:
    st.info('No hay coincidencias. Cambia el título o selecciona Todos en género.')

with st.expander('Cómo calculamos la popularidad'):
    st.write(
        'Primero ordenamos los juegos por cuántas veces se marcaron como jugados, cuántas veces '
        'se guardaron en pendientes y cuántas veces aparecieron en listas de deseos. Después '
        'sacamos el promedio del lugar que ocupó cada juego en esas tres listas. Usamos los '
        'juegos de entrenamiento como referencia para que todos se comparen en la misma escala.'
    )

````

## pytest.ini

Ruta: `Final/pytest.ini` · Bytes: 42 · SHA-256: `b160d82f7811555051f8966d8e02750a985227c1d022208c784e606946f2eada`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## requirements-lock.txt

Ruta: `Final/requirements-lock.txt` · Bytes: 849 · SHA-256: `11d78966be859ebd62255cf07c4c36fcaaf8660cfa3ee4182b0b18e54a93a0f6`

````text
altair==6.3.0
anyio==4.16.0
attrs==26.1.0
certifi==2026.10.23
charset-normalizer==3.5.2
click==8.5.1
cloudpickle==3.1.2
contourpy==1.4.0
cycler==0.12.1
fonttools==4.68.0
h11==0.16.0
idna==3.20
iniconfig==2.3.1
itsdangerous==2.2.0
Jinja2==3.1.6
joblib==1.6.0
jsonschema==4.26.0
jsonschema-specifications==2025.9.1
kiwisolver==1.5.1
MarkupSafe==3.0.4
matplotlib==3.11.2
narwhals==2.28.0
numpy==2.5.4
packaging==26.3
pandas==3.1.1
pillow==13.0.0
plotly==7.1.0
pluggy==1.7.0
protobuf==7.36.2
pyarrow==26.0.1
pydeck==0.9.3
Pygments==2.21.0
pyparsing==3.3.3
pytest==9.2.0
python-dateutil==4.0.0
python-multipart==0.0.33
referencing==0.37.0
requests==2.34.2
rpds-py==2026.9.1
scikit-learn==1.9.1
scipy==1.18.1
starlette==1.10.0
streamlit==1.67.0
threadpoolctl==3.8.0
typing_extensions==4.16.0
tzdata==2026.6
urllib3==2.8.0
uvicorn==0.54.0
websockets==17.4

````

## requirements.txt

Ruta: `Final/requirements.txt` · Bytes: 180 · SHA-256: `25190228cc03f28ee99c7f6cdec52bd73702c7b694b8a2bd9df64e7e4722e408`

````text
cloudpickle==3.1.2
joblib==1.6.0
matplotlib==3.11.2
numpy==2.5.4
pandas==3.1.1
plotly==7.1.0
pytest==9.2.0
scikit-learn==1.9.1
scipy==1.18.1
streamlit==1.67.0
threadpoolctl==3.8.0

````

## vista_graficas.py

Ruta: `Final/vista_graficas.py` · Bytes: 822 · SHA-256: `c9004e04de9b38a562fad663402da854190b17d117927f367dd28f1dd29ad9c4`

````text
"""Presentación adaptable para las gráficas de Streamlit."""

import streamlit as st

from src.ui import p5_plotly_layout

_MOD_VERSION = 'p5-v11-arte'


def mostrar_grafica(figura, titulo, *, alto=400, **opciones):
    """Coloca el título fuera del lienzo y aplica el tema accesible de Plotly."""
    st.subheader(titulo)
    p5_plotly_layout(figura, height=alto)
    top_margin = max(48, getattr(figura.layout.margin, 't', None) or 48)
    figura.update_layout(
        margin=dict(l=52, r=24, t=top_margin, b=64),
        legend=dict(orientation='h', x=0, y=-0.22, yanchor='top', font_size=12),
    )
    figura.update_xaxes(automargin=True)
    figura.update_yaxes(automargin=True)
    config = dict(displaylogo=False, responsive=True)
    return st.plotly_chart(figura, width='stretch', config=config, **opciones)

````

