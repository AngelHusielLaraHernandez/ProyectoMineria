# Carpeta: Final/pages

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## 1_Exploracion.py

Ruta: `Final/pages/1_Exploracion.py` · Bytes: 35675 · SHA-256: `b01c670037906a4d70a9f9f36aeddb256a255bd768a99aa2f4a5d156f0b8810b`

````text
"""Página 1 — Exploración (EDA, Brecha Usuarios-Crítica y Perfiles de Clustering)."""
import hashlib
import importlib
import json
import sys
from textwrap import wrap
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import src.data as _data

if getattr(_data, '_MOD_VERSION', None) != 'p5-v11-arte':
    if 'src.config' in sys.modules:
        importlib.reload(sys.modules['src.config'])
    _data = importlib.reload(_data)
    _data.asegurar_modulos_vigentes(config_recargado=True)
else:
    _data.asegurar_modulos_vigentes()

from src.config import CLEAN, REPORTS
from src.visualizacion import COLOR_SENALES, PALETA
from src.ui import (
    read_report,
    resources,
    section_banner,
    setup,
)

from vista_graficas import mostrar_grafica

setup(
    'Dashboard de videojuegos',
    'Explora actividad, recepción y perfiles del catálogo',
    transition='about',
    menu_idx=1,
    compact_menu=True,
)

df, bundle, analysis = resources()
elegibles = df.loc[df['elegible_analisis']].copy()
elegibles['rating_100_vista'] = elegibles['Rating'] * 20.0
elegibles['brecha_vista'] = elegibles['rating_100_vista'] - elegibles['critica_verificada_csv']


@st.cache_data(show_spinner=False)
def _cargar_perfiles_clusters(file_hash: str) -> pd.DataFrame:
    return pd.read_csv(CLEAN / 'dataset_con_clusters.csv')

def restablecer_filtros():
    st.session_state['eda_revision_filtros'] = int(st.session_state.get('eda_revision_filtros') or 0) + 1
    limpiar_seleccion()


def limpiar_seleccion():
    st.session_state['eda_revision_seleccion'] = int(st.session_state.get('eda_revision_seleccion') or 0) + 1


revision_filtros = int(st.session_state.get('eda_revision_filtros') or 0)
with st.expander('Filtros del dashboard', expanded=True):
    primera, segunda = st.columns(2)
    with primera:
        generos_sel = st.multiselect(
            'Géneros', sorted({g for fila in elegibles['generos'] for g in fila}),
            placeholder='Todos los géneros', key=f'eda_generos_{revision_filtros}',
        )
        rango_rating = st.slider(
            'Rating de usuarios (0–5)', 0.0, 5.0, (0.0, 5.0), .1,
            key=f'eda_rating_{revision_filtros}',
        )
    with segunda:
        decadas_sel = st.multiselect(
            'Décadas', sorted(int(d) for d in elegibles['decada'].dropna().unique() if d > 0),
            format_func=lambda d: f'{d}s', placeholder='Todas las décadas',
            key=f'eda_decadas_{revision_filtros}',
        )
        rango_meta = st.slider(
            'Metacritic (0–100)', 0, 100, (0, 100), key=f'eda_meta_{revision_filtros}',
        )
    st.button('Restablecer filtros', on_click=restablecer_filtros)
    st.caption('Los géneros se combinan por coincidencia con cualquiera de los seleccionados. '
               'Al acotar una escala de calificación se excluyen los juegos sin esa nota.')

filtrado = elegibles.copy()
if generos_sel:
    filtrado = filtrado[filtrado['generos'].map(lambda gs: any(g in gs for g in generos_sel))]
if decadas_sel:
    filtrado = filtrado[filtrado['decada'].isin(decadas_sel)]
if rango_rating != (0.0, 5.0):
    filtrado = filtrado[filtrado['Rating'].between(*rango_rating)]
if rango_meta != (0, 100):
    filtrado = filtrado[filtrado['critica_verificada_csv'].between(*rango_meta)]

pares_filtrados = filtrado.dropna(subset=['Rating', 'critica_verificada_csv']).copy()
mediana_plays = filtrado['Plays'].median() if filtrado['Plays'].notna().any() else None
brecha_absoluta = pares_filtrados['brecha_vista'].abs().mean()
with st.container(key='dashboard_indicadores'):
    indicadores = st.columns(4)
    indicadores[0].metric('Juegos filtrados', f'{len(filtrado):,} / {len(elegibles):,}')
    indicadores[1].metric('Pares con ambas notas', f'{len(pares_filtrados):,}')
    indicadores[2].metric('Mediana de Plays', f'{mediana_plays:,.0f}' if mediana_plays is not None else '—')
    indicadores[3].metric('Brecha absoluta media', f'{brecha_absoluta:.2f} pts' if len(pares_filtrados) else '—')

tab_actividad, tab_recepcion, tab_clustering, tab_riesgo = st.tabs([
    'Señales de actividad',
    'Recepción y brecha',
    'Segmentación (Clustering)',
    'Riesgo comercial (GaaS)',
])

# ---------------------------------------------------------------------------
# 2. DISTRIBUCIÓN DE INTERACCIÓN (PLAYS, WISHLIST, BACKLOGS) EN ESCALA LOG
# ---------------------------------------------------------------------------
with tab_actividad:
    section_banner(
        'Distribución de Interacción por Género (Escala Logarítmica)',
        'Plays · Wishlist · Backlogs Desglosados por Taxonomía',
    )

    col_sig, col_top = st.columns([2, 1])
    with col_sig:
        senal_sel = st.radio(
            'Señal de comunidad a visualizar',
            options=['Plays', 'Wishlist', 'Backlogs'],
            horizontal=True,
        )
    with col_top:
        top_n_gen = st.slider('Número de géneros principales', min_value=6, max_value=18, value=12)

    filas_gen = []
    for _, row in filtrado.dropna(subset=[senal_sel]).iterrows():
        val = float(row[senal_sel])
        if val > 0:
            for g in row['generos']:
                filas_gen.append({'Genero': g, senal_sel: val, 'Title': row['Title']})

    if filas_gen:
        df_gen_long = pd.DataFrame(filas_gen)
        orden_gen = (
            df_gen_long.groupby('Genero')[senal_sel]
            .median()
            .sort_values(ascending=False)
            .head(top_n_gen)
            .index.tolist()
        )
        df_gen_top = df_gen_long[df_gen_long['Genero'].isin(orden_gen)]

        fig_box = px.box(
            df_gen_top,
            x=senal_sel,
            y='Genero',
            orientation='h',
            category_orders={'Genero': orden_gen},
            color_discrete_sequence=[PALETA['primary']],
            points='outliers',
            hover_data=['Title'],
        )
        fig_box.update_traces(
            marker=dict(color=PALETA['accent'], size=5, opacity=0.8),
            line=dict(color=PALETA['secondary'], width=1.5),
            fillcolor='rgba(165, 107, 255, 0.75)',
        )
        fig_box.update_xaxes(type='log', title_text=f'{senal_sel} (interacciones, escala logarítmica)')
        fig_box.update_yaxes(autorange='reversed', title_text='Género')
        st.caption('Vistas exploratorias de los juegos filtrados. Los ejes logarítmicos muestran solo conteos positivos (> 0).')
        mostrar_grafica(fig_box, f'Distribución de {senal_sel} por género',
                        alto=max(360, 28 * len(orden_gen) + 80))

        # Comparativa simultánea de medianas log10 de Plays, Wishlist y Backlogs (solo > 0)
        resumen_tres = {senal: [] for senal in ['Plays', 'Wishlist', 'Backlogs']}
        for _, row in filtrado.iterrows():
            for senal in resumen_tres:
                val = row[senal]
                if pd.notna(val) and float(val) > 0:
                    val_f = float(val)
                    for g in row['generos']:
                        if g in orden_gen:
                            resumen_tres[senal].append({'Genero': g, senal: val_f})

        series_med = {
            senal: pd.DataFrame(filas_s).groupby('Genero')[senal].median()
            for senal, filas_s in resumen_tres.items()
            if filas_s
        }
        if series_med:
            df_med = pd.concat(series_med, axis=1).reindex(orden_gen).rename_axis('Genero').reset_index()
            fig_bar_log = go.Figure()
            for senal in ['Plays', 'Backlogs', 'Wishlist']:
                if senal in df_med:
                    fig_bar_log.add_trace(
                        go.Bar(
                            name=senal,
                            x=df_med[senal],
                            y=df_med['Genero'],
                            orientation='h',
                            marker_color=COLOR_SENALES[senal],
                            marker_line_color='#000000',
                            marker_line_width=1.5,
                        )
                    )
            fig_bar_log.update_layout(barmode='group')
            fig_bar_log.update_xaxes(type='log', title_text='Mediana de interacciones positivas (escala logarítmica)')
            fig_bar_log.update_yaxes(categoryorder='array', categoryarray=orden_gen, autorange='reversed', title_text='Género')
            mostrar_grafica(fig_bar_log, 'Medianas de Plays, Backlogs y Wishlist',
                            alto=max(380, 33 * len(orden_gen) + 125))
    else:
        st.info('No hay registros positivos con los filtros actuales para construir la distribución por género.')

    with st.expander('Popularidad por género y organización'):
        st.caption('La tabla muestra grupos con al menos 20 juegos. Para comparar las notas usamos al menos 20 juegos con las dos.')
        nivel_pop = st.radio('Agrupar por', ['Género', 'Organización'], horizontal=True)
        archivo_pop = 'genero' if nivel_pop == 'Género' else 'estudio'
        df_pop = read_report(f'tables/popularidad_{archivo_pop}.csv')
        st.dataframe(
            df_pop,
            hide_index=True,
            width='stretch',
            column_config={
                'grupo': 'Grupo',
                'n_juegos': st.column_config.NumberColumn('Juegos', format='%d'),
                'n_Plays': st.column_config.NumberColumn('n Plays', format='%d'),
                'media_Plays': st.column_config.NumberColumn('Media Plays', format='%.0f'),
                'mediana_Plays': st.column_config.NumberColumn('Mediana Plays', format='%.0f'),
                'n_Playing': st.column_config.NumberColumn('n Playing', format='%d'),
                'media_Playing': st.column_config.NumberColumn('Media Playing', format='%.0f'),
                'mediana_Playing': st.column_config.NumberColumn('Mediana Playing', format='%.0f'),
                'n_Backlogs': st.column_config.NumberColumn('n Backlogs', format='%d'),
                'media_Backlogs': st.column_config.NumberColumn('Media Backlogs', format='%.0f'),
                'mediana_Backlogs': st.column_config.NumberColumn('Mediana Backlogs', format='%.0f'),
                'n_Wishlist': st.column_config.NumberColumn('n Wishlist', format='%d'),
                'media_Wishlist': st.column_config.NumberColumn('Media Wishlist', format='%.0f'),
                'mediana_Wishlist': st.column_config.NumberColumn('Mediana Wishlist', format='%.0f'),
                'n_Rating': st.column_config.NumberColumn('n Rating', format='%d'),
                'media_Rating': st.column_config.NumberColumn('Media Rating', format='%.2f'),
                'mediana_Rating': st.column_config.NumberColumn('Mediana Rating', format='%.2f'),
                'n_Metacritic Rating': st.column_config.NumberColumn('n Metacritic', format='%d'),
                'media_Metacritic Rating': st.column_config.NumberColumn('Media Metacritic', format='%.1f'),
                'mediana_Metacritic Rating': st.column_config.NumberColumn('Mediana Metacritic', format='%.1f'),
                'n': st.column_config.NumberColumn('Pares (n)', format='%d'),
                'pearson_r': st.column_config.NumberColumn('Pearson r', format='%.3f'),
                'pearson_p': st.column_config.NumberColumn('p Pearson', format='%.2e'),
                'spearman_rho': st.column_config.NumberColumn('Spearman ρ', format='%.3f'),
                'spearman_p': st.column_config.NumberColumn('p Spearman', format='%.2e'),
            },
        )

# ---------------------------------------------------------------------------
# 3. DISPERSIÓN / DENSIDAD ENTRE RATING (USUARIOS) Y METACRITIC (PRENSA)
# 4. ANÁLISIS DE LA BRECHA USUARIOS-CRÍTICA POR GÉNERO Y ESTUDIO
# ---------------------------------------------------------------------------
with tab_recepcion:
    section_banner(
        'Recepción: Comunidad (Rating) vs. Prensa (Metacritic)',
        'Diagrama de Dispersión y Densidad Conjunta en Pares Elegibles',
    )

    modo_scatter = st.radio(
        'Modo de visualización conjunta',
        options=['Dispersión + Contornos de Densidad', 'Mapa de Calor 2D (Densidad)', 'Solo Dispersión'],
        horizontal=True,
    )

    juegos_consulta = filtrado
    if len(pares_filtrados):
        if modo_scatter == 'Mapa de Calor 2D (Densidad)':
            fig_sc = px.density_heatmap(
                pares_filtrados,
                x='critica_verificada_csv',
                y='Rating',
                nbinsx=22,
                nbinsy=22,
                color_continuous_scale=[PALETA['bg-primary'], PALETA['bg-chart'], PALETA['primary'], PALETA['secondary'], PALETA['accent'], PALETA['text-primary']],
                labels={
                    'critica_verificada_csv': 'Metacritic Rating (0–100)',
                    'Rating': 'Rating Usuarios Backloggd (0–5)',
                },
            )
        else:
            fig_sc = go.Figure()
            if modo_scatter == 'Dispersión + Contornos de Densidad' and len(pares_filtrados) >= 15:
                fig_sc.add_trace(
                    go.Histogram2dContour(
                        x=pares_filtrados['critica_verificada_csv'],
                        y=pares_filtrados['Rating'],
                        colorscale=[[0, 'rgba(5,13,34,0)'], [0.5, 'rgba(23,13,55,0.55)'], [1, 'rgba(0,207,255,0.65)']],
                        showscale=False,
                        line=dict(color=PALETA['secondary'], width=1),
                        hoverinfo='skip',
                    )
                )
            fig_sc.add_trace(
                go.Scatter(
                    x=pares_filtrados['critica_verificada_csv'],
                    y=pares_filtrados['Rating'],
                    mode='markers',
                    name='Videojuegos',
                    text=pares_filtrados['Title'],
                    customdata=np.stack(
                        [
                            pares_filtrados['anio'].fillna(0).astype(int),
                            pares_filtrados['brecha_vista'].round(1),
                            pares_filtrados['id_juego'],
                        ],
                        axis=-1,
                    ).tolist(),
                    hovertemplate=(
                        '<b>%{text}</b> (%{customdata[0]})<br>'
                        'Metacritic: %{x:.0f} / 100<br>'
                        'Rating Usuarios: %{y:.2f} / 5.0<br>'
                        'Brecha (Rating×20 − Meta): %{customdata[1]:+.1f} pts<extra></extra>'
                    ),
                    marker=dict(
                        color=PALETA['primary'],
                        size=7,
                        opacity=0.82,
                        line=dict(color=PALETA['text-primary'], width=0.8),
                    ),
                )
            )
            # Línea de paridad (Rating * 20 == Metacritic) protegida contra <=1 punto o rango invertido
            if len(pares_filtrados) >= 2:
                x_min = max(20.0, float(pares_filtrados['critica_verificada_csv'].min()))
                x_max = min(100.0, float(pares_filtrados['critica_verificada_csv'].max()))
                if x_max > x_min:
                    x_ref = np.linspace(x_min, x_max, 50)
                    fig_sc.add_trace(
                        go.Scatter(
                            x=x_ref,
                            y=x_ref / 20.0,
                            mode='lines',
                            name='Paridad',
                            line=dict(color=PALETA['accent'], width=2, dash='dash'),
                        )
                    )

        fig_sc.update_xaxes(title_text='Metacritic (0–100)')
        fig_sc.update_yaxes(title_text='Usuarios (0–5)')
        if modo_scatter == 'Mapa de Calor 2D (Densidad)':
            fig_sc.update_coloraxes(colorbar=dict(title='Juegos', thickness=10))
            mostrar_grafica(fig_sc, 'Densidad de calificaciones', alto=430)
        else:
            st.caption('Selecciona puntos, un rectángulo o un lazo para consultar esos juegos en la tabla.')
            huella_pares = hashlib.sha256(pares_filtrados['id_juego'].to_numpy(dtype='int64').tobytes()).hexdigest()[:16]
            revision = int(st.session_state.get('eda_revision_seleccion') or 0)
            seleccion = mostrar_grafica(
                fig_sc, 'Calificaciones de usuarios y prensa', alto=430,
                key=f'recepcion_{modo_scatter}_{huella_pares}_{revision}', on_select='rerun',
                selection_mode=('points', 'box', 'lasso'),
            )
            sel_obj = getattr(seleccion, 'selection', None) or (
                seleccion.get('selection') if isinstance(seleccion, dict) else None
            )
            puntos_sel = (
                sel_obj.get('points', [])
                if isinstance(sel_obj, dict)
                else (getattr(sel_obj, 'points', None) or [])
            )
            ids_seleccion = {
                int(datos[2])
                for punto in puntos_sel
                if isinstance(datos := punto.get('customdata'), (list, tuple)) and len(datos) >= 3
            }
            if ids_seleccion:
                st.button('Quitar selección de la gráfica', on_click=limpiar_seleccion)
                juegos_consulta = filtrado[filtrado['id_juego'].isin(ids_seleccion)]
    else:
        st.info('No hay pares completos de Rating y Metacritic bajo los filtros seleccionados.')

    st.subheader('Juegos de la consulta')
    cantidad = len(juegos_consulta)
    resultado = 'juego' if cantidad == 1 else 'juegos'
    st.caption(f'{cantidad:,} {resultado} en la tabla. La selección del gráfico acota esta consulta y su CSV.')
    columnas = ['Title', 'anio', 'Rating', 'critica_verificada_csv', 'brecha_vista', 'Plays', 'Backlogs', 'Wishlist']
    consulta = juegos_consulta[columnas].rename(columns={
        'Title': 'Juego', 'anio': 'Año', 'Rating': 'Usuarios', 'critica_verificada_csv': 'Metacritic',
        'brecha_vista': 'Brecha (pts)',
    })
    st.dataframe(
        consulta,
        hide_index=True,
        width='stretch',
        height=300,
        column_config={
            'Juego': 'Juego',
            'Año': st.column_config.NumberColumn('Año', format='%d'),
            'Usuarios': st.column_config.NumberColumn('Usuarios (0–5)', format='%.2f'),
            'Metacritic': st.column_config.NumberColumn('Metacritic (0–100)', format='%d'),
            'Brecha (pts)': st.column_config.NumberColumn('Brecha (pts)', format='%+.1f'),
            'Plays': st.column_config.NumberColumn('Plays', format='%d'),
            'Backlogs': st.column_config.NumberColumn('Backlogs', format='%d'),
            'Wishlist': st.column_config.NumberColumn('Wishlist', format='%d'),
        },
    )
    st.download_button(
        'Descargar juegos de la consulta',
        consulta.to_csv(index=False).encode('utf-8'),
        'consulta_dashboard.csv',
        'text/csv',
        disabled=consulta.empty,
    )

    section_banner(
        'Análisis de la Brecha Usuarios–Crítica',
        'Compara la nota de usuarios con la de prensa por género u organización',
    )

    st.caption('Para esta comparación usamos los juegos que tienen las dos notas.')
    st.write(
        'Primero multiplicamos la nota de usuarios por 20 para llevarla a la escala de 100. '
        'Luego restamos la nota de prensa. Si el resultado sale negativo, la prensa dio más puntos. '
        'La diferencia absoluta nos dice qué tan lejos quedaron las dos notas.'
    )

    dim_brecha = st.radio(
        'Desglosar brecha y correlación por:',
        options=['Género', 'Estudio / Organización (Team)'],
        horizontal=True,
    )

    archivo_corr = (
        'tables/correlacion_generos.csv'
        if dim_brecha == 'Género'
        else 'tables/correlacion_organizaciones.csv'
    )
    if dim_brecha != 'Género':
        st.caption(
            'El campo `Team` de Backloggd reúne estudios y editoras. '
            'Aquí aparecen las organizaciones con al menos 20 juegos con ambas notas.'
        )

    df_brecha = read_report(archivo_corr).query('estado == "incluido"').copy()
    metrica_orden = st.selectbox(
        'Métrica de desacuerdo a graficar',
        options=['brecha_absoluta_media', 'brecha_media'],
        format_func=lambda m: (
            'Brecha absoluta media'
            if m == 'brecha_absoluta_media'
            else 'Brecha media con signo'
        ),
    )

    df_plot_b = df_brecha.sort_values(metrica_orden, ascending=True)
    grupos_top_abs = set(df_brecha.loc[df_brecha[metrica_orden].abs().nlargest(3).index, 'grupo'])
    colores_brecha = [
        PALETA['accent'] if grupo in grupos_top_abs else PALETA['primary']
        for grupo in df_plot_b['grupo']
    ]

    fig_gap = go.Figure(
        go.Bar(
            x=df_plot_b[metrica_orden],
            y=df_plot_b['grupo'],
            orientation='h',
            marker=dict(color=colores_brecha, line=dict(color=PALETA['text-primary'], width=1)),
            customdata=np.stack(
                [
                    df_plot_b['n'],
                    df_plot_b['pearson_r'].round(3),
                    df_plot_b['spearman_rho'].round(3),
                ],
                axis=-1,
            ),
            hovertemplate=(
                '<b>%{y}</b> (n = %{customdata[0]})<br>'
                'Valor brecha: %{x:.2f} pts<br>'
                'Pearson r: %{customdata[1]} · Spearman ρ: %{customdata[2]}<extra></extra>'
            ),
        )
    )
    etiquetas_grupos = [wrap(grupo, width=16) for grupo in df_plot_b['grupo']]
    fig_gap.update_xaxes(title_text='Brecha (pts)')
    fig_gap.update_yaxes(title_text=dim_brecha, tickmode='array', tickvals=df_plot_b['grupo'],
                         ticktext=['<br>'.join(lineas) for lineas in etiquetas_grupos])
    alto_por_grupo = max(32, 14 * max(map(len, etiquetas_grupos), default=1) + 8)
    titulo_brecha = 'Brecha por género' if dim_brecha == 'Género' else 'Brecha por organización'
    st.caption('En dorado aparecen los tres grupos con la mayor diferencia entre notas.')
    mostrar_grafica(fig_gap, titulo_brecha, alto=max(420, len(df_plot_b) * alto_por_grupo + 60))

    configuracion_corr = {
        'grupo': 'Grupo',
        'n': st.column_config.NumberColumn('Pares (n)', format='%d'),
        'brecha_absoluta_media': st.column_config.NumberColumn('Brecha |Δ| media (pts)', format='%.2f'),
        'brecha_media': st.column_config.NumberColumn('Brecha media (pts)', format='%+.2f'),
        'pearson_r': st.column_config.NumberColumn('Pearson r', format='%.3f'),
        'spearman_rho': st.column_config.NumberColumn('Spearman ρ', format='%.3f'),
        'pearson_p': st.column_config.NumberColumn('p Pearson', format='%.2e'),
        'spearman_p': st.column_config.NumberColumn('p Spearman', format='%.2e'),
        'pearson_q_bh': st.column_config.NumberColumn('q BH Pearson', format='%.2e'),
        'spearman_q_bh': st.column_config.NumberColumn('q BH Spearman', format='%.2e'),
    }

    with st.expander('Análisis complementario de correlaciones y corrección por comparaciones múltiples'):
        correlacion = read_report('tables/correlacion_catalogo.csv').iloc[0]
        st.caption(
            f'Catálogo elegible completo: Pearson r = {correlacion["pearson_r"]:.3f}, '
            f'Spearman ρ = {correlacion["spearman_rho"]:.3f} ({int(correlacion["n"]):,} pares). '
            'La comparación por grupo usa este mismo alcance.'
        )
        columnas_tabla = [
            'grupo',
            'n',
            'brecha_absoluta_media',
            'brecha_media',
            'pearson_r',
            'pearson_p',
            'pearson_q_bh',
            'spearman_rho',
            'spearman_p',
            'spearman_q_bh',
        ]
        st.dataframe(
            df_brecha[columnas_tabla],
            hide_index=True,
            width='stretch',
            column_config=configuracion_corr,
        )
        nombre_descarga_corr = (
            'correlacion_generos.csv' if dim_brecha == 'Género' else 'correlacion_organizaciones.csv'
        )
        st.download_button(
            'Descargar tabla de correlaciones y brechas (CSV)',
            df_brecha.to_csv(index=False).encode('utf-8'),
            nombre_descarga_corr,
            'text/csv',
        )

# ---------------------------------------------------------------------------
# 5. SEGMENTACIÓN NO SUPERVISADA (CLUSTERING K-MEANS, WARD Y DBSCAN — FASE 4A)
# ---------------------------------------------------------------------------
with tab_clustering:
    section_banner(
        'Grupos de juegos con actividad y notas parecidas',
        'Exploración · K-Means, agrupamiento jerárquico de Ward y DBSCAN',
    )

    hash_clusters = hashlib.sha256((CLEAN / 'dataset_con_clusters.csv').read_bytes()).hexdigest()
    profiles = _cargar_perfiles_clusters(hash_clusters)
    metodo = st.radio('Método de agrupamiento', ['K-Means', 'Ward', 'DBSCAN'], horizontal=True)
    metricas_clusters = read_report('tables/metricas_clusters.csv')
    parametros = read_report('tables/parametros_clustering.csv').iloc[0]
    comparacion = metricas_clusters.loc[
        ((metricas_clusters.metodo == 'K-Means') & metricas_clusters.k.eq(parametros.kmeans_k))
        | ((metricas_clusters.metodo == 'Ward') & metricas_clusters.silhouette.eq(
            metricas_clusters.loc[metricas_clusters.metodo.eq('Ward'), 'silhouette'].max()))
        | ((metricas_clusters.metodo == 'DBSCAN') & metricas_clusters.factor_eps.eq(1)),
        ['metodo', 'k', 'n_evaluado', 'ruido', 'silhouette', 'davies_bouldin', 'calinski_harabasz'],
    ]
    st.caption('Comparación informativa. K-Means y Ward se eligen por silueta. DBSCAN ajusta eps y puede marcar ruido. Los índices requieren dos grupos y excluyen los puntos de ruido.')
    st.dataframe(
        comparacion,
        hide_index=True,
        width='stretch',
        column_config={
            'metodo': 'Método',
            'k': st.column_config.NumberColumn('Grupos', format='%d'),
            'n_evaluado': st.column_config.NumberColumn('Evaluados (n)', format='%d'),
            'ruido': st.column_config.NumberColumn('Ruido', format='%d'),
            'silhouette': st.column_config.NumberColumn('Silueta ↑', format='%.3f'),
            'davies_bouldin': st.column_config.NumberColumn('Davies–Bouldin ↓', format='%.3f'),
            'calinski_harabasz': st.column_config.NumberColumn('Calinski–Harabasz ↑', format='%.1f'),
        },
    )

    agrupados = profiles[profiles.incluido_clustering & profiles['id_juego'].isin(filtrado['id_juego'])].copy()
    if metodo == 'Ward':
        asignaciones = read_report('tables/clase_ward_asignaciones.csv')
        agrupados = agrupados.merge(asignaciones, on='id_juego', validate='one_to_one')
        columna = 'cluster_ward'
        arbol = json.loads((REPORTS / 'clase_ward_dendrograma.json').read_text(encoding='utf-8'))
        figura_ward = go.Figure()
        for x, y in zip(arbol['x'], arbol['y']):
            figura_ward.add_trace(go.Scatter(x=x, y=y, mode='lines', line=dict(color=PALETA['primary']),
                                             showlegend=False, hovertemplate='Distancia %{y:.2f}<extra></extra>'))
        figura_ward.update_xaxes(tickmode='array', tickvals=[5 + 10 * i for i in range(len(arbol['hojas']))],
                                 ticktext=arbol['hojas'], tickangle=-45, title_text='Ramas resumidas')
        figura_ward.update_yaxes(title_text='Distancia de Ward')
        mostrar_grafica(figura_ward, 'Dendrograma de Ward', alto=360)
        st.caption('Vista de las 12 últimas ramas del ajuste completo. Los paréntesis indican cuántos juegos resume cada rama.')
    else:
        columna = 'cluster_dbscan' if metodo == 'DBSCAN' else 'cluster_kmeans'

    resumen = read_report('tables/perfiles_clusters.csv').loc[lambda t: t.metodo.eq(metodo)]
    if metodo == 'DBSCAN':
        st.caption(f'Con eps={parametros.dbscan_eps:.4f} y min_samples={parametros.dbscan_min_samples}, '
                   f'grupos detectados: {parametros.dbscan_clusters}. Juegos marcados como ruido: {parametros.dbscan_ruido}.')
    st.caption('La tabla resume cada grupo completo. El mapa muestra los juegos que quedan al aplicar los filtros.')
    st.dataframe(
        resumen,
        hide_index=True,
        width='stretch',
        column_config={
            'metodo': 'Método',
            'cluster': st.column_config.NumberColumn('Grupo', format='%d'),
            'n': st.column_config.NumberColumn('Juegos (n)', format='%d'),
            'perfil_propuesto': 'Perfil interpretado',
            'generos_dominantes': 'Géneros dominantes',
            'media_Plays': st.column_config.NumberColumn('Media Plays', format='%.0f'),
            'media_Playing': st.column_config.NumberColumn('Media Playing', format='%.0f'),
            'media_Backlogs': st.column_config.NumberColumn('Media Backlogs', format='%.0f'),
            'media_Wishlist': st.column_config.NumberColumn('Media Wishlist', format='%.0f'),
            'media_Rating': st.column_config.NumberColumn('Media Rating', format='%.2f'),
            'media_Metacritic Rating': st.column_config.NumberColumn('Media Metacritic', format='%.1f'),
            'juegos_ejemplo': 'Ejemplos representativos',
        },
    )

    if agrupados.empty:
        st.info('La consulta no contiene juegos con coordenadas PCA.')
    else:
        agrupados['perfil'] = agrupados[columna].astype(int).map(lambda x: 'Ruido' if x == -1 else f'Grupo {x}')
        fig_pca = px.scatter(
            agrupados,
            x='componente_1',
            y='componente_2',
            color='perfil',
            symbol='perfil',
            hover_name='Title',
            hover_data=['Release Date', 'Rating', 'Metacritic Rating', 'Plays'],
            color_discrete_map={'Grupo 0': PALETA['primary'], 'Grupo 1': PALETA['accent'], 'Ruido': PALETA['secondary']},
            symbol_map={'Grupo 0': 'circle', 'Grupo 1': 'diamond', 'Ruido': 'x'},
            labels={
                'componente_1': 'Componente principal 1 (sin unidad)',
                'componente_2': 'Componente principal 2 (sin unidad)',
                'perfil': 'Grupo',
            },
        )
        fig_pca.update_traces(marker=dict(size=7, opacity=0.85, line=dict(width=0.7, color='#000000')))
        mostrar_grafica(fig_pca, f'PCA · {metodo} · {parametros.pca_varianza_total:.1%} de varianza explicada', alto=430)

    with st.expander('Selección de grupos y comparación de K-Means con Weka'):
        st.markdown('**Comparación de alternativas k=2, k=3 y k=4:**')
        st.dataframe(
            read_report('tables/clustering_03_alternativas_k.csv'),
            hide_index=True,
            width='stretch',
            column_config={
                'metodo': 'Método',
                'cluster': st.column_config.NumberColumn('Grupo', format='%d'),
                'n': st.column_config.NumberColumn('Juegos (n)', format='%d'),
                'perfil_propuesto': 'Perfil interpretado',
                'generos_dominantes': 'Géneros dominantes',
                'media_Plays': st.column_config.NumberColumn('Media Plays', format='%.0f'),
                'media_Playing': st.column_config.NumberColumn('Media Playing', format='%.0f'),
                'media_Backlogs': st.column_config.NumberColumn('Media Backlogs', format='%.0f'),
                'media_Wishlist': st.column_config.NumberColumn('Media Wishlist', format='%.0f'),
                'media_Rating': st.column_config.NumberColumn('Media Rating', format='%.2f'),
                'media_Metacritic Rating': st.column_config.NumberColumn('Media Metacritic', format='%.1f'),
            },
        )
        st.markdown('**Búsqueda de parámetros:**')
        st.dataframe(
            metricas_clusters.loc[metricas_clusters.metodo.eq(metodo)].dropna(axis=1, how='all'),
            hide_index=True,
            width='stretch',
            column_config={
                'metodo': 'Método',
                'k': st.column_config.NumberColumn('Grupos', format='%d'),
                'n_evaluado': st.column_config.NumberColumn('Evaluados (n)', format='%d'),
                'ruido': st.column_config.NumberColumn('Ruido', format='%d'),
                'silhouette': st.column_config.NumberColumn('Silueta', format='%.3f'),
                'davies_bouldin': st.column_config.NumberColumn('Davies–Bouldin', format='%.3f'),
                'calinski_harabasz': st.column_config.NumberColumn('Calinski–Harabasz', format='%.1f'),
                'inercia': st.column_config.NumberColumn('Inercia', format='%.1f'),
                'factor_eps': st.column_config.NumberColumn('Factor eps', format='%.2f'),
                'eps': st.column_config.NumberColumn('eps', format='%.4f'),
                'min_samples': st.column_config.NumberColumn('Min. muestras', format='%d'),
            },
        )
        st.markdown('**BIC de mezclas gaussianas · menor es mejor:**')
        st.dataframe(
            read_report('tables/bic_gmm.csv'),
            hide_index=True,
            width='stretch',
            column_config={
                'k': st.column_config.NumberColumn('Componentes (k)', format='%d'),
                'bic': st.column_config.NumberColumn('BIC', format='%.1f'),
                'convergio': st.column_config.CheckboxColumn('Convergió'),
            },
        )
        try:
            st.markdown('**Comparación reproducible contra Weka 3.8.6:**')
            st.dataframe(
                read_report('tables/weka_clustering_cli.csv'),
                hide_index=True,
                width='stretch',
                column_config={
                    'k': st.column_config.NumberColumn('k', format='%d'),
                    'herramienta': 'Herramienta',
                    'n': st.column_config.NumberColumn('Evaluados (n)', format='%d'),
                    'silhouette': st.column_config.NumberColumn('Silueta', format='%.3f'),
                    'inercia_comun': st.column_config.NumberColumn('Inercia común', format='%.1f'),
                    'ARI_weka_python': st.column_config.NumberColumn('ARI Weka vs Python', format='%.3f'),
                    'tamanos': 'Tamaños',
                },
            )
        except FileNotFoundError:
            st.info('Reporte de Weka no encontrado en este entorno.')

# ---------------------------------------------------------------------------
# 6. EVIDENCIA COMERCIAL COMPLEMENTARIA (JUEGOS COMO SERVICIO / GaaS)
# ---------------------------------------------------------------------------
with tab_riesgo:
    section_banner(
        'Riesgo Comercial y Juegos como Servicio (GaaS)',
        'Casos Documentados por Editoras Públicas',
    )
    st.write('Elige un juego para ver qué pasó y consultar la fuente.')
    casos = read_report('tables/evidencia_comercial.csv').fillna('')
    caso = st.selectbox('Consultar un caso', casos['juego'])
    evidencia = casos.loc[casos.juego.eq(caso)].iloc[0]
    st.markdown(f'**{evidencia.indicador}**')
    st.write(evidencia.evidencia)
    fuentes = [f'[{evidencia.fuente}]({evidencia.url})']
    if evidencia.url_contexto:
        fuentes.append(f'[{evidencia.fuente_contexto}]({evidencia.url_contexto})')
    st.markdown(' · '.join(fuentes))
    st.caption('Para comparar el riesgo por género se necesitan ingresos y costos por juego en un plazo '
               'común, así como lanzamientos comparables en presupuesto, plataforma, año y tamaño del estudio.')

````

## 2_Prediccion.py

Ruta: `Final/pages/2_Prediccion.py` · Bytes: 16457 · SHA-256: `5fa1a1715df68c9fc35769e8e7016d941fb570e4a85341b93596fe9f5fa6d972`

````text
"""Predicción de popularidad y juegos parecidos."""
import html
import importlib
import sys
import numpy as np
import pandas as pd
import streamlit as st

import src.data as _data

if getattr(_data, '_MOD_VERSION', None) != 'p5-v11-arte':
    if 'src.config' in sys.modules:
        importlib.reload(sys.modules['src.config'])
    _data = importlib.reload(_data)
    _data.asegurar_modulos_vigentes(config_recargado=True)
else:
    _data.asegurar_modulos_vigentes()

from src.similitud import cinco_vecinos
from src.inferencia import predecir_formulario
from src.lectura_prediccion import concluir_prediccion
from src.portadas import PORTADAS_LOCALES, buscar_portadas
from src.ui import (
    _p5_ascii,
    asset_b64,
    read_report,
    render_html,
    render_lb_rb_nav,
    resources,
    section_banner,
    setup,
)

portadas_en_cache = st.cache_data(ttl=3600, max_entries=128, show_spinner=False)(buscar_portadas)

setup(
    'Predicción de popularidad',
    'Prueba cómo cambia el nivel al modificar los datos de un juego.',
    transition='resume',
    menu_idx=2,
    compact_menu=True,
)

df, bundle, analysis = resources()
render_lb_rb_nav('MENÚ DE BATALLA // PREDICCIÓN')
pipeline = bundle['pipeline']
metricas = bundle['metricas']

# Taxonomía aprendida por el preprocesador en entrenamiento
prep = pipeline.named_steps['preparar']
taxonomia_generos = sorted(prep.named_transformers_['generos'].vocabulario_)
estudios_frecuentes = sorted(prep.named_transformers_['estudio'].vocabulario_)
opciones_estudio = ['Otro / Organización no frecuente', *estudios_frecuentes]
decadas_modelo = [int(x) for x in prep.named_transformers_['decada'].named_steps['codificar'].categories_[0]]
opciones_decada = [*sorted(d for d in decadas_modelo if d >= 0), *([-1] if -1 in decadas_modelo else [])]
indice_decada_defecto = opciones_decada.index(2020) if 2020 in opciones_decada else 0

section_banner('Datos del lanzamiento', 'Elige los géneros, la organización, la década y las notas')

with st.form('p5_battle_inference_form'):
    col_f1, col_f2 = st.columns(2)
    with col_f1:
        generos_seleccionados = st.multiselect(
            'Géneros del videojuego',
            options=taxonomia_generos,
            default=['Adventure', 'RPG'] if 'Adventure' in taxonomia_generos and 'RPG' in taxonomia_generos else taxonomia_generos[:1],
            help='Puedes elegir más de un género.',
        )
        estudio_seleccionado = st.selectbox(
            'Estudio o editora',
            options=opciones_estudio,
            index=0,
            help='Si la organización que buscas no aparece, elige «Otro».',
        )
        decada_seleccionada = st.selectbox(
            'Década de lanzamiento',
            options=opciones_decada,
            index=indice_decada_defecto,
            format_func=lambda d: 'Sin fecha interpretable (Década -1)' if d == -1 else f'Década de {d}s',
        )

    with col_f2:
        metacritic_esperado = st.slider(
            'Nota de prensa esperada (0 a 100)',
            min_value=0,
            max_value=100,
            value=82,
            step=1,
        )
        rating_esperado = st.slider(
            'Nota de usuarios esperada (0 a 5)',
            min_value=0.0,
            max_value=5.0,
            value=3.9,
            step=0.1,
        )
        sin_metacritic = st.checkbox(
            'Probar sin nota de prensa',
            value=False,
        )

    submitted = st.form_submit_button('⚔️ ANALIZAR LANZAMIENTO')

# Validación de al menos un género seleccionado
if not generos_seleccionados:
    st.warning(
        'Elige al menos un género para calcular el nivel de popularidad.'
    )
else:
    estudio_valor = (
        ['Otro']
        if estudio_seleccionado == 'Otro / Organización no frecuente'
        else [estudio_seleccionado]
    )
    meta_valor = np.nan if sin_metacritic else float(metacritic_esperado)

    fila, prediccion, mapa_probs = predecir_formulario(
        pipeline, generos_seleccionados, estudio_valor, decada_seleccionada,
        meta_valor, rating_esperado,
        temperatura=metricas['calibracion_web']['temperatura'],
    )

    # Vecinos más cercanos en el espacio predictivo de entrenamiento
    vecinos = cinco_vecinos(fila, pipeline, vecinos=bundle['vecinos'])
    meta_df = df[['id_juego', 'anio', 'generos', 'organizaciones', 'popularidad_indice']].copy()
    meta_df['generos_texto'] = meta_df['generos'].map(lambda gs: ', '.join(gs))
    vecinos = vecinos.merge(
        meta_df[['id_juego', 'anio', 'generos_texto', 'organizaciones', 'popularidad_indice']],
        on='id_juego',
        how='left',
    )

    # -----------------------------------------------------------------------
    # 2. RESULTADOS DE LA INFERENCIA
    # -----------------------------------------------------------------------
    section_banner('Resultado de la predicción', f'Modelo Activo: {metricas["modelo"]}')

    st.subheader(f'Nivel estimado de popularidad: {prediccion.upper()}')
    if sin_metacritic:
        st.warning(
            'Para este ejemplo usamos la nota de prensa que queda en medio al ordenar las del entrenamiento. '
            'Si luego ingresas la nota real, el resultado puede cambiar.'
        )

    col_r1, col_r2 = st.columns([1.25, 1])

    with col_r1:
        render_html(
            '<div class="p5-font" style="font-size:1.25rem;color:var(--accent);margin-bottom:0.6rem;">'
            'PROBABILIDAD CALIBRADA POR NIVEL</div>'
        )
        barras_html = ''
        for nivel_key, etiqueta in [('alto', 'ALTO'), ('medio', 'MEDIO'), ('bajo', 'BAJO')]:
            pct = mapa_probs.get(nivel_key, 0.0) * 100.0
            destacado = 'color:var(--primary);font-weight:900;' if nivel_key == prediccion else 'color:var(--text-primary);'
            barras_html += f"""
<div class="p5-prob-row">
<div class="p5-prob-header" style="{destacado}">
<span>{etiqueta}</span>
<span>{pct:.1f}%</span>
</div>
<div class="p5-prob-track">
<div class="p5-prob-fill" style="width:{pct:.4f}%;"></div>
</div>
</div>
"""
        render_html(f'<div class="p5-card">{barras_html}</div>')
        st.caption(
            'La barra más larga indica el nivel que estima el modelo. Los porcentajes '
            'se ajustaron con predicciones de juegos de entrenamiento que quedaron fuera de cada pliegue.'
        )
        with st.expander('¿Qué significan alto, medio y bajo?'):
            corte_bajo, corte_alto = metricas['definicion_objetivo']['cortes']
            st.markdown(
                'Los niveles se definen con un índice de 0 a 1. Para calcularlo se compara '
                'cada juego con los del entrenamiento en partidas registradas, pendientes y '
                'listas de deseos. Después se promedian las tres posiciones relativas.'
            )
            st.markdown(
                f'- **Alto.** Índice por encima de {corte_alto:.4f}.\n'
                f'- **Medio.** Índice mayor que {corte_bajo:.4f} y hasta {corte_alto:.4f}.\n'
                f'- **Bajo.** Índice hasta {corte_bajo:.4f}.'
            )
            st.caption('Los cortes se muestran redondeados. Las barras estiman la probabilidad de caer en cada nivel.')

    with col_r2:
        # 2. Perfil de mercado (Cluster asignado por contexto de vecinos K-Means)
        clusters_validos = vecinos['cluster_kmeans'].dropna().astype(int)
        perfiles_tabla = read_report('tables/perfiles_clusters.csv').query('metodo == "K-Means"')
        if len(clusters_validos):
            cluster_modal = int(clusters_validos.mode().iloc[0])
            fila_perfil = perfiles_tabla[perfiles_tabla['cluster'].astype(int) == cluster_modal]
            desc_perfil = (
                fila_perfil.iloc[0]['perfil_propuesto']
                if len(fila_perfil)
                else 'Perfil intermedio del catálogo'
            )
            etiqueta_perfil = f'Grupo K-Means {cluster_modal}'
        else:
            cluster_modal = -1
            desc_perfil = 'Sin cluster K-Means asignado en vecinos con crítica completa'
            etiqueta_perfil = 'Perfil en evaluación'

        # 3. Brecha típica contextual del género principal seleccionado
        genero_principal = generos_seleccionados[0]
        genero_html = html.escape(str(genero_principal), quote=True)
        desc_perfil_html = html.escape(str(desc_perfil), quote=True)
        etiqueta_perfil_html = html.escape(str(etiqueta_perfil), quote=True)
        tabla_gen_corr = read_report('tables/correlacion_generos.csv')
        fila_gen = tabla_gen_corr[tabla_gen_corr['grupo'] == genero_principal]
        if (
            len(fila_gen)
            and fila_gen.iloc[0].get('estado') == 'incluido'
            and pd.notna(fila_gen.iloc[0]['brecha_absoluta_media'])
        ):
            brecha_abs_gen = float(fila_gen.iloc[0]['brecha_absoluta_media'])
            brecha_med_gen = float(fila_gen.iloc[0]['brecha_media'])
            n_gen = int(fila_gen.iloc[0]['n'])
            texto_brecha = (
                f'En <strong>{genero_html}</strong> ({n_gen} juegos con las dos notas), '
                f'la brecha absoluta media es <strong>{brecha_abs_gen:.2f} pts</strong> sobre 100 '
                f'(brecha media con signo: <strong>{brecha_med_gen:+.2f} pts</strong>).'
            )
        else:
            n_info = f' (n = {int(fila_gen.iloc[0]["n"])} pares)' if len(fila_gen) else ''
            texto_brecha = (
                f'Para <strong>{genero_html}</strong>{n_info} hacen falta al menos 20 juegos con ambas notas '
                'para calcular la diferencia media.'
            )

        brecha_usuario_input = (
            f'{(rating_esperado * 20.0 - metacritic_esperado):+.1f} pts'
            if not sin_metacritic
            else 'N/D (Metacritic ausente)'
        )

        render_html(
            f"""
            <div class="p5-card">
                <div class="p5-font" style="font-size:1.2rem;color:var(--accent);margin-bottom:0.4rem;">
                    GRUPO DE JUEGOS PARECIDOS
                </div>
                <div style="font-family:'ComicProyecto',sans-serif;font-size:1.5rem;color:var(--text-primary);">
                    {etiqueta_perfil_html}
                </div>
                <p style="font-size:0.9rem;color:#dddddd;margin:0.25rem 0 0.9rem 0;">
                    {desc_perfil_html}. Este grupo es el más común entre los juegos parecidos que aparecen abajo.
                </p>
                <hr style="border-color:var(--primary);margin:0.65rem 0;"/>
                <div class="p5-font" style="font-size:1.2rem;color:var(--accent);margin-bottom:0.4rem;">
                    DIFERENCIA ENTRE NOTAS ({html.escape(_p5_ascii(genero_principal).upper(), quote=True)})
                </div>
                <p style="font-size:0.92rem;color:#f0f0f0;margin:0;">
                    {texto_brecha}<br/>
                    <span style="color:var(--accent);">Diferencia con las notas que elegiste: <strong>{brecha_usuario_input}</strong></span>
                </p>
            </div>
            """
        )

    st.subheader('Conclusión de esta consulta')
    notas_medias = prep.named_transformers_['notas'].named_steps['imputar'].statistics_
    lectura, contexto = concluir_prediccion(fila.iloc[0], prediccion, mapa_probs, notas_medias[0])
    st.markdown(lectura)
    st.markdown(html.escape(contexto))
    st.caption('El resultado estima la actividad y el interés relativos en Backloggd.')

    section_banner(
        'Cinco juegos parecidos',
        'Son juegos del catálogo con datos parecidos a los que elegiste.',
    )

    tabla_vecinos = vecinos[
        ['id_juego', 'Title', 'anio', 'generos_texto', 'organizaciones', 'cluster_kmeans', 'distancia']
    ].copy()
    tabla_vecinos['anio'] = tabla_vecinos['anio'].fillna(0).astype(int)
    tabla_vecinos['cluster_kmeans'] = tabla_vecinos['cluster_kmeans'].map(
        lambda v: 'Sin cluster (sin crítica CSV)' if pd.isna(v) else f'Cluster {int(v)}'
    )

    pendientes = tuple(sorted({
        (r.Title, int(r.anio)) for r in tabla_vecinos.itertuples(index=False)
        if r.Title not in PORTADAS_LOCALES and r.anio
    }))
    portadas = portadas_en_cache(pendientes) if pendientes else {}
    vecinos_bars_html = ''
    for idx_v, row_v in tabla_vecinos.reset_index(drop=True).iterrows():
        act_cls = 'active' if idx_v == 0 else ''
        titulo = row_v['Title']
        archivo = PORTADAS_LOCALES.get(titulo)
        arte_local = asset_b64(f'img/juegos/{archivo}.webp') if archivo else ''
        arte_steam = portadas.get((titulo, int(row_v['anio'])))
        if arte_local or arte_steam:
            formato = 'webp' if arte_local else 'jpeg'
            imagen = (
                f'<figure class="sc-vecino-arte">'
                f'<img src="data:image/{formato};base64,{arte_local or arte_steam}" alt=""/></figure>'
            )
        else:
            organizaciones = row_v['organizaciones']
            nombre = ' · '.join(organizaciones) if isinstance(organizaciones, list) else ''
            imagen = (
                '<div class="sc-vecino-arte sc-vecino-organizacion">'
                f'<small>{"Organización del catálogo" if nombre else "Arte del juego"}</small>'
                f'<strong>{html.escape(nombre or "Portada no disponible")}</strong></div>'
            )
        titulo_v = html.escape(_p5_ascii(row_v['Title']), quote=True)
        generos_v = html.escape(str(row_v['generos_texto']), quote=True)
        cluster_v = html.escape(str(row_v['cluster_kmeans']), quote=True)
        anio_v = 'N/D' if int(row_v['anio']) == 0 else str(int(row_v['anio']))
        vecinos_bars_html += f"""
        <div class="sc-bar-outer {act_cls}">
            <div class="sc-bar-red"></div>
            <div class="sc-bar">
                <div class="sc-bar-fill"></div>
                <div class="sc-bar-shade"></div>
                <div class="sc-bar-content">
                    {imagen}
                    <div class="sc-main">
                        <div class="sc-label">{titulo_v}</div>
                        <div class="sc-subdesc">
                            Géneros: {generos_v} · {cluster_v}
                        </div>
                    </div>
                    <div class="sc-stats">
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--primary);border-color:var(--primary);">AÑO</span>
                                <span class="sc-stat-num">{anio_v}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--primary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                        <div class="sc-stat">
                            <div class="sc-stat-top">
                                <span class="sc-stat-tag" style="color:var(--secondary);border-color:var(--secondary);">DIST.</span>
                                <span class="sc-stat-num">{row_v['distancia']:.2f}</span>
                            </div>
                            <div class="sc-stat-bars">
                                <div class="sc-stat-bar-color" style="background:var(--secondary);"></div>
                                <div class="sc-stat-bar-black"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        """
    render_html(f'<div class="sc-root">{vecinos_bars_html}</div>')

    st.dataframe(
        tabla_vecinos,
        hide_index=True,
        width='stretch',
        column_order=['Title', 'anio', 'generos_texto', 'cluster_kmeans', 'distancia'],
        column_config={
            'Title': 'Videojuego',
            'anio': st.column_config.NumberColumn('Año', format='%d'),
            'generos_texto': 'Géneros',
            'cluster_kmeans': 'Perfil K-Means (Descriptivo)',
            'distancia': st.column_config.NumberColumn('Distancia Euclídea', format='%.3f'),
        },
    )

    render_html(
        """
        <div class="p5-legal-footer">
            La estimación se basa en la actividad registrada en Backloggd.
        </div>
        """
    )

````

## 3_Acerca_del_modelo.py

Ruta: `Final/pages/3_Acerca_del_modelo.py` · Bytes: 17227 · SHA-256: `b311432cc47a4bd91624317ab34746c0f62c0835e5d6292db082b896799481e6`

````text
"""Página 3 — Acerca del Modelo: Métricas, Comparación de Algoritmos, Matriz de Confusión e Importancia."""
import html
import importlib
import sys
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import src.data as _data

if getattr(_data, '_MOD_VERSION', None) != 'p5-v11-arte':
    if 'src.config' in sys.modules:
        importlib.reload(sys.modules['src.config'])
    _data = importlib.reload(_data)
    _data.asegurar_modulos_vigentes(config_recargado=True)
else:
    _data.asegurar_modulos_vigentes()

from src.visualizacion import PALETA

from vista_graficas import mostrar_grafica
from src.ui import (
    asset_b64,
    read_report,
    render_html,
    render_lb_rb_nav,
    resources,
    section_banner,
    setup,
)

setup(
    'Cómo salió el modelo',
    'Compara los modelos y revisa en qué niveles se equivocaron.',
    transition='default',
    menu_idx=3,
    compact_menu=True,
)

df, bundle, analysis = resources()
render_lb_rb_nav('RESULTADOS DEL MODELO')
metricas = bundle['metricas']
resumen_m = metricas['metricas']

# ---------------------------------------------------------------------------
# 1. KPIs DINÁMICOS DESDE models/metadata.json
# ---------------------------------------------------------------------------
section_banner('Ficha del modelo activo', metricas['modelo'])

render_html(
    f"""
    <div class="p5-kpi-grid">
        <div class="p5-kpi-card">
            <div class="p5-kpi-label">Modelo Activo</div>
            <div class="p5-kpi-value" style="font-size:1.75rem;">{metricas['modelo']}</div>
            <div class="p5-kpi-note">scikit-learn {metricas['version_sklearn']} · Semilla {metricas['semilla']}</div>
        </div>
        <div class="p5-kpi-card">
            <div class="p5-kpi-label">F1 Macro (Prueba)</div>
            <div class="p5-kpi-value">{resumen_m['f1_macro']:.4f}</div>
            <div class="p5-kpi-note">CV externa 10 × 5: {resumen_m['f1_macro_cv']:.4f} (Base Dummy: {resumen_m['f1_macro_referencia']:.4f})</div>
        </div>
        <div class="p5-kpi-card">
            <div class="p5-kpi-label">Exactitud / Bal. Acc</div>
            <div class="p5-kpi-value">{resumen_m['exactitud']:.1%} / {resumen_m['balanced_accuracy']:.1%}</div>
            <div class="p5-kpi-note">Juegos de entrenamiento: {metricas['n_entrenamiento']} · Juegos de prueba: {metricas['n_prueba']}</div>
        </div>
        <div class="p5-kpi-card">
            <div class="p5-kpi-label">Niveles de popularidad</div>
            <div class="p5-kpi-value" style="font-size:1.45rem;">Bajo, medio y alto</div>
            <div class="p5-kpi-note">Cortes terciles: {metricas['definicion_objetivo']['cortes'][0]:.3f} y {metricas['definicion_objetivo']['cortes'][1]:.3f}</div>
        </div>
    </div>
    """
)

# ---------------------------------------------------------------------------
# 2. COMPARACIÓN DE ALGORITMOS (reports/modelo_comparacion.csv)
# ---------------------------------------------------------------------------
section_banner(
    f'Comparación de {len(metricas["evaluacion_anidada"])} modelos supervisados',
    'Naive Bayes · CART · Random Forest · Red neuronal MLP · Referencia mayoritaria',
)

tabla_comp = read_report('tables/comparacion_prueba_actual_e_historica.csv').copy()
nombres_legibles = {
    'DummyClassifier': 'DummyClassifier (Base Mayoritaria)',
    'CategoricalNB': 'Naive Bayes (CategoricalNB Discretizado)',
    'DecisionTreeClassifier': 'Árbol de Decisión (CART)',
    'RandomForestClassifier': 'Random Forest',
    'MLPClassifier': 'Red neuronal MLP',
}
nombres_cortos = {
    'DummyClassifier': 'REFERENCIA MAYORITARIA',
    'CategoricalNB': 'NAIVE BAYES',
    'DecisionTreeClassifier': 'ÁRBOL DE DECISIÓN',
    'RandomForestClassifier': 'RANDOM FOREST',
    'MLPClassifier': 'RED NEURONAL MLP',
}
tabla_comp['Algoritmo'] = tabla_comp['modelo'].map(lambda m: nombres_legibles.get(m, m))

# Menú de candidatos (configuración e historial de validación). La tabla inferior concentra métricas comparadas.
arte_algoritmos = {
    'RandomForestClassifier': 'halo',
    'MLPClassifier': 'spider-man',
    'CategoricalNB': 'god-of-war',
    'DecisionTreeClassifier': 'link',
    'DummyClassifier': 'mario',
}
sp_left_html = '<div class="sp-title">BITÁCORA DE ALGORITMOS</div>'
sp_right_html = ''
orden_sp = tabla_comp.assign(activo=tabla_comp.modelo.eq(metricas['modelo'])).sort_values(['activo', 'f1_macro_cv'], ascending=False).reset_index(drop=True)
for idx_m, row_m in orden_sp.iterrows():
    es_activo = bool(row_m['activo'])
    act_cls = 'active' if es_activo else ''
    disp_style = 'block' if es_activo else 'none'
    tag_txt = 'MODELO ACTIVO' if es_activo else 'CANDIDATO COMPARADO'
    nombre_corto = html.escape(nombres_cortos.get(row_m['modelo'], str(row_m['modelo'])), quote=True)
    algoritmo_html = html.escape(str(row_m['Algoritmo']), quote=True)
    origen_html = html.escape(str(row_m['origen_prueba']), quote=True)
    params_html = html.escape(str(row_m['mejores_parametros']), quote=True)
    arte = arte_algoritmos.get(row_m['modelo'], 'zelda')
    arte_b64 = asset_b64(f'img/juegos/{arte}.webp')
    sp_left_html += f"""
    <div class="sp-item {act_cls}" data-sp-target="alg-{idx_m}">
        <img class="sp-item-art" src="data:image/webp;base64,{arte_b64}" alt=""/>
        <div>
            <div class="sp-item-title">{nombre_corto}</div>
            <div class="sp-item-stack">F1 CV: {row_m['f1_macro_cv']:.4f} · F1 PRUEBA: {row_m['f1_macro_prueba']:.4f}</div>
        </div>
    </div>
    """
    sp_right_html += f"""
    <div class="sp-right" data-sp-id="alg-{idx_m}" style="display:{disp_style};">
        <div class="sp-tag">{tag_txt}</div>
        <div class="sp-right-title">{nombre_corto}</div>
        <div class="sp-right-summary">
            <strong>{algoritmo_html}</strong><br/>
            F1 macro en CV externa (10 × 5): {row_m['f1_macro_cv']:.4f} (±{row_m['desviacion_cv']:.4f})<br/>
            Alcance de prueba (n={metricas["n_prueba"]}): {origen_html}<br/>
            Nota: consulta todas las métricas numéricas comparadas en la tabla inferior.
        </div>
        <div class="sp-link">PARÁMETROS: {params_html}</div>
    </div>
    """

render_html(
    f'<div class="sp-shell"><div class="sp-left">{sp_left_html}</div><div>{sp_right_html}</div></div>'
)

st.dataframe(
    tabla_comp[
        [
            'Algoritmo',
            'f1_macro_cv',
            'desviacion_cv',
            'exactitud_prueba',
            'f1_macro_prueba',
            'balanced_accuracy_prueba',
            'origen_prueba',
        ]
    ],
    hide_index=True,
    width='stretch',
    column_config={
        'Algoritmo': 'Algoritmo',
        'f1_macro_cv': st.column_config.NumberColumn('F1 macro CV externa', format='%.4f'),
        'desviacion_cv': st.column_config.NumberColumn('Desv. Est. CV', format='%.4f'),
        'exactitud_prueba': st.column_config.NumberColumn('Exactitud (Prueba)', format='%.4f'),
        'f1_macro_prueba': st.column_config.NumberColumn('F1 Macro (Prueba)', format='%.4f'),
        'balanced_accuracy_prueba': st.column_config.NumberColumn('Exactitud Balanceada (Prueba)', format='%.4f'),
        'origen_prueba': 'Origen de la prueba',
    },
)

fig_comp = go.Figure()
filas_modelos = np.arange(len(tabla_comp))
etiquetas_modelos = {
    'DummyClassifier': 'Referencia<br>mayoritaria',
    'CategoricalNB': 'Naive Bayes',
    'DecisionTreeClassifier': 'Árbol de<br>decisión',
    'RandomForestClassifier': 'Random Forest',
    'MLPClassifier': 'Red neuronal<br>MLP',
}
for desplazamiento, etiqueta, campo, color, simbolo in [
    (-.22, 'F1 macro CV', 'f1_macro_cv', PALETA['primary'], 'circle'),
    (0, 'F1 macro prueba', 'f1_macro_prueba', PALETA['secondary'], 'diamond'),
    (.22, 'Exactitud prueba', 'exactitud_prueba', PALETA['accent'], 'square'),
]:
    es_cv = campo == 'f1_macro_cv'
    fig_comp.add_trace(go.Scatter(
        name=etiqueta,
        mode='markers',
        y=filas_modelos + desplazamiento,
        x=tabla_comp[campo],
        error_x=dict(array=tabla_comp['desviacion_cv'], color=color, thickness=2, width=5) if es_cv else None,
        text=tabla_comp['Algoritmo'],
        customdata=tabla_comp['desviacion_cv'] if es_cv else tabla_comp['origen_prueba'],
        marker=dict(color=color, symbol=simbolo, size=10, line=dict(color=PALETA['text-primary'], width=1)),
        hovertemplate='<b>%{text}</b><br>' + etiqueta + ': %{x:.3f}'
        + (' · DE %{customdata:.3f}' if es_cv else '<br>%{customdata}') + '<extra></extra>',
    ))
fig_comp.update_xaxes(title_text='Puntaje (0–1)', range=[0, 1])
fig_comp.update_yaxes(
    tickmode='array', tickvals=filas_modelos,
    ticktext=[etiquetas_modelos.get(modelo, modelo) for modelo in tabla_comp['modelo']],
    range=[len(filas_modelos) - .5, -.5], fixedrange=True, ticklabelstandoff=8, title_text='Modelo',
)
mostrar_grafica(fig_comp, 'Desempeño en validación cruzada y prueba', alto=465)
st.caption('Cada punto muestra un resultado. El tramo azul indica cuánto cambió el F1 macro entre las pruebas.')

cv = read_report('tables/comparativo_modelos.csv').set_index('modelo')
contrastes = read_report('tables/comparacion_estadistica.csv')
rf, mlp = cv.loc['RandomForestClassifier'], cv.loc['MLPClassifier']
rf_mlp = contrastes.loc[contrastes.modelo_a.eq('RandomForestClassifier') & contrastes.modelo_b.eq('MLPClassifier')]
p_t = rf_mlp.loc[rf_mlp.prueba.str.startswith('t corregida'), 'p_valor'].iloc[0]
st.caption(f'El F1 macro varió menos entre pruebas para Random Forest ({rf.f1_macro_de:.4f}) que la MLP ({mlp.f1_macro_de:.4f}). '
           f'La t corregida para su diferencia da p={p_t:.4f}. La prueba de los demás candidatos es histórica.')
with st.expander('Métricas de validación externa y contrastes'):
    st.dataframe(cv.reset_index(), hide_index=True, width='stretch')
    st.dataframe(contrastes, hide_index=True, width='stretch')

# ---------------------------------------------------------------------------
# 3. MATRIZ DE CONFUSIÓN Y VARIABLES MÁS INFLUYENTES (ANCHO COMPLETO)
# ---------------------------------------------------------------------------
# El ancho completo mantiene legibles títulos, intervalos y etiquetas.
col_cm, col_pi = st.container(), st.container()

with col_cm:
    section_banner('Matriz de confusión', f'Prueba con {metricas["n_prueba"]} juegos')
    clases = metricas['clases']  # ['bajo', 'medio', 'alto']
    matriz = np.asarray(resumen_m['matriz_confusion'], dtype=int)

    fig_cm = go.Figure(
        data=go.Heatmap(
            z=matriz,
            x=[c.capitalize() for c in clases],
            y=[c.capitalize() for c in clases],
            colorscale=[
                [0.0, PALETA['bg-chart-deep']],
                [0.35, PALETA['purple-deep']],
                [0.7, PALETA['secondary']],
                [1.0, PALETA['text-primary']],
            ],
            colorbar=dict(title='Juegos', thickness=10),
            hovertemplate='Clase Real: <b>%{y}</b><br>Clase Predicha: <b>%{x}</b><br>Juegos: <b>%{z}</b><extra></extra>',
        )
    )
    for fila, clase_real in enumerate(clases):
        for columna, clase_predicha in enumerate(clases):
            valor = int(matriz[fila, columna])
            fig_cm.add_annotation(
                x=clase_predicha.capitalize(),
                y=clase_real.capitalize(),
                text=str(valor),
                showarrow=False,
                font=dict(size=18, color=PALETA['bg-primary'] if valor >= .45 * matriz.max() else PALETA['text-primary']),
            )
    fig_cm.update_xaxes(title_text='Clase predicha')
    fig_cm.update_yaxes(title_text='Clase real', autorange='reversed')
    mostrar_grafica(fig_cm, 'Clases reales frente a predicciones', alto=390)
    st.caption('En la diagonal se ven los aciertos. Si sigues una fila, puedes ver en qué otros niveles quedaron los juegos.')

with col_pi:
    section_banner('Importancia de variables en Random Forest', 'Reducción de impureza de Gini')
    df_gini = read_report('tables/modelo_importancia_gini.csv').sort_values('importancia')
    etiquetas = {'Rating': 'Usuarios', 'Metacritic Rating': 'Metacritic',
                 'generos': 'Géneros', 'estudio': 'Organización', 'decada': 'Década'}
    figura_gini = go.Figure(go.Bar(
        x=df_gini['importancia'] * 100, y=df_gini['variable'].map(etiquetas),
        orientation='h', marker_color=PALETA['primary'],
        hovertemplate='%{y}: %{x:.2f} %<extra></extra>',
    ))
    figura_gini.update_xaxes(title_text='Importancia relativa (%)', rangemode='tozero')
    figura_gini.update_yaxes(ticklabelstandoff=8, title_text='Entrada del modelo')
    mostrar_grafica(figura_gini, 'Contribución a la reducción de impureza', alto=360)
    st.caption(
        'Una barra más larga indica que el bosque usó más ese dato para separar los niveles.'
    )

# ---------------------------------------------------------------------------
# 4. REPORTE DETALLADO POR CLASE Y AUDITORÍA DE IMPUTACIÓN
# ---------------------------------------------------------------------------
section_banner('Resultados por nivel', 'Bajo, medio y alto')

col_d1, col_d2 = st.columns(2)
with col_d1:
    st.markdown('**Precisión, Recall y F1-Score por Tercil en Prueba:**')
    filas_clases = []
    for c in metricas['clases']:
        info_c = resumen_m['reporte_clases'][c]
        filas_clases.append(
            {
                'Clase': c.capitalize(),
                'Soporte (n)': int(info_c['support']),
                'Precisión': info_c['precision'],
                'Recall (Sensibilidad)': info_c['recall'],
                'F1-Score': info_c['f1-score'],
            }
        )
    st.dataframe(
        pd.DataFrame(filas_clases),
        hide_index=True,
        width='stretch',
        column_config={
            'Clase': 'Clase',
            'Soporte (n)': st.column_config.NumberColumn('Soporte (n)', format='%d'),
            'Precisión': st.column_config.NumberColumn(format='%.3f'),
            'Recall (Sensibilidad)': st.column_config.NumberColumn(format='%.3f'),
            'F1-Score': st.column_config.NumberColumn(format='%.3f'),
        },
    )

with col_d2:
    st.markdown(f'**Recall por clase para {len(tabla_comp)} modelos**')
    st.caption('Prueba actual del bosque y resultados históricos para los demás candidatos.')
    err_df = read_report('tables/modelo_error_por_clase.csv').copy()
    err_df['clase'] = err_df['clase'].astype(str).str.capitalize()
    st.dataframe(
        err_df,
        hide_index=True,
        width='stretch',
        column_config={
            'modelo': 'Modelo',
            'clase': 'Clase',
            'n': st.column_config.NumberColumn('Total Clase', format='%d'),
            'aciertos': st.column_config.NumberColumn('Aciertos', format='%d'),
            'recall': st.column_config.NumberColumn('Recall', format='%.3f'),
        },
    )

section_banner('Calibración de probabilidades', 'Compara los porcentajes del bosque con lo que pasó en la prueba')
calibracion = metricas['calibracion_web']
ajustada = calibracion['metricas_prueba']
st.markdown(
    f'El ajuste se aprendió con predicciones fuera de pliegue de **{calibracion["n_ajuste"]} juegos** '
    f'de entrenamiento. La comparación usa los mismos **{calibracion["n_prueba"]} juegos** de prueba.'
)
nivel = st.radio('Nivel de popularidad', ['alto', 'medio', 'bajo'], format_func=str.capitalize, horizontal=True)
curva = go.Figure()
curva.add_scatter(x=[0, 1], y=[0, 1], mode='lines', name='Referencia ideal',
                  line=dict(color=PALETA['text-primary'], dash='dot'))
for archivo, serie, color, simbolo in [
    ('calibracion.csv', 'Sin calibrar', PALETA['secondary'], 'diamond'),
    ('calibracion_ajustada.csv', 'Calibrada', PALETA['primary'], 'circle'),
]:
    fiabilidad = read_report(f'tables/{archivo}')
    filas = fiabilidad.loc[fiabilidad.clase.eq(nivel)]
    curva.add_scatter(
        x=filas.probabilidad_media,
        y=filas.fraccion_observada,
        customdata=filas.n,
        mode='lines+markers',
        name=serie,
        line=dict(color=color),
        marker=dict(symbol=simbolo, size=7),
        hovertemplate='Probabilidad media %{x:.1%}<br>Fracción observada %{y:.1%}<br>Juegos %{customdata}<extra></extra>',
    )
curva.update_xaxes(title_text='Probabilidad estimada media (%)', tickformat='.0%', range=[0, 1])
curva.update_yaxes(title_text='Fracción observada de la clase (%)', tickformat='.0%', range=[0, 1])
mostrar_grafica(curva, f'Fiabilidad del nivel {nivel}', alto=400)
st.caption('Cada punto agrupa juegos con probabilidades parecidas. Cuanto más cerca esté de la diagonal, '
           'más se parece la probabilidad estimada a la frecuencia observada en ese grupo.')
st.markdown(
    '| Métrica en prueba | Sin calibrar | Calibrada |\n'
    '| --- | ---: | ---: |\n'
    f'| Brier multiclase | {resumen_m["brier_multiclase"]:.4f} | {ajustada["brier_multiclase"]:.4f} |\n'
    f'| Log-loss | {resumen_m["log_loss"]:.4f} | {ajustada["log_loss"]:.4f} |'
)
st.caption('En ambas métricas, un valor más bajo indica mejores probabilidades en esta prueba.')

````

## BITACORA_UNIFICADA.md

Ruta: `Final/pages/BITACORA_UNIFICADA.md` · Bytes: 761 · SHA-256: `eee3c4fa72609125b8a91f1a5d338e659caa4afb40127d64bef49b2f3a8a83fd`

````text
# Páginas de Streamlit

- Exploración reúne los filtros y las gráficas. Predicción contiene el formulario. Modelo explica la comparación y los resultados en prueba.

## Portadas y conclusion de Prediccion

Juegos parecidos usa primero las portadas locales. Para otros titulos consulta la tienda publica de Steam y comprueba el titulo y el año. Si la ficha no coincide o la conexion falla, muestra el nombre de la organizacion registrada en el catalogo, cuando existe. La app consulta solo los titulos de los juegos parecidos y guarda los resultados temporalmente en cache.

La conclusion usa las probabilidades calibradas, la distancia entre los dos primeros niveles y los datos de la consulta. Cuando falta la nota de prensa indica la mediana aplicada.

````

