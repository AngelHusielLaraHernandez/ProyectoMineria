# Carpeta: Final/data

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `Final/data/BITACORA_UNIFICADA.md` · Bytes: 307 · SHA-256: `7e3d2b095a7a7ef5c92ca5e07f97ebf7244ea212801279ab34b7997bccec91c9`

````text
# Datos y exportaciones

- raw contiene la copia fija del CSV de trabajo. historical conserva el catálogo anterior. clean contiene datos preparados y export conserva las entradas de Weka y Orange con su procedencia.
- El [log de limpieza](../reports/limpieza_log.md) reúne los conteos de la preparación.

````

