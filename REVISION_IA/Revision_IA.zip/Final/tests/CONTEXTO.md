# Carpeta: Final/tests

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `Final/tests/BITACORA_UNIFICADA.md` · Bytes: 128 · SHA-256: `a5bd84972d5d5fce699706ffc264b9e82e4ccca7c146f20483f355ff0f47d502`

````text
# Pruebas de la aplicación

- Las pruebas cubren los datos, las métricas, el modelo, las gráficas y los flujos de Streamlit.

````

## test_auditoria.py

Ruta: `Final/tests/test_auditoria.py` · Bytes: 4121 · SHA-256: `0e75d064df57541e4495a026cff35cc2cf9ea6ecadda5a417463db50b0899325`

````text
"""Regresiones de trazabilidad, coherencia entre fases y prevención de circularidad."""
import hashlib
import importlib
import json

import pandas as pd
import pytest

from src.config import ROOT, CLEAN, REPORTS
from src.data import load_clean
from src.modeling import train
from src.procedencia import auditar_historia


def test_historia_se_reconstruye_sin_modificar_maestro():
    origen = ROOT / 'data/raw/games_curated.csv'
    antes = origen.read_bytes()
    historia, pendientes = auditar_historia(ROOT)
    assert historia['filas_historicas'] == 1512
    assert historia['descartes_heredados'] == 395
    assert historia['grupos_con_diferencias'] == 13
    assert historia['grupos_con_conflicto_analitico'] == 3
    assert historia['diferencias_reconstruccion'] == []
    assert pendientes == {117, 140, 296}
    assert origen.read_bytes() == antes


def test_seis_figuras_eda_y_script_reproducible_presentes():
    assert (ROOT / 'src/01_inspeccion.py').exists()
    for nombre in ['rating', 'metacritic', 'plays_log', 'decadas', 'generos_top15', 'rating_vs_metacritic']:
        assert (REPORTS / f'figures/eda_{nombre}.png').stat().st_size > 1000


def test_join_de_generos_exige_id_y_preserva_pertenencias():
    juegos = pd.read_csv(CLEAN / 'dataset_depurado.csv')
    generos = pd.read_csv(CLEAN / 'generos_largo.csv')
    unido = generos.merge(juegos[['id_juego', 'Release Date']], on='id_juego', validate='many_to_one')
    assert len(unido) == len(generos)
    assert juegos.titulo_compartido.sum() == 35
    assert juegos.loc[juegos.titulo_compartido, 'grupo_titulo'].nunique() == 17
    with pytest.raises(pd.errors.MergeError):
        generos.merge(juegos[['Title', 'Release Date']], left_on='juego', right_on='Title', validate='many_to_one')


def test_correlaciones_con_casos_historicos_senalados_excluidos():
    parametros = json.loads((REPORTS / 'clustering_03_parametros.json').read_text())
    assert parametros['n_completos'] == 887
    assert parametros['n_conflictos_historicos'] == 3
    tabla = pd.read_csv(REPORTS / 'clustering_03_correlaciones_catalogo.csv')
    assert tabla.iloc[0]['n'] == parametros['n_completos']


def test_modelo_rechaza_etiquetas_y_proyecciones_de_clusters():
    for campo in ['cluster_kmeans', 'cluster_dbscan', 'componente_1']:
        with pytest.raises(ValueError, match='no acepta'):
            train(pd.DataFrame({campo: [0]}))


def test_modelo_usa_solo_depurado_y_excluye_conflictos():
    modelo = pd.read_csv(CLEAN / 'juegos_modelo.csv')
    assert len(modelo) == len(load_clean().query('elegible_analisis')) == 1114
    assert not set(modelo.id_juego) & {117, 140, 296}
    assert not any(c.startswith(('cluster_', 'componente_')) for c in modelo)
    metadata = json.loads((ROOT / 'models/metadata.json').read_text())
    assert metadata['definicion_objetivo']['version'] == 'INDICE-PERCENTILES-TRAIN-2.0'


def test_log_no_atribuye_conversiones_km_inexistentes():
    log = (REPORTS / 'limpieza_log.md').read_text()
    assert '0 textos K/M convertidos' in log
    assert '395 filas históricas' in log
    assert 'ya no están en el maestro' in log


def test_manifest_app_y_reporte_comparten_artefactos():
    manifest = json.loads((REPORTS / 'manifest.json').read_text())
    for nombre in ['dataset_depurado', 'dataset_con_clusters']:
        assert manifest[f'sha256_{nombre}'] == hashlib.sha256((CLEAN / f'{nombre}.csv').read_bytes()).hexdigest()
    app = (ROOT / 'pages/1_Exploracion.py').read_text()
    assert 'dataset_con_clusters.csv' in app
    assert "CLEAN / 'perfiles.csv'" not in app
    assert "tables/perfiles_clusters.csv" in app


def test_comparacion_weka_es_ejecucion_y_misma_fuente():
    manifest = json.loads((REPORTS / 'weka/ejecucion.json').read_text())
    tabla = pd.read_csv(REPORTS / 'weka/comparacion.csv')
    assert set(tabla.herramienta) == {'Weka 3.8.6', 'sklearn'}
    assert len(tabla) == 6 and tabla.n.eq(887).all()
    assert manifest['sha256_dataset_depurado'] == hashlib.sha256((CLEAN / 'dataset_depurado.csv').read_bytes()).hexdigest()
    assert (REPORTS / 'weka/k2_stdout.txt').stat().st_size > 1000

````

## test_auditoria2.py

Ruta: `Final/tests/test_auditoria2.py` · Bytes: 9477 · SHA-256: `12bb3ab337b30f5b0264a155fa03d27a3682b6a7fa811bca8c59502418823ef9`

````text
"""Regresiones metodológicas y de portabilidad de la segunda auditoría."""
import importlib
import json
import os
import subprocess
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from streamlit.testing.v1 import AppTest

from src.config import ROOT, FEATURES
from src.features import CategoriasFrecuentes
from src.objetivo import ajustar_referencia, aplicar_referencia, ClasificadorObjetivoLocal

modulo = importlib.import_module('src.04_modelo')


def datos_y_metadata():
    return (pd.read_csv(ROOT / 'data/clean/juegos_modelo.csv'),
            json.loads((ROOT / 'models/metadata.json').read_text()))


def test_otro_estudio_es_respaldo_y_no_bandera_de_cualquier_socio_raro():
    encoder = CategoriasFrecuentes(min_frecuencia=2, otro_solo_si_ninguna=True)
    encoder.fit(pd.DataFrame({'estudio': [['A'], ['A', 'Raro'], ['B']]}))
    z = encoder.transform(pd.DataFrame({'estudio': [['A', 'Nuevo'], ['Nuevo'], [], ['A']]}))
    np.testing.assert_array_equal(z, [[1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 0, 0]])


def test_referencia_no_cambia_al_alterar_solo_prueba():
    df, meta = datos_y_metadata()
    train = df[df.particion.eq('entrenamiento')]
    original = ajustar_referencia(train)
    mutado = df.copy()
    mutado.loc[mutado.particion.eq('prueba'), ['Plays', 'Wishlist', 'Backlogs']] = 10**12
    nueva = ajustar_referencia(mutado[mutado.particion.eq('entrenamiento')])
    assert nueva == original == meta['definicion_objetivo']
    esperado = aplicar_referencia(df, original)
    assert esperado.nivel_popularidad.tolist() == df.nivel_popularidad.tolist()


def test_cada_fold_usa_referencia_y_etiquetas_de_su_subentrenamiento():
    df, _ = datos_y_metadata()
    folds = json.loads((ROOT / 'models/referencias_folds.json').read_text())
    etiquetas = pd.read_csv(ROOT / 'reports/modelo_etiquetas_validacion_locales.csv')
    assert len(folds) == 10
    por_id = df.set_index('id_juego', drop=False)
    test_ids = set(df.loc[df.particion.eq('prueba'), 'id_juego'])
    for f in folds:
        assert not set(f['ids_ajuste']) & set(f['ids_validacion'])
        assert not (set(f['ids_ajuste']) | set(f['ids_validacion'])) & test_ids
        ref = ajustar_referencia(por_id.loc[f['ids_ajuste']])
        assert f['referencia'] == ref
        esperado = aplicar_referencia(por_id.loc[f['ids_validacion']], ref).nivel_popularidad.tolist()
        assert esperado == etiquetas.loc[etiquetas.fold.eq(f['fold']), 'nivel_popularidad_local'].tolist()


def test_estimador_grid_aprende_objetivo_sin_etiquetas_globales():
    df, _ = datos_y_metadata()
    muestra = df[df.particion.eq('entrenamiento')].head(90).copy()
    for c in ['generos', 'estudio']:
        muestra[c] = muestra[c].map(json.loads)
    modelo = ClasificadorObjetivoLocal(modulo.construir_pipeline(DecisionTreeClassifier(max_depth=3, random_state=42)))
    # y intencionalmente falso: fit debe usar la referencia de sus propias señales.
    modelo.fit(muestra, ['alto']*len(muestra))
    assert set(modelo.classes_) == {'bajo', 'medio', 'alto'}
    assert modelo.referencia_['poblacion_referencia_n'] == len(muestra)
    assert modelo.pipeline_.named_steps['preparar'].feature_names_in_.tolist() == FEATURES


def test_indicadores_categoricos_son_binarios_y_no_hay_missingindicator():
    df, _ = datos_y_metadata()
    train = df[df.particion.eq('entrenamiento')].copy()
    for c in ['generos', 'estudio']:
        train[c] = train[c].map(json.loads)
    modelo = joblib.load(ROOT / 'models/modelo_popularidad.joblib')
    prep = modelo.named_steps['preparar']
    nombres = prep.get_feature_names_out()
    z = prep.transform(train[FEATURES])
    assert not any('missingindicator' in n for n in nombres)
    categoricas = [i for i, n in enumerate(nombres) if not n.startswith('notas__')]
    assert set(np.unique(z[:, categoricas])) <= {0., 1.}
    assert not prep.named_transformers_['notas'].named_steps['imputar'].add_indicator


def test_joblib_carga_y_predice_desde_proceso_limpio_sin_src(tmp_path):
    codigo = '''import sys,joblib,pandas as pd
p=joblib.load(sys.argv[1])
fila=pd.DataFrame([{'generos':['RPG'],'estudio':'Nuevo','decada':2020,'Rating':4.0,'Metacritic Rating':85.0}])
assert p.predict(fila)[0] in ['bajo','medio','alto']
assert 'src' not in sys.modules
print('CARGA_PORTATIL_CORRECTA')
'''
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    salida = subprocess.run([sys.executable, '-c', codigo, str(ROOT / 'models/modelo_popularidad.joblib')],
                            cwd=tmp_path, env=env, capture_output=True, text=True, timeout=30)
    assert salida.returncode == 0, salida.stderr
    assert 'CARGA_PORTATIL_CORRECTA' in salida.stdout


def test_formulario_exige_nota_o_ausencia_explicita_y_muestra_vecinos():
    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=120)
    assert not app.exception
    # Validar que si no hay géneros seleccionados se muestra advertencia sin excepción
    app.multiselect[0].set_value([])
    app.button[0].click().run()
    assert not app.exception
    assert app.warning and not any('Nivel estimado' in h.value for h in app.subheader)
    # Al seleccionar géneros y ejecutar, muestra predicción y los 5 vecinos
    app.multiselect[0].set_value(['RPG', 'Adventure'])
    app.slider[0].set_value(85)
    app.slider[1].set_value(4.2)
    app.button[0].click().run()
    assert not app.exception
    assert any('Nivel estimado' in h.value for h in app.subheader)
    assert len(app.dataframe[0].value) == 5


def test_ausencia_habilita_campos_sin_enviar_y_acepta_escala_completa():
    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=120)
    app.slider[0].set_value(100)
    app.slider[1].set_value(5.0)
    app.button[0].click().run()
    assert not app.exception
    assert any('Nivel estimado' in h.value for h in app.subheader)
    app.checkbox[0].check().run()
    app.button[0].click().run()
    assert not app.exception
    assert len(app.dataframe[0].value) == 5


def test_cambio_de_artefactos_invalida_clave_de_cache(tmp_path, monkeypatch):
    import src.ui as ui
    import src.pipeline as pipeline
    for nombre in ['CLEAN', 'MODELS', 'REPORTS']:
        monkeypatch.setattr(ui, nombre, tmp_path)
    monkeypatch.setattr(pipeline, 'huella_pipeline', lambda: 'codigo-sin-cambios')
    llamadas = []
    monkeypatch.setattr(ui, '_resources', lambda huella, estado: llamadas.append((huella, estado)))
    archivo = tmp_path / 'metadata.json'
    archivo.write_text('{}')
    ui.resources()
    archivo.write_text('{"cambio": true}')
    ui.resources()
    archivo.unlink()
    ui.resources()
    assert llamadas[0] != llamadas[1] != llamadas[2]


def test_vecinos_no_necesitan_conteos_y_son_solo_entrenamiento():
    from src.similitud import cinco_vecinos
    df, _ = datos_y_metadata()
    modelo = joblib.load(ROOT / 'models/modelo_popularidad.joblib')
    fila = pd.DataFrame([{'generos':['RPG'], 'estudio':[], 'decada':2020, 'Rating':4., 'Metacritic Rating':85.}])
    vecinos = cinco_vecinos(fila, modelo)
    assert len(vecinos) == vecinos.id_juego.nunique() == 5
    assert set(vecinos.id_juego) <= set(df.loc[df.particion.eq('entrenamiento'), 'id_juego'])
    assert {'cluster_kmeans', 'cluster_dbscan'} <= set(vecinos)


def test_pantalla_error_cuando_falta_artefacto(monkeypatch, caplog):
    import src.ui as ui
    mensajes_error = []
    detenidos = []
    monkeypatch.setattr(ui, '_resources', lambda huella, estado: (_ for _ in ()).throw(FileNotFoundError('Falta modelo_popularidad.joblib')))
    monkeypatch.setattr(ui.st, 'error', lambda msg: mensajes_error.append(msg))
    monkeypatch.setattr(ui.st, 'stop', lambda: detenidos.append(True))
    ui.resources()
    assert detenidos == [True]
    assert mensajes_error == ['No se pudo cargar el observatorio. Recarga la página para volver a intentarlo.']
    assert 'Falta modelo_popularidad.joblib' in caplog.text


def test_recarga_automatica_si_src_ui_estaba_en_memoria_antigua(monkeypatch):
    import src.ui as ui
    monkeypatch.delattr(ui, 'asset_b64', raising=False)
    app = AppTest.from_file(str(ROOT / 'app.py')).run(timeout=60)
    assert not app.exception
    assert hasattr(ui, 'asset_b64')


def test_menu_unico_en_sidebar_y_sin_bloques_codigo_html_incrustado():
    paginas = [
        'app.py',
        'pages/1_Exploracion.py',
        'pages/2_Prediccion.py',
        'pages/3_Acerca_del_modelo.py',
    ]
    for rel in paginas:
        app = AppTest.from_file(str(ROOT / rel)).run(timeout=60)
        assert not app.exception, f'Excepción en {rel}: {app.exception}'
        sidebar_mds = [m.value for m in app.sidebar.markdown]
        main_mds = [m.value for m in app.main.markdown]
        # 1. El menú P5Menu (<div class="p5-menu-stage">) DEBE estar en el sidebar y NUNCA en main
        assert sum('<div class="p5-menu-stage"' in m for m in sidebar_mds) == 1, f'Falta menú P5 en sidebar de {rel}'
        assert sum('<div class="p5-menu-stage"' in m for m in main_mds) == 0, f'Menú duplicado en main de {rel}'
        # 2. Ningún bloque HTML (<div ...) debe tener líneas con >= 4 espacios de sangría que CommonMark convierta en <pre><code>
        for m in [*sidebar_mds, *main_mds]:
            if m.lstrip().startswith('<div'):
                for line in m.splitlines():
                    assert not line.startswith('    '), f'Línea con sangría >=4 en HTML de {rel}: {line[:50]}'

````

## test_clustering.py

Ruta: `Final/tests/test_clustering.py` · Bytes: 4024 · SHA-256: `99f28c00c7328cad44fd3b87656d83bf3d48dddf6393932e69dedb700f8917a2`

````text
"""Pruebas de cobertura, asociación y espacio del análisis de seis variables."""
import importlib
import json

import numpy as np
import pandas as pd
import pytest

modulo = importlib.import_module('src.03_clustering')


def test_minimo_20_se_aplica_a_pares_y_no_solo_titulos():
    df = pd.DataFrame({'Rating': np.arange(25, dtype=float), 'Metacritic Rating': np.arange(25, dtype=float)})
    df.loc[:5, 'Rating'] = np.nan
    resultado = modulo.asociacion(df)
    assert resultado['n_juegos'] == 25 and resultado['n'] == 19
    assert resultado['estado'].startswith('excluido')
    assert pd.isna(resultado['pearson_r']) and pd.isna(resultado['pearson_p'])
    df.loc[5, 'Rating'] = 5
    resultado = modulo.asociacion(df)
    assert resultado['n'] == 20 and resultado['estado'] == 'incluido'
    assert np.isfinite(resultado['pearson_p']) and np.isfinite(resultado['spearman_p'])


def test_correlacion_alta_no_equivale_a_brecha_pequena():
    rating = np.linspace(1, 4, 30)
    df = pd.DataFrame({'Rating': rating, 'Metacritic Rating': rating * 20 + 10,
                       'brecha': np.full(30, -10), 'generos': [['RPG']] * 30})
    tabla = modulo.correlaciones_por_grupo(df, 'generos')
    assert tabla.iloc[0]['pearson_r'] == pytest.approx(1)
    assert tabla.iloc[0]['brecha_absoluta_media'] == pytest.approx(10)


def test_variables_constantes_no_generan_p_valores_enganosos():
    df = pd.DataFrame({'Rating': [4] * 25, 'Metacritic Rating': np.arange(25)})
    resultado = modulo.asociacion(df)
    assert resultado['estado'] == 'excluido: variable constante'
    assert pd.isna(resultado['spearman_p'])


def datos():
    rng = np.random.default_rng(42)
    df = pd.DataFrame(rng.uniform(1, 1000, size=(40, 4)), columns=modulo.CONTEOS)
    df['Rating'] = rng.uniform(1, 5, 40)
    df['Metacritic Rating'] = rng.uniform(45, 99, 40)
    return df


def test_log_y_escalado_solo_en_casos_completos_sin_genero():
    df = datos()
    df.loc[0, 'Rating'] = np.nan
    df['genero'] = 'No entra a la distancia'
    mascara, espacio, escalador = modulo.preparar_espacio(df)
    assert mascara.sum() == 39 and espacio.shape == (39, 6)
    np.testing.assert_allclose(espacio.mean(axis=0), 0, atol=1e-12)
    np.testing.assert_allclose(espacio.std(axis=0), 1, atol=1e-12)
    np.testing.assert_allclose(escalador.mean_[:4], np.log1p(df.loc[mascara, modulo.CONTEOS]).mean())
    np.testing.assert_allclose(escalador.mean_[4:], df.loc[mascara, ['Rating', 'Metacritic Rating']].mean())


def test_eps_se_extrae_de_la_curva_usada_y_es_reproducible():
    _, espacio, _ = modulo.preparar_espacio(datos())
    eps, indice, distancias, motivo = modulo.elegir_eps(espacio, 12)
    assert eps > 0 and eps == distancias[indice]
    assert np.all(np.diff(distancias) >= 0)
    assert eps == modulo.elegir_eps(espacio, 12)[0]
    assert motivo


def test_ruido_no_se_presenta_como_silhouette_de_un_cluster():
    _, espacio, _ = modulo.preparar_espacio(datos())
    assert modulo.silueta_sin_ruido(espacio, np.full(40, -1)) is None
    assert modulo.silueta_sin_ruido(espacio, np.zeros(40, dtype=int)) is None


def test_salida_real_conserva_juegos_y_distingue_ausencias_de_ruido():
    entrada = pd.read_csv(modulo.RAIZ / 'data/clean/dataset_depurado.csv')
    salida = pd.read_csv(modulo.RAIZ / 'data/clean/dataset_con_clusters.csv')
    parametros = json.loads((modulo.RAIZ / 'reports/clustering_03_parametros.json').read_text())
    assert len(entrada) == len(salida) == parametros['n_entrada']
    assert entrada.id_juego.tolist() == salida.id_juego.tolist()
    completos = entrada[modulo.VARIABLES].notna().all(axis=1)
    if 'elegible_analisis' in entrada:
        completos &= entrada.elegible_analisis
    assert salida.incluido_clustering.equals(completos)
    assert salida.loc[~completos, ['cluster_kmeans', 'cluster_dbscan']].isna().all().all()
    assert salida.loc[completos, ['cluster_kmeans', 'cluster_dbscan']].notna().all().all()
    assert int(salida.cluster_dbscan.eq(-1).sum()) == parametros['dbscan_ruido']

````

## test_dashboard.py

Ruta: `Final/tests/test_dashboard.py` · Bytes: 7347 · SHA-256: `6caf2b48c27f48bacc69c5a7b7b9d3ede84a7db1f0978eca66048b28bf6a03ab`

````text
"""Pruebas de interacción y regresiones del tablero de exploración (Página 1)."""
import base64
import io
import json

import numpy as np
import pandas as pd
import streamlit as st
from streamlit.testing.v1 import AppTest

import src.ui as ui
from src.config import REPORTS, ROOT
from src.visualizacion import FONT_SANS, PALETA


def _valores_plotly(raw):
    if isinstance(raw, dict) and 'bdata' in raw:
        return np.frombuffer(base64.b64decode(raw['bdata']), dtype=np.dtype(raw['dtype'])).tolist()
    return list(raw)


def _especificaciones_plotly(app):
    return [json.loads(pc.proto.spec) for pc in app.get('plotly_chart')]


def _grafica_brecha(app):
    for spec in _especificaciones_plotly(app):
        xaxis = spec.get('layout', {}).get('xaxis', {})
        if xaxis.get('title', {}).get('text') == 'Brecha (pts)':
            return spec
    raise AssertionError('No se encontró la gráfica de brecha en 1_Exploracion.py')


def test_dashboard_filtra_restablece_y_admite_consulta_vacia():
    app = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    total = app.metric[0].value
    app.multiselect(key='eda_generos_0').set_value(['Pinball']).run()
    assert not app.exception
    assert app.metric[0].value == f'1 / {total.split(" / ")[1]}'
    app.slider(key='eda_rating_0').set_value((0.0, 0.1)).run()
    assert not app.exception
    assert app.metric[0].value.startswith('0 / ')
    next(boton for boton in app.button if boton.label == 'Restablecer filtros').click().run()
    assert not app.exception
    assert app.metric[0].value == total
    assert not app.multiselect(key='eda_generos_1').value
    assert app.slider(key='eda_rating_1').value == (0.0, 5.0)


def test_dashboard_cuatro_pestanas_graficas_y_descarga_csv(monkeypatch):
    descargas = []
    orig_download = st.download_button

    def _spy_download(label, data, file_name=None, mime=None, **kwargs):
        descargas.append((label, data, file_name, mime, kwargs.get('disabled', False)))
        return orig_download(label, data, file_name=file_name, mime=mime, **kwargs)

    monkeypatch.setattr(st, 'download_button', _spy_download)

    app = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    assert not app.exception
    assert [tab.label for tab in app.tabs] == [
        'Señales de actividad',
        'Recepción y brecha',
        'Segmentación (Clustering)',
        'Riesgo comercial (GaaS)',
    ]
    assert len(app.dataframe) >= 4
    assert all(not df_el.value.empty for df_el in app.dataframe)

    for pc in app.get('plotly_chart'):
        spec = json.loads(pc.proto.spec)
        config = json.loads(pc.proto.config or '{}')
        assert spec['layout']['font']['family'] == FONT_SANS
        assert spec['layout']['margin']['t'] >= 44
        assert 'toImage' not in config.get('modeBarButtonsToRemove', [])

    assert [(d[2], d[4]) for d in descargas] == [
        ('consulta_dashboard.csv', False),
        ('correlacion_generos.csv', False),
    ]
    for _, payload, nombre, mime, _ in descargas:
        assert not nombre.startswith('tables/')
        assert mime == 'text/csv'
        parsed = pd.read_csv(io.BytesIO(payload))
        assert not parsed.empty

    descargas.clear()
    app.radio[3].set_value('Estudio / Organización (Team)').run(timeout=30)
    assert not app.exception
    assert any(d[2] == 'correlacion_organizaciones.csv' for d in descargas)


def test_dashboard_brecha_con_signo_destaca_tres_mayores_desacuerdos_absolutos():
    app = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    app.selectbox[0].set_value('brecha_media').run(timeout=30)
    assert not app.exception

    corr_gen = pd.read_csv(REPORTS / 'tables/correlacion_generos.csv').query('estado == "incluido"')
    esperados_gen = set(corr_gen.loc[corr_gen['brecha_media'].abs().nlargest(3).index, 'grupo'])

    traza_gen = _grafica_brecha(app)['data'][0]
    destacados_gen = {
        grupo for grupo, color in zip(traza_gen['y'], traza_gen['marker']['color'])
        if color == PALETA['accent']
    }
    assert destacados_gen == esperados_gen == {'Shooter', 'Racing', 'Fighting'}

    app.radio[3].set_value('Estudio / Organización (Team)').run(timeout=30)
    assert not app.exception
    corr_org = pd.read_csv(REPORTS / 'tables/correlacion_organizaciones.csv').query('estado == "incluido"')
    esperados_org = set(corr_org.loc[corr_org['brecha_media'].abs().nlargest(3).index, 'grupo'])

    traza_org = _grafica_brecha(app)['data'][0]
    destacados_org = {
        grupo for grupo, color in zip(traza_org['y'], traza_org['marker']['color'])
        if color == PALETA['accent']
    }
    assert destacados_org == esperados_org == {'Activision', 'Ubisoft Entertainment', 'Electronic Arts'}


def test_dashboard_fig_bar_log_seguro_ante_ceros(monkeypatch):
    app = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    assert not app.exception
    fig_bar_log = next(
        spec for spec in _especificaciones_plotly(app)
        if spec.get('layout', {}).get('barmode') == 'group'
        and spec.get('layout', {}).get('xaxis', {}).get('type') == 'log'
    )
    for traza in fig_bar_log['data']:
        valores_x = [float(v) for v in _valores_plotly(traza['x']) if v is not None and not np.isnan(float(v))]
        assert valores_x and all(v > 0 for v in valores_x)

    df_real, bundle, analysis = ui.resources()
    fila_cero = df_real.loc[df_real['Plays'] == 0].head(1).copy()
    assert not fila_cero.empty
    fila_cero['generos'] = [['Adventure']]
    fila_cero['Wishlist'] = [250.0]
    fila_cero['Backlogs'] = [45.0]
    monkeypatch.setattr(ui, 'resources', lambda: (fila_cero, bundle, analysis))

    app_cero = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    assert not app_cero.exception
    assert any('No hay registros positivos' in info.value for info in app_cero.info)

    app_cero.radio[0].set_value('Wishlist').run(timeout=30)
    assert not app_cero.exception
    fig_solo_positivas = next(
        spec for spec in _especificaciones_plotly(app_cero)
        if spec.get('layout', {}).get('barmode') == 'group'
        and spec.get('layout', {}).get('xaxis', {}).get('type') == 'log'
    )
    nombres_trazas = {t['name'] for t in fig_solo_positivas['data']}
    assert 'Plays' not in nombres_trazas
    assert nombres_trazas == {'Backlogs', 'Wishlist'}
    for traza in fig_solo_positivas['data']:
        valores_x = [float(v) for v in _valores_plotly(traza['x']) if v is not None and not np.isnan(float(v))]
        assert valores_x and all(v > 0 for v in valores_x)


def test_dashboard_fig_pca_y_metodos_seguros_con_filtros_vacios():
    app = AppTest.from_file(str(ROOT / 'pages/1_Exploracion.py')).run(timeout=30)
    app.slider(key='eda_rating_0').set_value((0.0, 0.1)).run(timeout=30)
    assert not app.exception
    assert app.metric[0].value.startswith('0 / ')
    assert any('La consulta no contiene juegos con coordenadas PCA.' in info.value for info in app.info)
    assert app.get('download_button')[0].proto.disabled

    for metodo in ['Ward', 'DBSCAN']:
        app.radio[4].set_value(metodo).run(timeout=30)
        assert not app.exception
        assert any('La consulta no contiene juegos con coordenadas PCA.' in info.value for info in app.info)

````

## test_inferencia.py

Ruta: `Final/tests/test_inferencia.py` · Bytes: 5485 · SHA-256: `d19ea04ef6426428cfec77edfe041f3a98915723d092459150b5a6553873c8f5`

````text
"""Paridad entre formulario, datos crudos y artefacto guardado."""
import joblib
import numpy as np
import pandas as pd
import pytest
from src.config import MODELS, ROOT
from src.inferencia import predecir_formulario


@pytest.fixture(scope='module')
def modelo():
    return joblib.load(MODELS / 'modelo_popularidad.joblib')


@pytest.mark.parametrize('meta,rating,estudio', [(82,3.9,['Otro']), (None,3.9,['Otro']), (100,5,['Nintendo']), (0,0,['Organización nueva'])])
def test_formulario_coincide_con_pipeline(modelo, meta, rating, estudio):
    fila, clase, p = predecir_formulario(modelo,['Adventure','RPG'],estudio,2020,meta,rating)
    assert isinstance(fila, pd.DataFrame)
    assert clase == modelo.predict(fila)[0]
    assert sum(p.values()) == pytest.approx(1)
    for etiqueta,valor in zip(modelo.classes_,modelo.predict_proba(fila)[0]):
        assert p[etiqueta] == pytest.approx(valor)
    if meta is None:
        assert fila['Metacritic Rating'].isna().all()


@pytest.mark.parametrize('decada', [-1, -1.0, 0, 1980, 2020])
def test_formulario_acepta_decada_menos_uno_y_multiplos_de_diez(modelo, decada):
    fila, clase, p = predecir_formulario(modelo, ['Adventure', 'RPG'], ['Otro'], decada, 82, 3.9)
    assert fila['decada'].iloc[0] == int(decada)
    assert clase == modelo.predict(fila)[0]
    assert sum(p.values()) == pytest.approx(1)
    for etiqueta, valor in zip(modelo.classes_, modelo.predict_proba(fila)[0]):
        assert p[etiqueta] == pytest.approx(valor)


@pytest.mark.parametrize('decada_invalida', [True, False, np.bool_(True), np.bool_(False), 1985, 2023, -10, -2, 2020.5, np.nan, np.inf])
def test_formulario_rechaza_bool_y_decadas_invalidas(modelo, decada_invalida):
    with pytest.raises(ValueError):
        predecir_formulario(modelo, ['RPG'], ['Otro'], decada_invalida, 82, 3.9)


def test_predecir_formulario_evalua_predict_proba_una_sola_vez(modelo):
    class _PipelineSpy:
        def __init__(self, real):
            self._real = real
            self.classes_ = real.classes_
            self.llamadas_proba = 0

        def predict(self, X):
            raise AssertionError('predecir_formulario no debe invocar predict() por separado')

        def predict_proba(self, X):
            self.llamadas_proba += 1
            return self._real.predict_proba(X)

    espia = _PipelineSpy(modelo)
    fila, clase, p = predecir_formulario(espia, ['RPG'], ['Nintendo'], -1, 88, 4.3)
    assert espia.llamadas_proba == 1
    assert clase == modelo.predict(fila)[0]
    for etiqueta, valor in zip(modelo.classes_, modelo.predict_proba(fila)[0]):
        assert p[etiqueta] == pytest.approx(valor)


@pytest.mark.parametrize('meta,rating', [(101,3.9),(82,5.1),(-1,3.9),(82,np.inf)])
def test_formulario_rechaza_escalas_invalidas(modelo,meta,rating):
    with pytest.raises(ValueError):
        predecir_formulario(modelo,['RPG'],['Otro'],2020,meta,rating)


def test_sin_genero_no_se_predice(modelo):
    with pytest.raises(ValueError,match='género'):
        predecir_formulario(modelo,[],['Otro'],2020,82,3.9)


def test_interfaz_envia_valores_del_formulario(modelo):
    import json
    from streamlit.testing.v1 import AppTest
    app=AppTest.from_file(str(ROOT/'pages/2_Prediccion.py')).run(timeout=60)
    app.multiselect[0].set_value(['RPG'])
    app.selectbox[0].set_value('Nintendo')
    app.selectbox[1].set_value(2010)
    app.slider[0].set_value(91)
    app.slider[1].set_value(4.5)
    app.button[0].click().run(timeout=60)
    temperatura = json.loads((MODELS / 'metadata.json').read_text())['calibracion_web']['temperatura']
    fila, clase, probabilidades = predecir_formulario(
        modelo, ['RPG'], ['Nintendo'], 2010, 91, 4.5, temperatura=temperatura,
    )
    assert not app.exception
    assert any(f'Nivel estimado de popularidad: {clase.upper()}' in e.value for e in app.subheader)
    assert clase == modelo.predict(fila)[0]
    assert sum(probabilidades.values()) == pytest.approx(1)
    original = dict(zip(modelo.classes_, modelo.predict_proba(fila)[0]))
    assert probabilidades[clase] != pytest.approx(original[clase])
    barras = next(b.value for b in app.markdown if '<div class="p5-prob-row">' in b.value)
    for nivel, probabilidad in probabilidades.items():
        assert f'<span>{nivel.upper()}</span>\n<span>{probabilidad:.1%}</span>' in barras
    assert any(e.label == '¿Qué significan alto, medio y bajo?' for e in app.expander)
    app.checkbox[0].set_value(True)
    app.button[0].click().run(timeout=60)
    _,clase,_=predecir_formulario(modelo,['RPG'],['Nintendo'],2010,None,4.5)
    assert not app.exception
    assert any(f'Nivel estimado de popularidad: {clase.upper()}' in e.value for e in app.subheader)


def test_interfaz_envia_decada_menos_uno(modelo):
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    assert 'Sin fecha interpretable (Década -1)' in app.selectbox[1].options
    app.multiselect[0].set_value(['RPG'])
    app.selectbox[0].set_value('Nintendo')
    app.selectbox[1].set_value(-1)
    assert app.selectbox[1].value == -1
    app.slider[0].set_value(84)
    app.slider[1].set_value(4.1)
    app.button[0].click().run(timeout=60)
    _, clase, _ = predecir_formulario(modelo, ['RPG'], ['Nintendo'], -1, 84, 4.1)
    assert not app.exception
    assert any(f'Nivel estimado de popularidad: {clase.upper()}' in e.value for e in app.subheader)
    assert len(app.dataframe[0].value) == 5

````

## test_limpieza.py

Ruta: `Final/tests/test_limpieza.py` · Bytes: 8464 · SHA-256: `ececa278a6d9d0c76c574d8c1b24ad191e9ed420713334e48b5da47d888f63ff`

````text
"""Comprueba transformaciones, procedencia y conciliación de filas del log."""
import hashlib
import importlib
import json
import re

import numpy as np
import pandas as pd
import pytest

limpieza = importlib.import_module('src.02_limpieza')


@pytest.mark.parametrize('valor,esperado', [('999', 999), ('1K', 1000), ('1.5M', 1500000),
                                         (' 1.2 K ', 1200), (' 3m ', 3000000), ('1,200', 1200), ('1,500', 1500), (999, 999), (0, 0)])
def test_conversion_k_m(valor, esperado):
    assert limpieza.convertir_conteo(valor) == esperado


@pytest.mark.parametrize('valor', ['', '   ', None, pd.NA, np.nan])
def test_conversion_nulos(valor):
    assert pd.isna(limpieza.convertir_conteo(valor))


@pytest.mark.parametrize('valor', ['texto invalido', '1KK', '-4', '1,5K', 'inf', np.inf])
def test_conversion_invalida_no_imputa(valor):
    with pytest.raises(ValueError, match='Conteo inválido'):
        limpieza.convertir_conteo(valor)


def ejemplo():
    return pd.DataFrame([
        {'ID Original': 1, 'Title': 'Juego A', 'Release Date': 'Feb 25, 2022',
         'Genres': "['RPG', 'Adventure', 'RPG']", 'Rating': 4.5,
         'Metacritic Rating': 90, 'critic_score_final': 90,
         'critic_source': 'metacritic_csv', 'Origen_calificacion': 'Metacritic',
         **{c: '1.2K' for c in limpieza.CONTEOS}},
        {'ID Original': 2, 'Title': 'Juego B', 'Release Date': '10/12/2019',
         'Genres': '[]', 'Rating': np.nan, 'Metacritic Rating': 80,
         'critic_score_final': 80, 'critic_source': 'metacritic_csv',
         'Origen_calificacion': 'Metacritic', **{c: '999' for c in limpieza.CONTEOS}},
        {'ID Original': 3, 'Title': 'Juego C', 'Release Date': 'releases on TBD',
         'Genres': "['Indie']", 'Rating': 4, 'Metacritic Rating': 85,
         'critic_score_final': np.nan, 'critic_source': 'none',
         'Origen_calificacion': 'Estimacion propia', **{c: '0' for c in limpieza.CONTEOS}},
    ])


def test_fechas_mezcladas_y_decadas():
    df = ejemplo()
    df.loc[2, 'Release Date'] = '2020-01-31'
    resultado, _, _, _ = limpieza.limpiar(df)
    assert resultado.anio.tolist() == [2022, 2019, 2020]
    assert resultado.decada.tolist() == [2020, 2010, 2020]
    assert resultado.loc[1, 'fecha_lanzamiento'] == pd.Timestamp('2019-12-10')
    assert limpieza.interpretar_fecha('31/01/2020') == limpieza.interpretar_fecha('January 31, 2020')
    assert limpieza.interpretar_fecha('2020/01/31') == pd.Timestamp('2020-01-31')
    assert pd.isna(limpieza.interpretar_fecha('31/02/2020'))
    assert pd.isna(limpieza.interpretar_fecha('TBD'))
    assert pd.isna(limpieza.interpretar_fecha('Januarchy 31, 2020'))


def test_tbd_no_elimina_ni_inventa_anio():
    resultado, _, _, bitacora = limpieza.limpiar(ejemplo())
    assert pd.isna(resultado.loc[2, 'anio'])
    assert bool(resultado.loc[2, 'fecha_no_interpretable'])
    assert len(resultado) == 3
    assert all(p['antes'] == p['despues'] for p in bitacora.pasos)


def test_genero_principal_conserva_orden_y_largo_no_duplica_pertenencias():
    resultado, largo, _, _ = limpieza.limpiar(ejemplo())
    assert resultado.loc[0, 'genero_principal'] == 'RPG'
    assert pd.isna(resultado.loc[1, 'genero_principal'])
    assert largo.columns.tolist() == ['id_juego', 'juego', 'genero']
    assert largo.loc[largo.id_juego.eq(1), 'genero'].tolist() == ['RPG', 'Adventure']
    assert not largo.duplicated(['id_juego', 'genero']).any()
    assert set(largo.id_juego).issubset(set(resultado.id_juego))


def test_faltantes_no_se_imputan_y_estimada_no_crea_brecha():
    resultado, _, _, _ = limpieza.limpiar(ejemplo())
    assert resultado.loc[0, 'rating_normalizado'] == 90
    assert resultado.loc[0, 'brecha'] == 0
    assert pd.isna(resultado.loc[1, 'Rating']) and bool(resultado.loc[1, 'rating_faltante'])
    assert resultado.loc[2, 'metacritic_rating_original'] == 85
    assert pd.isna(resultado.loc[2, 'Metacritic Rating'])
    assert bool(resultado.loc[2, 'metacritic_rating_faltante'])
    assert not bool(resultado.loc[2, 'metacritic_rating_faltante_original'])
    assert pd.isna(resultado.loc[2, 'brecha'])


def test_metacritic_original_ausente_tiene_indicador():
    df = ejemplo()
    df.loc[1, ['Metacritic Rating', 'critic_score_final']] = np.nan
    resultado, _, _, _ = limpieza.limpiar(df)
    assert bool(resultado.loc[1, 'metacritic_rating_faltante_original'])
    assert bool(resultado.loc[1, 'metacritic_rating_faltante'])


def test_escala_invalida_no_se_normaliza_como_si_fuera_de_cinco():
    df = ejemplo()
    df.loc[0, 'Rating'] = 9
    with pytest.raises(ValueError, match='fuera de la escala documentada'):
        limpieza.limpiar(df)


def test_procedencia_incoherente_es_error():
    df = ejemplo()
    df.loc[2, 'critic_score_final'] = 85
    with pytest.raises(ValueError, match='procedencia coherente'):
        limpieza.limpiar(df)


def con_duplicado():
    df = ejemplo()
    repetido = df.iloc[[0]].copy()
    repetido['ID Original'] = 99
    repetido['Title'] = '  JUEGO   A '
    repetido['Release Date'] = '2022-02-25'
    return pd.concat([df, repetido], ignore_index=True)


def test_duplicados_equivalentes_se_eliminan_con_razon():
    resultado, largo, descartados, bitacora = limpieza.limpiar(con_duplicado())
    assert len(resultado) == 3 and len(descartados) == 1
    cambios = [p for p in bitacora.pasos if p['antes'] != p['despues']]
    assert len(cambios) == 1
    assert cambios[0]['eliminadas'] == 1 and cambios[0]['razon']
    assert not largo.duplicated(['id_juego', 'genero']).any()


def test_mismo_titulo_en_fechas_distintas_no_es_duplicado():
    df = con_duplicado()
    df.loc[3, 'Release Date'] = '2023-02-25'
    resultado, _, descartados, _ = limpieza.limpiar(df)
    assert len(resultado) == 4 and descartados.empty


def test_duplicados_en_conflicto_no_se_descartan_arbitrariamente():
    df = con_duplicado()
    df.loc[3, 'Plays'] = '50K'
    with pytest.raises(ValueError, match='Duplicados en conflicto'):
        limpieza.limpiar(df)


def test_bitacora_rechaza_cambios_sin_razon_o_fuera_de_balance():
    bitacora = limpieza.Bitacora(4)
    with pytest.raises(ValueError, match='razón registrada'):
        bitacora.registrar('Paso', 4, 3, 'Sin explicación', eliminadas=1)
    with pytest.raises(ValueError, match='no coincide'):
        bitacora.registrar('Paso', 4, 3, 'Conteo incorrecto', eliminadas=0)
    with pytest.raises(ValueError, match='fuera del registro'):
        bitacora.registrar('Paso', 3, 3, 'Se perdió una fila antes')
    with pytest.raises(ValueError, match='balance de filas'):
        bitacora.verificar(3)


def test_exportacion_concilia_csv_y_log_sin_modificar_fuente(tmp_path):
    entrada = tmp_path / 'data' / 'raw' / 'games_curated.csv'
    entrada.parent.mkdir(parents=True)
    con_duplicado().to_csv(entrada, index=False)
    huella = hashlib.sha256(entrada.read_bytes()).hexdigest()
    limpieza.ejecutar(tmp_path)
    log = (tmp_path / 'reports' / 'limpieza_log.md').read_text(encoding='utf-8')
    registro = json.loads(re.search(r'```json\n(.*?)\n```', log, re.S)[1])
    datos = pd.read_csv(tmp_path / 'data' / 'clean' / 'dataset_depurado.csv')
    largo = pd.read_csv(tmp_path / 'data' / 'clean' / 'generos_largo.csv')
    assert registro['filas_entrada'] == 4 and registro['filas_salida'] == len(datos) == 3
    assert registro['filas_generos_largo'] == len(largo)
    anterior = registro['filas_entrada']
    for paso in registro['pasos']:
        assert paso['antes'] == anterior
        assert paso['antes'] - paso['despues'] == paso['eliminadas']
        assert paso['antes'] == paso['despues'] or paso['razon']
        anterior = paso['despues']
    assert anterior == len(datos)
    assert registro['filas_entrada'] - sum(p['eliminadas'] for p in registro['pasos']) == len(datos)
    assert hashlib.sha256(entrada.read_bytes()).hexdigest() == huella
    assert huella in log


def test_exportacion_repetida_es_reproducible(tmp_path):
    entrada = tmp_path / 'data' / 'raw' / 'games_curated.csv'
    entrada.parent.mkdir(parents=True)
    ejemplo().to_csv(entrada, index=False)
    limpieza.ejecutar(tmp_path)
    rutas = [tmp_path / 'data' / 'clean' / 'dataset_depurado.csv',
             tmp_path / 'data' / 'clean' / 'generos_largo.csv', tmp_path / 'reports' / 'limpieza_log.md']
    anteriores = [p.read_bytes() for p in rutas]
    limpieza.ejecutar(tmp_path)
    assert anteriores == [p.read_bytes() for p in rutas]

````

## test_modelo.py

Ruta: `Final/tests/test_modelo.py` · Bytes: 4800 · SHA-256: `73c2f50db3927fba206af6728fb00d2f1271962a09b4ac5340b098fce4868c59`

````text
"""Regresiones de la fase 04: target explícito, folds, categorías y artefacto crudo."""
import importlib
import json
from math import ceil

import joblib
import numpy as np
import pandas as pd
import pytest
from sklearn.pipeline import Pipeline

from src.config import FEATURES, ROOT
from src.features import CategoriasFrecuentes
from src.objetivo import CAMPOS_OBJETIVO, definir_objetivo

modulo = importlib.import_module('src.04_modelo')


def test_objetivo_es_promedio_de_rangos_y_no_de_escalas():
    df = pd.DataFrame({'Plays': [10, 10, 20, 40, 80, 160], 'Wishlist': [1, 2, 3, 4, 5, 6], 'Backlogs': [1, 2, 3, 4, 5, 6]})
    out, meta = definir_objetivo(df)
    np.testing.assert_allclose(out.popularidad_indice, df.rank(method='average', pct=True).mean(axis=1))
    assert out.percentil_plays.iloc[0] == out.percentil_plays.iloc[1]
    assert meta['campos'] == CAMPOS_OBJETIVO
    assert set(out.nivel_popularidad) == {'bajo', 'medio', 'alto'}


def test_objetivo_con_empates_sin_tres_niveles_es_error():
    with pytest.raises(ValueError, match='empates'):
        definir_objetivo(pd.DataFrame({c: [1]*10 for c in CAMPOS_OBJETIVO}))


def test_categorias_raras_y_nuevas_se_agrupan_en_otro():
    encoder = CategoriasFrecuentes(min_frecuencia=2).fit(pd.DataFrame({'estudio': [['A'], ['A', 'B'], []]}))
    assert encoder.vocabulario_ == ['A']
    z = encoder.transform(pd.DataFrame({'estudio': [['B'], ['Nuevo'], [], '["A"]']}))
    np.testing.assert_array_equal(z, [[0, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 0]])


def test_holdout_y_diez_folds_respetan_estratos_y_titulos():
    df = pd.read_csv(ROOT / 'data/clean/juegos_modelo.csv')
    train = df[df.particion.eq('entrenamiento')]
    test = df[df.particion.eq('prueba')]
    assert abs(len(test)/len(df) - .2) < .02
    assert not set(train.grupo_titulo) & set(test.grupo_titulo)
    assert train.fold_validacion.nunique() == 10
    for fold in range(1, 11):
        a = train[train.fold_validacion.ne(fold)]
        b = train[train.fold_validacion.eq(fold)]
        assert set(b.nivel_popularidad) == {'bajo', 'medio', 'alto'}
        assert not set(a.grupo_titulo) & set(b.grupo_titulo)
    assert set(test.nivel_popularidad) == {'bajo', 'medio', 'alto'}


def test_archivo_guardado_es_pipeline_y_recibe_formulario_crudo():
    modelo = joblib.load(ROOT / 'models/modelo_popularidad.joblib')
    assert isinstance(modelo, Pipeline)
    fila = pd.DataFrame([{'generos': '["RPG", "Género nuevo"]', 'estudio': 'Estudio nuevo',
                          'decada': 2030, 'Metacritic Rating': np.nan, 'Rating': np.nan}])
    assert modelo.predict(fila)[0] in ['bajo', 'medio', 'alto']
    assert np.isfinite(modelo.predict_proba(fila)).all()
    assert set(FEATURES).isdisjoint(CAMPOS_OBJETIVO + ['Playing', 'cluster_kmeans', 'cluster_dbscan'])


def test_ganador_se_elige_por_cv_y_permuta_solo_campos_crudos():
    tabla = pd.read_csv(ROOT / 'reports/modelo_comparacion.csv')
    meta = json.loads((ROOT / 'models/metadata.json').read_text())
    assert meta['modelo'] == 'RandomForestClassifier'
    externa = pd.read_csv(ROOT / 'reports/tables/cv_externa_folds.csv')
    assert externa.groupby('modelo').size().eq(50).all()
    medias = externa.groupby('modelo').f1_macro.mean()
    assert np.allclose(tabla.set_index('modelo').f1_macro_cv, medias.reindex(tabla.modelo))
    assert set(tabla.modelo) == {'DummyClassifier', 'CategoricalNB', 'DecisionTreeClassifier', 'RandomForestClassifier', 'MLPClassifier'}
    perm = pd.read_csv(ROOT / 'reports/modelo_permutation_importance.csv')
    assert set(perm.variable_cruda) == set(FEATURES)
    assert len(pd.read_csv(ROOT / 'reports/modelo_permutaciones_repeticiones.csv')) == 30
    assert np.asarray(meta['metricas']['matriz_confusion']).sum() == meta['n_prueba']


def test_metadata_declara_referencia_de_entrenamiento_y_fuentes():
    meta = json.loads((ROOT / 'models/metadata.json').read_text())
    assert meta['version_sklearn']
    assert meta['fecha'] and meta['clases'] == ['bajo', 'medio', 'alto']
    assert 'solo en entrenamiento' in meta['definicion_objetivo']['momento_definicion']
    assert meta['definicion_objetivo']['poblacion_referencia_n'] == meta['n_entrenamiento']
    assert meta['validacion']['pliegues'] == 10


def test_imputacion_y_vocabulario_se_ajustan_solo_con_entrenamiento():
    df = pd.read_csv(ROOT / 'data/clean/juegos_modelo.csv')
    train = df[df.particion.eq('entrenamiento')]
    modelo = joblib.load(ROOT / 'models/modelo_popularidad.joblib')
    notas = modelo.named_steps['preparar'].named_transformers_['notas']
    np.testing.assert_allclose(notas.named_steps['imputar'].statistics_, train[['Metacritic Rating', 'Rating']].median())
    assert 'Estudio nuevo' not in modelo.named_steps['preparar'].named_transformers_['estudio'].vocabulario_

````

## test_pipeline.py

Ruta: `Final/tests/test_pipeline.py` · Bytes: 4625 · SHA-256: `b8c010effa91fc3edb8823da62132dc9d40325cda7d192f18433019e62dc014e`

````text
"""Pruebas de los riesgos científicos y de integración principales."""
import json

import joblib
import numpy as np
import pandas as pd
import pytest
from scipy.io import arff
from streamlit.testing.v1 import AppTest

from src.analysis import grouped_correlations
from src.config import CLEAN, FEATURES, MODELS, REPORTS, ROOT, SIGNALS, RAW
from src.data import load_clean, parse_count, parse_list
from src.modeling import levels, thresholds


@pytest.mark.parametrize('raw,expected', [('3.9K', 3900), ('1.2M', 1200000), ('850', 850), ('0', 0)])
def test_suffix(raw, expected):
    assert parse_count(raw) == expected


@pytest.mark.parametrize('raw', ['-5', 'desconocido', '1KK'])
def test_reject_invalid_counts(raw):
    with pytest.raises(ValueError):
        parse_count(raw)


def test_literal_lists_and_missing():
    assert parse_list("['RPG', 'RPG', 'Adventure']") == ['Adventure', 'RPG']
    assert parse_list(np.nan) == []
    with pytest.raises((ValueError, SyntaxError)):
        parse_list('__import__("os").system("false")')


def test_estimates_and_conflicts_excluded():
    df = load_clean()
    assert not df.duplicated(['Title', 'Release Date']).any()
    assert df.loc[df['Origen_calificacion'].ne('Metacritic'), 'critica_verificada_csv'].isna().all()
    pendientes = df.loc[df.conflicto_historico_pendiente]
    assert set(pendientes.id_juego) == {117, 140, 296}
    assert not pendientes.elegible_analisis.any()
    assert not any(c.endswith('_USD') or c == 'unidades_vendidas_estimadas' for c in df.columns)
    assert len(df) == json.loads((REPORTS / 'inspeccion.json').read_text())['filas_limpias']
    assert not set(['rating_100', 'gap', 'gap_real', 'studio_main', 'publisher_main']) & set(df.columns)
    original = ROOT.parent / 'Proyecto' / 'data' / 'processed' / 'games_curated.csv'
    if original.exists():
        assert RAW.read_bytes() == original.read_bytes()


def test_objetivo_fijo_y_predictores_no_contienen_senales():
    from src.objetivo import ajustar_referencia, aplicar_referencia
    from collections import Counter
    df = pd.read_csv(CLEAN / 'juegos_modelo.csv')
    train = df[df.particion.eq('entrenamiento')]
    test = df[df.particion.eq('prueba')]
    model = joblib.load(MODELS / 'modelo_popularidad.joblib')
    metadata = json.loads((MODELS / 'metadata.json').read_text())
    assert set(train.grupo_titulo).isdisjoint(test.grupo_titulo)
    definicion = ajustar_referencia(train)
    esperado = aplicar_referencia(df, definicion)
    np.testing.assert_allclose(metadata['definicion_objetivo']['cortes'], definicion['cortes'])
    assert (esperado.nivel_popularidad.to_numpy() == df.nivel_popularidad.to_numpy()).all()
    assert set(FEATURES).isdisjoint(SIGNALS + ['popularidad_indice', 'nivel_popularidad'])
    encoder = model.named_steps['preparar'].named_transformers_['estudio']
    conteos = Counter(v for row in train.estudio.map(json.loads) for v in row)
    assert set(encoder.vocabulario_) == {v for v, n in conteos.items() if n >= 10}


def test_small_groups_do_not_produce_correlations():
    df = pd.DataFrame({'generos': [['RPG']] * 5, 'Rating': [1, 2, 3, 4, 5],
                       'critica_verificada_csv': [30, 50, 60, 80, 90]})
    row = grouped_correlations(df, 'generos').iloc[0]
    assert row['n'] == 5 and pd.isna(row['r'])


def test_unknown_organizations_and_missing_ratings():
    model = joblib.load(MODELS / 'modelo_popularidad.joblib')
    row = pd.DataFrame([{'generos': ['Género desconocido'], 'estudio': ['Estudio nuevo'],
                         'decada': 2030, 'Rating': np.nan, 'Metacritic Rating': np.nan}])
    assert model.predict(row)[0] in ['bajo', 'medio', 'alto']


def test_arff_partitions_readable():
    for name in ['entrenamiento', 'prueba']:
        data, meta = arff.loadarff(CLEAN / f'{name}_weka.arff')
        exported = pd.read_csv(CLEAN / f'{name}_orange.csv')
        assert len(data) == len(exported)
        assert len(meta.names()) == len(exported.columns)


@pytest.mark.parametrize('page', ['app.py', 'pages/1_Exploracion.py',
                                  'pages/2_Prediccion.py', 'pages/3_Acerca_del_modelo.py'])
def test_app_pages(page):
    app = AppTest.from_file(str(ROOT / page)).run(timeout=60)
    assert not app.exception, [x.message for x in app.exception]
    if 'Prediccion' in page:
        app.button[0].click().run(timeout=30)
        assert not app.exception
        assert any('Nivel estimado' in x.value for x in app.subheader)
    if page == 'app.py':
        app.text_input[0].set_value('NINGUN_JUEGO_123456').run()
        assert not app.exception
        assert app.info

````

## test_regresiones_web.py

Ruta: `Final/tests/test_regresiones_web.py` · Bytes: 20579 · SHA-256: `aa2d2d39cdf7c3bc8691be202294192c3ee3cf93779fb60d062d5060e1648ec5`

````text
"""Pruebas de regresión de lógica web, seguridad HTML, UI y artefactos corruptos."""
import hashlib
import inspect
import json
import pickle
import re
import shutil
import sys

import joblib
import numpy as np
import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

import src.data as data_mod
import src.inferencia as inferencia_mod
import src.pipeline as pipeline_mod
import src.similitud as similitud_mod
import src.ui as ui
import src.visualizacion as vis_mod
import vista_graficas as vg_mod
from src.config import CLEAN, MODELS, REPORTS, ROOT
from src.similitud import cinco_vecinos
from src.visualizacion import FONT_SANS, PALETA


class _PrepProxy:
    """Expone vocabulario de géneros extendido delegando transform() al preprocesador real."""

    def __init__(self, real_prep, extra_generos):
        self._real = real_prep
        gen_real = real_prep.named_transformers_['generos']
        self.named_transformers_ = {
            **real_prep.named_transformers_,
            'generos': type('_GenVocab', (), {'vocabulario_': [*gen_real.vocabulario_, *extra_generos]})(),
        }

    def transform(self, X):
        return self._real.transform(X)


class _PipelineProxy:
    """Envuelve el Pipeline real para habilitar opciones extra en AppTest sin mutar el modelo."""

    def __init__(self, real_pipeline, extra_generos):
        self._real = real_pipeline
        self.classes_ = real_pipeline.classes_
        self.named_steps = {
            **real_pipeline.named_steps,
            'preparar': _PrepProxy(real_pipeline.named_steps['preparar'], extra_generos),
        }

    def predict_proba(self, X):
        return self._real.predict_proba(X)


# ---------------------------------------------------------------------------
# 1. Similitud (src/similitud.py)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    'fila_dict',
    [
        {'generos': ['RPG', 'Adventure'], 'estudio': ['Nintendo'], 'decada': 2020, 'Rating': 4.2, 'Metacritic Rating': 88.0},
        {'generos': ['Indie'], 'estudio': ['Otro'], 'decada': -1, 'Rating': 3.5, 'Metacritic Rating': np.nan},
    ],
)
def test_cinco_vecinos_dos_args_coincide_con_bundle_y_df_clusters(monkeypatch, fila_dict):
    modelo = joblib.load(MODELS / 'modelo_popularidad.joblib')
    vecinos_bundle = joblib.load(MODELS / 'vecinos_popularidad.joblib')
    df_clusters = pd.read_csv(CLEAN / 'dataset_con_clusters.csv')
    fila = pd.DataFrame([fila_dict])

    res_2args = cinco_vecinos(fila, modelo)
    res_con_vecinos = cinco_vecinos(fila, modelo, vecinos=vecinos_bundle)

    # Con vecinos y df_clusters explícitos no debe releer artefactos de disco.
    monkeypatch.setattr(similitud_mod.joblib, 'load', lambda *a, **k: (_ for _ in ()).throw(AssertionError('joblib.load inesperado')))
    monkeypatch.setattr(similitud_mod.pd, 'read_csv', lambda *a, **k: (_ for _ in ()).throw(AssertionError('pd.read_csv inesperado')))
    res_4args = cinco_vecinos(fila, modelo, vecinos=vecinos_bundle, df_clusters=df_clusters)

    assert len(res_2args) == 5
    pd.testing.assert_frame_equal(res_2args, res_con_vecinos)
    pd.testing.assert_frame_equal(res_2args, res_4args)


# ---------------------------------------------------------------------------
# 2. Página de predicción (pages/2_Prediccion.py)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize('genero_excluido,n_esperado', [('Pinball', 1), ('Music', 18)])
def test_prediccion_muestra_resultados_en_orden_con_menos_de_20_pares(monkeypatch, genero_excluido, n_esperado):
    corr_real = pd.read_csv(REPORTS / 'tables/correlacion_generos.csv')
    fila_csv = corr_real.loc[corr_real['grupo'] == genero_excluido].iloc[0]
    assert fila_csv['estado'] != 'incluido'
    assert pd.notna(fila_csv['brecha_absoluta_media'])

    df_real, bundle_real, analysis_real = ui.resources()
    bundle_proxy = {**bundle_real, 'pipeline': _PipelineProxy(bundle_real['pipeline'], [genero_excluido])}
    monkeypatch.setattr(ui, 'resources', lambda: (df_real, bundle_proxy, analysis_real))

    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    assert not app.exception

    app.multiselect[0].set_value([genero_excluido])
    app.button[0].click().run(timeout=60)
    assert not app.exception

    html_total = '\n'.join(m.value for m in app.main.markdown)
    assert f'(n = {n_esperado} pares) hacen falta al menos 20 juegos con ambas notas' in html_total

    posiciones = [
        html_total.index('PROBABILIDAD CALIBRADA POR NIVEL'),
        html_total.index('GRUPO DE JUEGOS PARECIDOS'),
        html_total.index('DIFERENCIA ENTRE NOTAS'),
        html_total.index('Cinco juegos parecidos'),
    ]
    assert posiciones == sorted(posiciones)


def test_prediccion_escapa_html_en_title_y_generos_especiales(monkeypatch):
    genero_xss = 'RPG <script>alert(1)</script> & Acción'
    titulo_xss = 'Juego <img src=x onerror=alert(2)> & "Prueba"'
    genero_vecino_xss = 'Acción & <Aventura>'
    perfil_xss = 'Perfil <b onclick=evil()>Especial & Único</b>'

    df_real, bundle_real, analysis_real = ui.resources()
    df_mod = df_real.copy()
    bundle_proxy = {**bundle_real, 'pipeline': _PipelineProxy(bundle_real['pipeline'], [genero_xss])}

    def _cinco_vecinos_xss(fila, pipeline_arg, vecinos=None, df_clusters=None):
        res = cinco_vecinos(fila, bundle_real['pipeline'], vecinos=bundle_real['vecinos']).copy()
        id_objetivo = int(res.iloc[0]['id_juego'])
        res.loc[res.index[0], 'Title'] = titulo_xss
        df_mod.loc[df_mod['id_juego'] == id_objetivo, 'generos'] = pd.Series(
            [[genero_vecino_xss]], index=df_mod.index[df_mod['id_juego'] == id_objetivo]
        )
        return res

    orig_cached_report = ui._cached_report

    def _cached_report_xss(name, file_hash):
        df_rep = orig_cached_report(name, file_hash).copy()
        if name == 'tables/perfiles_clusters.csv':
            df_rep['perfil_propuesto'] = perfil_xss
        return df_rep

    monkeypatch.setattr(ui, 'resources', lambda: (df_mod, bundle_proxy, analysis_real))
    monkeypatch.setattr(similitud_mod, 'cinco_vecinos', _cinco_vecinos_xss)
    monkeypatch.setattr(ui, '_cached_report', _cached_report_xss)

    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    app.multiselect[0].set_value([genero_xss])
    app.button[0].click().run(timeout=60)
    assert not app.exception

    html_total = '\n'.join(m.value for m in app.main.markdown)
    assert '&lt;script&gt;alert(1)&lt;/script&gt; &amp; Acción' in html_total
    assert '&lt;SCRIPT&gt;ALERT(1)&lt;/SCRIPT&gt; &amp; ACCIÓN' in html_total
    assert '&lt;img src=x onerror=alert(2)&gt; &amp; &quot;Prueba&quot;' in html_total
    assert 'Acción &amp; &lt;Aventura&gt;' in html_total
    assert 'Perfil &lt;b onclick=evil()&gt;Especial &amp; Único&lt;/b&gt;' in html_total
    for crudo in ['<script>alert(1)</script>', '<img src=x', '<Aventura>', '<b onclick=evil()>']:
        assert crudo not in html_total


# ---------------------------------------------------------------------------
# 3. Página Acerca del modelo (pages/3_Acerca_del_modelo.py)
# ---------------------------------------------------------------------------
def test_acerca_modelo_activo_y_contraste_matriz_confusion():
    app = AppTest.from_file(str(ROOT / 'pages/3_Acerca_del_modelo.py')).run(timeout=60)
    assert not app.exception

    shell_html = next(m.value for m in app.main.markdown if '<div class="sp-shell"' in m.value)
    assert '<div class="sp-right" data-sp-id="alg-0" style="display:block;">\n<div class="sp-tag">MODELO ACTIVO</div>\n<div class="sp-right-title">RANDOM FOREST</div>' in shell_html
    assert '<div class="sp-tag">CANDIDATO COMPARADO</div>\n<div class="sp-right-title">RED NEURONAL MLP</div>' in shell_html

    assert len(app.dataframe) == 5
    assert all(not df_el.value.empty for df_el in app.dataframe)

    charts = app.get('plotly_chart')
    assert len(charts) == 4
    for pc in charts:
        spec = json.loads(pc.proto.spec)
        config = json.loads(pc.proto.config or '{}')
        assert spec['layout']['font']['family'] == FONT_SANS
        assert spec['layout']['margin']['t'] >= 44
        assert 'toImage' not in config.get('modeBarButtonsToRemove', [])

    cm_spec = json.loads(charts[1].proto.spec)
    annotations = cm_spec['layout']['annotations']
    assert len(annotations) == 9
    max_val = max(int(a['text']) for a in annotations)
    for ann in annotations:
        esperado = PALETA['bg-primary'] if int(ann['text']) >= 0.45 * max_val else PALETA['text-primary']
        assert ann['font']['color'] == esperado


def test_acerca_modelo_maneja_campos_faltantes_y_escapa_mejores_parametros(monkeypatch):
    df_real, bundle_real, analysis_real = ui.resources()
    metricas_sin_diag = json.loads(json.dumps(bundle_real['metricas']))
    metricas_sin_diag.pop('diagnostico_ausencia', None)
    metricas_sin_diag['modelo'] = 'ModeloCustom_X'
    metricas_sin_diag['metricas']['matriz_confusion'] = [[45, 44, 0], [0, 100, 0], [0, 0, 10]]
    bundle_mod = {**bundle_real, 'metricas': metricas_sin_diag}

    orig_cached_report = ui._cached_report
    payload_xss = '{"param": "<script>alert(9)</script> & \'test\'"}'

    def _cached_report_mod(name, file_hash):
        df_rep = orig_cached_report(name, file_hash).copy()
        if name == 'tables/comparacion_prueba_actual_e_historica.csv':
            fila_extra = df_rep.iloc[-1].copy()
            fila_extra['modelo'] = 'ModeloCustom_X'
            fila_extra['f1_macro_cv'] = 0.40
            fila_extra['mejores_parametros'] = payload_xss
            df_rep = pd.concat([df_rep, pd.DataFrame([fila_extra])], ignore_index=True)
        return df_rep

    monkeypatch.setattr(ui, 'resources', lambda: (df_real, bundle_mod, analysis_real))
    monkeypatch.setattr(ui, '_cached_report', _cached_report_mod)

    app = AppTest.from_file(str(ROOT / 'pages/3_Acerca_del_modelo.py')).run(timeout=60)
    assert not app.exception

    html_total = '\n'.join(m.value for m in app.main.markdown)
    assert '<div class="sp-tag">MODELO ACTIVO</div>\n<div class="sp-right-title">ModeloCustom_X</div>' in html_total
    assert '&lt;script&gt;alert(9)&lt;/script&gt; &amp; &#x27;test&#x27;' in html_total
    assert '<script>alert(9)</script>' not in html_total
    assert all('Diagnóstico de Imputación' not in expander.label for expander in app.expander)

    cm_spec = json.loads(app.get('plotly_chart')[1].proto.spec)
    colores_por_texto = {ann['text']: ann['font']['color'] for ann in cm_spec['layout']['annotations']}
    assert colores_por_texto['45'] == PALETA['bg-primary']
    assert colores_por_texto['44'] == PALETA['text-primary']


# ---------------------------------------------------------------------------
# 4. Página Inicio (app.py) y UI (src/ui.py)
# ---------------------------------------------------------------------------
def test_app_busqueda_con_resultado_y_vacia_y_sin_hero_png():
    app = AppTest.from_file(str(ROOT / 'app.py')).run(timeout=60)
    assert not app.exception
    html_inicial = '\n'.join(m.value for m in app.main.markdown)
    assert 'alt="Take Your Heart"' not in html_inicial
    assert '3 CASOS · DÉCADA -1' in html_inicial
    assert any(e.label == 'Cómo calculamos la popularidad' for e in app.expander)

    app.text_input[0].set_value('Persona').run(timeout=60)
    assert not app.exception
    assert len(app.dataframe) == 1
    df_res = app.dataframe[0].value
    assert not df_res.empty
    assert df_res['Title'].str.contains('persona', case=False, na=False).all()
    assert len(app.get('download_button')) == 1
    assert not any('No hay coincidencias' in info.value for info in app.info)

    app.text_input[0].set_value('TITULO_INEXISTENTE_999').run(timeout=60)
    assert not app.exception
    assert len(app.dataframe) == 0
    assert any('No hay coincidencias' in info.value for info in app.info)


def test_ui_escapa_html_y_registra_el_detalle_de_la_alerta(monkeypatch, tmp_path, caplog):
    renderizados = []
    errores = []
    monkeypatch.setattr(ui, 'FONTS_DIR', tmp_path / 'fuentes_inexistentes')
    monkeypatch.setattr(ui.st, 'markdown', lambda txt, **kw: renderizados.append(txt))
    monkeypatch.setattr(ui.st, 'error', lambda msg: errores.append(msg))

    ui.section_banner('<script>s()</script> & Título', '<img src=x onerror=alert(1)> & Sub')
    ui.render_lb_rb_nav('<b>Sección & Nav</b>')
    ui.render_critical_alert('<script>boom()</script> & "fallo"')

    html_combinado = '\n'.join(renderizados)
    assert '&lt;script&gt;s()&lt;/script&gt; &amp; Título' in html_combinado
    assert '&lt;img src=x onerror=alert(1)&gt; &amp; Sub' in html_combinado
    assert '&lt;b&gt;Sección &amp; Nav&lt;/b&gt;' in html_combinado
    assert '<script>s()</script>' not in html_combinado
    assert '<img src=x' not in html_combinado
    assert '<b>Sección' not in html_combinado
    assert '<script>boom()</script>' in caplog.text
    assert errores == ['No se pudo cargar el observatorio. Recarga la página para volver a intentarlo.']


@pytest.mark.parametrize('exc', [EOFError('archivo truncado'), pickle.UnpicklingError('pickle inválido')])
def test_ui_resources_captura_eof_y_unpickling_error_directo(monkeypatch, exc):
    errores = []
    detenidos = []
    monkeypatch.setattr(ui, '_resources', lambda huella, estado: (_ for _ in ()).throw(exc))
    monkeypatch.setattr(ui.st, 'error', lambda msg: errores.append(msg))
    monkeypatch.setattr(ui.st, 'stop', lambda: detenidos.append(True))

    ui.resources()
    assert detenidos == [True]
    assert errores == ['No se pudo cargar el observatorio. Recarga la página para volver a intentarlo.']


@pytest.mark.parametrize('bytes_corruptos,exc_esperada', [(b'', EOFError), (b'g0\n.', pickle.UnpicklingError)])
def test_ui_resources_captura_joblib_corrupto_end_to_end(monkeypatch, tmp_path, bytes_corruptos, exc_esperada):
    tmp_models = tmp_path / 'models'
    tmp_reports = tmp_path / 'reports'
    tmp_models.mkdir()
    tmp_reports.mkdir()

    shutil.copy2(MODELS / 'metadata.json', tmp_models / 'metadata.json')
    shutil.copy2(MODELS / 'vecinos_popularidad.joblib', tmp_models / 'vecinos_popularidad.joblib')
    modelo_corrupto = tmp_models / 'modelo_popularidad.joblib'
    modelo_corrupto.write_bytes(bytes_corruptos)
    with pytest.raises(exc_esperada):
        joblib.load(modelo_corrupto)
    shutil.copy2(REPORTS / 'clustering_03_parametros.json', tmp_reports / 'clustering_03_parametros.json')

    def _sha(ruta):
        return hashlib.sha256(ruta.read_bytes()).hexdigest()

    manifiesto = {
        'sha256_modelo_popularidad': _sha(tmp_models / 'modelo_popularidad.joblib'),
        'sha256_metadata_modelo': _sha(tmp_models / 'metadata.json'),
        'sha256_vecinos': _sha(tmp_models / 'vecinos_popularidad.joblib'),
        'sha256_dataset_depurado': _sha(CLEAN / 'dataset_depurado.csv'),
        'sha256_dataset_con_clusters': _sha(CLEAN / 'dataset_con_clusters.csv'),
        'sha256_reportes_app': {
            'clustering_03_parametros.json': _sha(tmp_reports / 'clustering_03_parametros.json'),
        },
    }
    (tmp_reports / 'manifest.json').write_text(json.dumps(manifiesto), encoding='utf-8')

    errores = []
    detenidos = []
    monkeypatch.setattr(pipeline_mod, 'REPORTES_APP', ('clustering_03_parametros.json',))
    monkeypatch.setattr(ui, 'MODELS', tmp_models)
    monkeypatch.setattr(ui, 'REPORTS', tmp_reports)
    monkeypatch.setattr(ui.st, 'error', lambda msg: errores.append(msg))
    monkeypatch.setattr(ui.st, 'stop', lambda: detenidos.append(True))

    ui.resources()
    assert detenidos == [True]
    assert errores == ['No se pudo cargar el observatorio. Recarga la página para volver a intentarlo.']


def test_ui_setup_render_page_transition_solo_al_cambiar_de_pagina(monkeypatch):
    estado_sesion = {}
    transiciones = []

    monkeypatch.setattr(ui.st, 'session_state', estado_sesion)
    monkeypatch.setattr(ui.st, 'set_page_config', lambda **kw: None)
    monkeypatch.setattr(ui, 'inject_p5_css', lambda: None)
    monkeypatch.setattr(ui, 'render_page_transition', lambda variant='default': transiciones.append(variant))
    monkeypatch.setattr(ui, 'render_p5_main_menu', lambda **kw: None)
    monkeypatch.setattr(ui, 'render_sidebar_audio', lambda: None)
    monkeypatch.setattr(ui.st, 'title', lambda *a, **kw: None)
    monkeypatch.setattr(ui.st, 'caption', lambda *a, **kw: None)
    monkeypatch.setattr(ui, '_inject_parent_interactive_engine', lambda: None)

    ui.setup('Inicio', transition='default', menu_idx=0)
    ui.setup('Inicio', transition='default', menu_idx=0)
    ui.setup('Exploración', transition='about', menu_idx=1)
    ui.setup('Exploración', transition='about', menu_idx=1)
    assert transiciones == ['default', 'about']


def test_ui_apptest_transicion_solo_en_carga_inicial_no_en_rerun():
    app_inicio = AppTest.from_file(str(ROOT / 'app.py')).run(timeout=60)
    assert sum('<div class="p5-transition-layer"' in m.value for m in app_inicio.main.markdown) == 1
    app_inicio.text_input[0].set_value('Zelda').run(timeout=60)
    assert sum('<div class="p5-transition-layer"' in m.value for m in app_inicio.main.markdown) == 0

    app_pred = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    assert sum('<div class="p5-transition-layer"' in m.value for m in app_pred.main.markdown) == 1
    app_pred.button[0].click().run(timeout=60)
    assert sum('<div class="p5-transition-layer"' in m.value for m in app_pred.main.markdown) == 0


def test_recarga_en_caliente_actualiza_modulos_obsoletos(monkeypatch):
    # Simula sesión en vivo con módulos previos en sys.modules (firma antigua de 2 args y v8).
    monkeypatch.setattr(similitud_mod, 'cinco_vecinos', lambda fila, pipeline: None)
    for mod in (data_mod, inferencia_mod, similitud_mod, vis_mod, vg_mod):
        monkeypatch.setattr(mod, '_MOD_VERSION', 'p5-v8-neon', raising=False)
    monkeypatch.setattr(ui, '_UI_VERSION', 'p5-v8-neon', raising=False)
    monkeypatch.delattr(data_mod, 'asegurar_modulos_vigentes')

    app_pred = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    assert not app_pred.exception
    app_pred.button[0].click().run(timeout=60)
    assert not app_pred.exception
    assert len(app_pred.dataframe[0].value) == 5

    sim_vigente = sys.modules['src.similitud']
    assert 'vecinos' in inspect.signature(sim_vigente.cinco_vecinos).parameters
    assert getattr(sys.modules['src.ui'], '_UI_VERSION', None) == 'p5-v11-arte'
    for nombre in ('src.data', 'src.inferencia', 'src.similitud', 'src.visualizacion', 'vista_graficas'):
        assert getattr(sys.modules[nombre], '_MOD_VERSION', None) == 'p5-v11-arte'

    # Incluso si _MOD_VERSION coincidiera, detectar firma antigua de cinco_vecinos debe recargar src.similitud.
    monkeypatch.setattr(sim_vigente, 'cinco_vecinos', lambda fila, pipeline: None)
    recargados = sys.modules['src.data'].asegurar_modulos_vigentes()
    assert 'src.similitud' in recargados
    assert 'vecinos' in inspect.signature(sys.modules['src.similitud'].cinco_vecinos).parameters


def test_prediccion_recarga_la_firma_anterior_a_la_calibracion(monkeypatch):
    def predecir_anterior(pipeline, generos, estudio, decada, metacritic, rating):
        raise AssertionError('Streamlit conservó la función anterior en memoria')

    monkeypatch.setattr(inferencia_mod, 'predecir_formulario', predecir_anterior)
    app = AppTest.from_file(str(ROOT / 'pages/2_Prediccion.py')).run(timeout=60)
    assert not app.exception
    assert any('PROBABILIDAD CALIBRADA POR NIVEL' in m.value for m in app.main.markdown)


def test_css_p5_banner_y_tarjetas_alinean_al_cien_por_ciento():
    css = (ROOT / 'assets/css/persona5.css').read_text(encoding='utf-8')
    bloque_banner = re.search(r'(?m)^\.p5-banner\s*\{([^}]*)\}', css)
    assert bloque_banner is not None
    reglas_banner = bloque_banner.group(1)
    assert 'display: block;' in reglas_banner
    assert 'display: inline-block;' not in reglas_banner
    assert 'width: 100%;' in reglas_banner
    assert 'box-sizing: border-box;' in reglas_banner

    for selector in ('p5-card', 'p5-card-accent', 'p5-callout-warning'):
        bloque = re.search(rf'(?m)^\.{selector}\s*\{{([^}}]*)\}}', css)
        assert bloque is not None
        assert 'width: 100%;' in bloque.group(1)
        assert 'box-sizing: border-box;' in bloque.group(1)

````

## test_visualizacion.py

Ruta: `Final/tests/test_visualizacion.py` · Bytes: 4381 · SHA-256: `dc3dc83fb28985d8e1fd93b17d442bc4d12e141ac23078a86640b0a7e85c5f9c`

````text
"""Verifica que la presentación conserve datos, errores y escalas."""
import plotly.graph_objects as go
import pytest
from src.visualizacion import etiquetas_fuera_del_error, COLOR_SENALES


def test_etiqueta_vertical_separa_error_sin_cambiar_datos():
    fig = go.Figure(go.Bar(x=['NB', 'RF'], y=[.549, .557], error_y=dict(array=[.06, .04])))
    fig.update_yaxes(range=[0, .72])
    etiquetas_fuera_del_error(fig, desplazamiento_categoria=-.8/3)
    assert list(fig.data[0].y) == [.549, .557]
    assert list(fig.data[0].error_y.array) == [.06, .04]
    assert list(fig.layout.yaxis.range) == [0, .72]
    assert fig.layout.annotations[0].y == pytest.approx(.609)
    assert fig.layout.annotations[0].x == pytest.approx(-.8/3)
    assert fig.layout.annotations[0].yshift > 0


def test_etiqueta_horizontal_queda_despues_del_intervalo():
    fig = go.Figure(go.Bar(x=[.0833], y=['Rating'], orientation='h', error_x=dict(array=[.022])))
    fig.update_xaxes(range=[0, .115])
    etiquetas_fuera_del_error(fig, sufijo=' F1')
    etiqueta = fig.layout.annotations[0]
    assert etiqueta.x == pytest.approx(.1053)
    assert etiqueta.xanchor == 'left' and etiqueta.xshift > 0
    assert etiqueta.text == '0.0833 F1'
    assert list(fig.data[0].x) == [.0833]
    assert list(fig.data[0].error_x.array) == [.022]
    assert list(fig.layout.xaxis.range) == [0, .115]


def test_colores_semanticos_consistentes():
    assert COLOR_SENALES == {'Plays': '#00CFFF', 'Backlogs': '#8B9CFF', 'Wishlist': '#FFD166'}


def test_tema_logaritmico_conserva_escala_datos_y_rango():
    from src.ui import p5_plotly_layout
    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[10, 100, 1000]))
    fig.update_yaxes(type='log', range=[1, 3])
    p5_plotly_layout(fig, title='Comprobación de escala')
    assert fig.layout.yaxis.type == 'log'
    assert fig.layout.yaxis.dtick == 1
    assert list(fig.layout.yaxis.range) == [1, 3]
    assert list(fig.data[0].y) == [10, 100, 1000]


def test_p5_plotly_layout_usa_font_sans_y_margen_superior_minimo():
    from src.ui import p5_plotly_layout
    from src.visualizacion import FONT_SANS

    fig_sin_titulo = p5_plotly_layout(go.Figure(go.Scatter(x=[1, 2], y=[3, 4])), title='')
    assert fig_sin_titulo.layout.margin.t >= 44
    assert fig_sin_titulo.layout.font.family == FONT_SANS
    assert fig_sin_titulo.layout.title.font.family == FONT_SANS
    assert fig_sin_titulo.layout.legend.font.family == FONT_SANS
    assert fig_sin_titulo.layout.hoverlabel.font.family == FONT_SANS
    assert fig_sin_titulo.layout.xaxis.tickfont.family == FONT_SANS
    assert fig_sin_titulo.layout.xaxis.title.font.family == FONT_SANS
    assert fig_sin_titulo.layout.yaxis.tickfont.family == FONT_SANS
    assert fig_sin_titulo.layout.yaxis.title.font.family == FONT_SANS

    titulo_largo = 'Distribución comparativa de señales de popularidad en el catálogo completo'
    fig_con_titulo = p5_plotly_layout(go.Figure(go.Bar(x=['A'], y=[1])), title=titulo_largo)
    assert fig_con_titulo.layout.margin.t >= 48 >= 44
    assert fig_con_titulo.layout.font.family == FONT_SANS


def test_vista_graficas_mostrar_grafica_preserva_fuente_margen_y_toimage(monkeypatch):
    import vista_graficas
    from src.visualizacion import FONT_SANS

    capturado = {}
    monkeypatch.setattr(vista_graficas.st, 'subheader', lambda texto: capturado.setdefault('titulo', texto))
    monkeypatch.setattr(
        vista_graficas.st,
        'plotly_chart',
        lambda fig, **kwargs: capturado.update({'fig': fig, 'kwargs': kwargs}) or 'ok',
    )

    fig = go.Figure(go.Bar(x=[10, 20], y=['A', 'B'], orientation='h'))
    resultado = vista_graficas.mostrar_grafica(fig, 'Gráfica de prueba', alto=390)

    assert resultado == 'ok'
    assert capturado['titulo'] == 'Gráfica de prueba'
    fig_out = capturado['fig']
    assert fig_out.layout.font.family == FONT_SANS
    assert fig_out.layout.xaxis.tickfont.family == FONT_SANS
    assert fig_out.layout.yaxis.tickfont.family == FONT_SANS
    assert fig_out.layout.xaxis.automargin is True
    assert fig_out.layout.yaxis.automargin is True
    assert fig_out.layout.margin.t >= 48 >= 44
    assert fig_out.layout.legend.font.size == 12
    config = capturado['kwargs']['config']
    assert config['displaylogo'] is False
    assert config['responsive'] is True
    assert 'toImage' not in config.get('modeBarButtonsToRemove', [])

````

