# Carpeta: MenuVersion2

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `MenuVersion2/BITACORA_UNIFICADA.md` · Bytes: 161 · SHA-256: `7ecea541d3d45845e3f2b12f62b9976a9eec9e16e02b61fa591dde69c8612255`

````text
# Referencias de menú

- Se conservaron las fuentes de los tres prototipos y sus licencias. Se retiraron el compilado local y node_modules del prototipo Decky.

````

## package-lock.json

Ruta: `MenuVersion2/package-lock.json` · Bytes: 91 · SHA-256: `da8e289907e43d247df4295a828f767c0f60b208dbcf23e640875860d198c8dc`

````text
{
  "name": "MenuVersion2",
  "lockfileVersion": 3,
  "requires": true,
  "packages": {}
}

````

