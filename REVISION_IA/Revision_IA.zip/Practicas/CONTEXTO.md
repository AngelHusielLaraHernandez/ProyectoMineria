# Carpeta: Practicas

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `Practicas/BITACORA_UNIFICADA.md` · Bytes: 172 · SHA-256: `22cc3ddb6562288ed5c07106c8ecde9de198faf2d07a3010d0715bba26678726`

````text
# Prácticas de la materia

- Se conservaron los informes de las prácticas 2 y 3. El cuaderno de la tienda corresponde a la práctica 3. Se retiraron auxiliares de LaTeX.

````

