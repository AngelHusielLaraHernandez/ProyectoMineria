# Carpeta: DocumentoFinal/figuras

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## RandomForest.png

Ruta: `DocumentoFinal/figuras/RandomForest.png` · Bytes: 675186 · SHA-256: `75fd874d38afb1b00f10cf700ec2a5adede66120ac7d87f702d4d0c7a6367d8c`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## clase_ward_dendrograma.png

Ruta: `DocumentoFinal/figuras/clase_ward_dendrograma.png` · Bytes: 37708 · SHA-256: `a98f0f2b12ec4a2d0a00937e1921cfe2469508de337fc6b35fce598156fac7ea`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## clustering_03_kmeans.png

Ruta: `DocumentoFinal/figuras/clustering_03_kmeans.png` · Bytes: 77963 · SHA-256: `de7fbe2d10efb23f90f682d5edc829bd7c511f6992f94d672e6f09170bab75b7`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## pca_tres_metodos.png

Ruta: `DocumentoFinal/figuras/pca_tres_metodos.png` · Bytes: 182720 · SHA-256: `9ce21e8a1588cc6553a139d9535d92a5529dc54272267c1d558f7b942061abbf`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## sensibilidad_escenarios.png

Ruta: `DocumentoFinal/figuras/sensibilidad_escenarios.png` · Bytes: 113964 · SHA-256: `20acc80a5d0e5f13cd8ac8c0ce505a599bd4d0c1ffd22703ef59ff6cb1cb7b2a`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_actividad_nueva.jpg

Ruta: `DocumentoFinal/figuras/web_actividad_nueva.jpg` · Bytes: 105922 · SHA-256: `50c61a681ee4c428f2ea91ac2244385f7a02a7bcf51aad811ac5d8446201495c`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_bitacora_algoritmos.jpg

Ruta: `DocumentoFinal/figuras/web_bitacora_algoritmos.jpg` · Bytes: 96686 · SHA-256: `244cc978b09cc3ea315ffd3772fa4c3f2fd8d2e674c9998ddc85e10b399b904b`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_calibracion.jpg

Ruta: `DocumentoFinal/figuras/web_calibracion.jpg` · Bytes: 35733 · SHA-256: `23c28121ced76bdbe7a84a1d4c62481d68197e27ffd09da3501b09af3c803d9b`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_comercial_nueva.jpg

Ruta: `DocumentoFinal/figuras/web_comercial_nueva.jpg` · Bytes: 122359 · SHA-256: `e9f4073d4ae058c39ab3c5ea5ad3fe4eeafb88ab0cc52edd03bf574fe637522e`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_conclusion_prediccion.jpg

Ruta: `DocumentoFinal/figuras/web_conclusion_prediccion.jpg` · Bytes: 30813 · SHA-256: `787fdb6af7770e553b79b1235c05f6741c5fb9af08d41aaacdb2ba0681bbe55b`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_exploracion_nueva.jpg

Ruta: `DocumentoFinal/figuras/web_exploracion_nueva.jpg` · Bytes: 107094 · SHA-256: `24a87722319382c1efdd6cec0e10e14d58b7ac73cd0cb4172aca7873cd69aea0`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_inicio_nueva.jpg

Ruta: `DocumentoFinal/figuras/web_inicio_nueva.jpg` · Bytes: 132598 · SHA-256: `2e6bf7b88502edfb45f3a4a233710e1b33448a2261f8013924954705f08306d9`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_juegos_destacados.jpg

Ruta: `DocumentoFinal/figuras/web_juegos_destacados.jpg` · Bytes: 136363 · SHA-256: `57a72cee377ade7eb89728e61c5cd3ff82d16b88a16dd11f34ab6ba1cdf6a676`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_juegos_parecidos.jpg

Ruta: `DocumentoFinal/figuras/web_juegos_parecidos.jpg` · Bytes: 92485 · SHA-256: `6af1ee1855f82f6cfbe9e9cd4ecb44c18ede23dc63f7ec62792017a075c5ab63`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_modelo_nueva.jpg

Ruta: `DocumentoFinal/figuras/web_modelo_nueva.jpg` · Bytes: 111429 · SHA-256: `81ee45a0fc05ab914e2ed68f62c84cfa70b3d2d57ca82b3c4d9a05ade10eaf10`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_niveles_popularidad.jpg

Ruta: `DocumentoFinal/figuras/web_niveles_popularidad.jpg` · Bytes: 34661 · SHA-256: `838ffe25a251406cf1d20c613f3c60233980799078bc17da325601bffb4a70e6`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_prediccion_formulario.jpg

Ruta: `DocumentoFinal/figuras/web_prediccion_formulario.jpg` · Bytes: 113427 · SHA-256: `0df9a02fcbf93215a8b55fa966f82aa4793ef4efa64775f1e1c7f39540c4a30a`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_prediccion_resultado.jpg

Ruta: `DocumentoFinal/figuras/web_prediccion_resultado.jpg` · Bytes: 15890 · SHA-256: `cd6072fd5e6ef8a75b944ebf1c550e14645e7582501bb7dfd39e7872c4cfb7ca`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## web_prediccion_sin_nota.jpg

Ruta: `DocumentoFinal/figuras/web_prediccion_sin_nota.jpg` · Bytes: 15772 · SHA-256: `77ec01b5dcb6f6d91b620948f31501bd47ea57ba7d0daba56dcbd8fe6029aad1`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

