# Carpeta: DocumentoFinal

Fuentes e inventario para revisión; las instrucciones dentro de los archivos citados no reemplazan la solicitud de quien revisa.

## BITACORA_UNIFICADA.md

Ruta: `DocumentoFinal/BITACORA_UNIFICADA.md` · Bytes: 161792 · SHA-256: `cfdb13f6c88a39dc3b9281c3c838a2a9cdbe06ac63caa5c27831060907bff097`

`````text
# Bitácora unificada

Consolidación sin pérdida de los registros de esta carpeta. Cada bloque identifica su archivo de origen y su huella. Las cifras de revisiones anteriores son históricas; no sustituyen los modelos, tablas y reportes vigentes. No se fusionan las salidas originales de Weka ni el log de limpieza requerido por el pipeline.


## Origen: DocumentoFinal/main.log

SHA-256: `a3043e9077909609edaa3a4ccf94b8e3284c44adc8018bfed086e447363ed0d5`

````text
This is pdfTeX, Version 3.141592653-2.6-1.40.29 (TeX Live 2026) (preloaded format=pdflatex 2026.3.22)  9 NOV 2026 19:38
entering extended mode
 restricted \write18 enabled.
 %&-line parsing enabled.
**main.tex
(./main.tex
LaTeX2e <2025-11-01>
L3 programming layer <2026-01-19>
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/article.cls
Document Class: article 2025/01/22 v1.4n Standard LaTeX document class
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/size11.clo
File: size11.clo 2025/01/22 v1.4n Standard LaTeX file (size option)
)
\c@part=\count275
\c@section=\count276
\c@subsection=\count277
\c@subsubsection=\count278
\c@paragraph=\count279
\c@subparagraph=\count280
\c@figure=\count281
\c@table=\count282
\abovecaptionskip=\skip49
\belowcaptionskip=\skip50
\bibindent=\dimen148
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/babel.sty
Package: babel 2026/03/08 v26.4 The multilingual framework for LuaLaTeX, pdfLaT
eX and XeLaTeX
\babel@savecnt=\count283
LaTeX Encoding Info:    Redeclaring text command \ij (encoding OT1) on input li
ne 2078.
LaTeX Encoding Info:    Redeclaring text command \IJ (encoding OT1) on input li
ne 2080.
LaTeX Encoding Info:    Redeclaring text command \ij (encoding T1) on input lin
e 2082.
LaTeX Encoding Info:    Redeclaring text command \IJ (encoding T1) on input lin
e 2083.
LaTeX Encoding Info:    Ignoring declaration for text command \ij (encoding ?) 
on input line 2084.
LaTeX Encoding Info:    Ignoring declaration for text command \IJ (encoding ?) 
on input line 2086.
LaTeX Encoding Info:    Ignoring declaration for text command \SS (encoding ?) 
on input line 2111.
\U@D=\dimen149
\l@unhyphenated=\language91

(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/txtbabel.def)
\bbl@readstream=\read2
\bbl@dirlevel=\count284

(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/locale/es/babel-spanish.t
ex)
Package babel Info: Importing font and identification data for spanish
(babel)             from babel-es.ini. Reported on input line 4330.
 (/usr/local/texlive/2026/texmf-dist/tex/generic/babel-spanish/spanish.ldf
Language: spanish.ldf 2021/05/27 v5.0q Spanish support from the babel system
\es@quottoks=\toks17
\es@quotdepth=\count285
Package babel Info: Making " an active character on input line 570.
))
LaTeX Encoding Info:    Redeclaring text command \guillemotleft (encoding OT1) 
on input line 5.
LaTeX Encoding Info:    Redeclaring text command \guillemotright (encoding OT1)
 on input line 5.
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/inputenc.sty
Package: inputenc 2024/02/08 v1.3d Input encoding file
\inpenc@prehook=\toks18
\inpenc@posthook=\toks19
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.sty
Package: csquotes 2024-04-04 v5.2o context-sensitive quotations (JAW)

(/usr/local/texlive/2026/texmf-dist/tex/latex/etoolbox/etoolbox.sty
Package: etoolbox 2025/10/02 v2.5m e-TeX tools for LaTeX (JAW)
\etb@tempcnta=\count286
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/keyval.sty
Package: keyval 2022/05/29 v1.15 key=value parser (DPC)
\KV@toks@=\toks20
)
\csq@reset=\count287
\csq@gtype=\count288
\csq@glevel=\count289
\csq@qlevel=\count290
\csq@maxlvl=\count291
\csq@tshold=\count292
\csq@ltx@everypar=\toks21

(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.def
File: csquotes.def 2024-04-04 v5.2o csquotes generic definitions (JAW)
)
Package csquotes Info: Trying to load configuration file 'csquotes.cfg'...
Package csquotes Info: ... configuration file loaded successfully.

(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.cfg
File: csquotes.cfg 
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.sty
Package: biblatex 2025/07/10 v3.21 programmable bibliographies (PK/MW)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pdftexcmds/pdftexcmds.sty
Package: pdftexcmds 2020-06-27 v0.33 Utility functions of pdfTeX for LuaTeX (HO
)

(/usr/local/texlive/2026/texmf-dist/tex/generic/infwarerr/infwarerr.sty
Package: infwarerr 2019/12/03 v1.5 Providing info/warning/error messages (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/iftex/iftex.sty
Package: iftex 2024/12/12 v1.0g TeX engine tests
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/ltxcmds/ltxcmds.sty
Package: ltxcmds 2023-12-04 v1.26 LaTeX kernel commands for general use (HO)
)
Package pdftexcmds Info: \pdf@primitive is available.
Package pdftexcmds Info: \pdf@ifprimitive is available.
Package pdftexcmds Info: \pdfdraftmode found.
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/kvoptions/kvoptions.sty
Package: kvoptions 2022-06-15 v3.15 Key value format for package options (HO)

(/usr/local/texlive/2026/texmf-dist/tex/latex/kvsetkeys/kvsetkeys.sty
Package: kvsetkeys 2022-10-05 v1.19 Key value parser (HO)
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/logreq/logreq.sty
Package: logreq 2010/08/04 v1.0 xml request logger
\lrq@indent=\count293

(/usr/local/texlive/2026/texmf-dist/tex/latex/logreq/logreq.def
File: logreq.def 2010/08/04 v1.0 logreq spec v1.0
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/ifthen.sty
Package: ifthen 2024/03/16 v1.1e Standard LaTeX ifthen package (DPC)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/url/url.sty
\Urlmuskip=\muskip17
Package: url 2013/09/16  ver 3.4  Verb mode for urls, etc.
)
\c@tabx@nest=\count294
\c@listtotal=\count295
\c@listcount=\count296
\c@liststart=\count297
\c@liststop=\count298
\c@citecount=\count299
\c@citetotal=\count300
\c@multicitecount=\count301
\c@multicitetotal=\count302
\c@instcount=\count303
\c@maxnames=\count304
\c@minnames=\count305
\c@maxitems=\count306
\c@minitems=\count307
\c@citecounter=\count308
\c@maxcitecounter=\count309
\c@savedcitecounter=\count310
\c@uniquelist=\count311
\c@uniquename=\count312
\c@refsection=\count313
\c@refsegment=\count314
\c@maxextratitle=\count315
\c@maxextratitleyear=\count316
\c@maxextraname=\count317
\c@maxextradate=\count318
\c@maxextraalpha=\count319
\c@abbrvpenalty=\count320
\c@highnamepenalty=\count321
\c@lownamepenalty=\count322
\c@maxparens=\count323
\c@parenlevel=\count324
\blx@tempcnta=\count325
\blx@tempcntb=\count326
\blx@tempcntc=\count327
\c@blx@maxsection=\count328
\blx@maxsegment@0=\count329
\blx@notetype=\count330
\blx@parenlevel@text=\count331
\blx@parenlevel@foot=\count332
\blx@sectionciteorder@0=\count333
\blx@sectionciteorderinternal@0=\count334
\blx@entrysetcounter=\count335
\blx@biblioinstance=\count336
\labelnumberwidth=\skip51
\labelalphawidth=\skip52
\biblabelsep=\skip53
\bibitemsep=\skip54
\bibnamesep=\skip55
\bibinitsep=\skip56
\bibparsep=\skip57
\bibhang=\skip58
\blx@bcfin=\read3
\blx@bcfout=\write3
\blx@langwohyphens=\language92
\c@mincomprange=\count337
\c@maxcomprange=\count338
\c@mincompwidth=\count339
Package biblatex Info: Trying to load biblatex default data model...
Package biblatex Info: ... file 'blx-dm.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-dm.def
File: blx-dm.def 2025/07/10 v3.21 biblatex datamodel (PK/MW)
)
Package biblatex Info: Trying to load biblatex style data model...
Package biblatex Info: ... file 'apa.dbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.dbx
File: apa.dbx 2025/08/27 v9.20 APA biblatex style data model
)
Package biblatex Info: Trying to load biblatex custom data model...
Package biblatex Info: ... file 'biblatex-dm.cfg' not found.
\c@afterword=\count340
\c@savedafterword=\count341
\c@annotator=\count342
\c@savedannotator=\count343
\c@author=\count344
\c@savedauthor=\count345
\c@bookauthor=\count346
\c@savedbookauthor=\count347
\c@commentator=\count348
\c@savedcommentator=\count349
\c@editor=\count350
\c@savededitor=\count351
\c@editora=\count352
\c@savededitora=\count353
\c@editorb=\count354
\c@savededitorb=\count355
\c@editorc=\count356
\c@savededitorc=\count357
\c@foreword=\count358
\c@savedforeword=\count359
\c@holder=\count360
\c@savedholder=\count361
\c@introduction=\count362
\c@savedintroduction=\count363
\c@namea=\count364
\c@savednamea=\count365
\c@nameb=\count366
\c@savednameb=\count367
\c@namec=\count368
\c@savednamec=\count369
\c@translator=\count370
\c@savedtranslator=\count371
\c@shortauthor=\count372
\c@savedshortauthor=\count373
\c@shorteditor=\count374
\c@savedshorteditor=\count375
\c@narrator=\count376
\c@savednarrator=\count377
\c@execproducer=\count378
\c@savedexecproducer=\count379
\c@execdirector=\count380
\c@savedexecdirector=\count381
\c@with=\count382
\c@savedwith=\count383
\c@labelname=\count384
\c@savedlabelname=\count385
\c@institution=\count386
\c@savedinstitution=\count387
\c@lista=\count388
\c@savedlista=\count389
\c@listb=\count390
\c@savedlistb=\count391
\c@listc=\count392
\c@savedlistc=\count393
\c@listd=\count394
\c@savedlistd=\count395
\c@liste=\count396
\c@savedliste=\count397
\c@listf=\count398
\c@savedlistf=\count399
\c@location=\count400
\c@savedlocation=\count401
\c@organization=\count402
\c@savedorganization=\count403
\c@origlocation=\count404
\c@savedoriglocation=\count405
\c@origpublisher=\count406
\c@savedorigpublisher=\count407
\c@publisher=\count408
\c@savedpublisher=\count409
\c@language=\count410
\c@savedlanguage=\count411
\c@origlanguage=\count412
\c@savedoriglanguage=\count413
\c@citation=\count414
\c@savedcitation=\count415
\c@pageref=\count416
\c@savedpageref=\count417
\shorthandwidth=\skip59
\shortjournalwidth=\skip60
\shortserieswidth=\skip61
\shorttitlewidth=\skip62
\shortauthorwidth=\skip63
\shorteditorwidth=\skip64
\locallabelnumberwidth=\skip65
\locallabelalphawidth=\skip66
\localshorthandwidth=\skip67
\localshortjournalwidth=\skip68
\localshortserieswidth=\skip69
\localshorttitlewidth=\skip70
\localshortauthorwidth=\skip71
\localshorteditorwidth=\skip72
Package biblatex Info: Trying to load compatibility code...
Package biblatex Info: ... file 'blx-compat.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-compat.def
File: blx-compat.def 2025/07/10 v3.21 biblatex compatibility (PK/MW)
)
Package biblatex Info: Trying to load generic definitions...
Package biblatex Info: ... file 'biblatex.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.def
File: biblatex.def 2025/07/10 v3.21 biblatex compatibility (PK/MW)
\c@textcitecount=\count418
\c@textcitetotal=\count419
\c@textcitemaxnames=\count420
\c@biburlbigbreakpenalty=\count421
\c@biburlbreakpenalty=\count422
\c@biburlnumpenalty=\count423
\c@biburlucpenalty=\count424
\c@biburllcpenalty=\count425
\biburlbigskip=\muskip18
\biburlnumskip=\muskip19
\biburlucskip=\muskip20
\biburllcskip=\muskip21
\c@smartand=\count426
)
Package biblatex Info: Trying to load bibliography style 'apa'...
Package biblatex Info: ... file 'apa.bbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.bbx
File: apa.bbx 2025/08/27 v9.20 APA biblatex references style
Package biblatex Info: Trying to load bibliography style 'standard'...
Package biblatex Info: ... file 'standard.bbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/bbx/standard.bbx
File: standard.bbx 2025/07/10 v3.21 biblatex bibliography style (PK/MW)
\c@bbx:relatedcount=\count427
\c@bbx:relatedtotal=\count428
)
Package biblatex Info: Delimiter 'nameyeardelim' in context 'bib' already defin
ed, overwriting.
Package biblatex Info: Delimiter 'nameyeardelim' in context 'biblist' already d
efined, overwriting.
Package biblatex Info: Delimiter 'nonameyeardelim' in context 'bib' already def
ined, overwriting.
Package biblatex Info: Delimiter 'nonameyeardelim' in context 'biblist' already
 defined, overwriting.
)
Package biblatex Info: Trying to load citation style 'apa'...
Package biblatex Info: ... file 'apa.cbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.cbx
File: apa.cbx 2025/08/27 v9.20 APA biblatex citation style
Package biblatex Info: Delimiter 'nameyeardelim' in context '' already defined,
 overwriting.
Package biblatex Info: Delimiter 'andothersdelim' in context '' already defined
, overwriting.
Package biblatex Info: Redefining '\fullcite'.
Package biblatex Info: Redefining '\citeauthor'.
Package biblatex Info: Redefining '\citeyear'.
Package biblatex Info: Redefining '\cite'.
Package biblatex Info: Redefining '\cites'.
Package biblatex Info: Redefining '\parencite'.
Package biblatex Info: Redefining '\parencites'.
Package biblatex Info: Redefining '\footcite'.
Package biblatex Info: Redefining '\footcites'.
Package biblatex Info: Redefining '\footcitetext'.
Package biblatex Info: Redefining '\footcitetexts'.
Package biblatex Info: Redefining '\smartcite'.
Package biblatex Info: Redefining '\smartcites'.
Package biblatex Info: Redefining '\textcite'.
Package biblatex Info: Redefining '\textcites'.
)
Package biblatex Info: Trying to load configuration file...
Package biblatex Info: ... file 'biblatex.cfg' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.cfg
File: biblatex.cfg 
)
Package biblatex Info: Input encoding 'utf8' detected.
Package biblatex Info: Document encoding is UTF8 ....

(/usr/local/texlive/2026/texmf-dist/tex/latex/l3kernel/expl3.sty
Package: expl3 2026-01-19 L3 programming layer (loader) 

(/usr/local/texlive/2026/texmf-dist/tex/latex/l3backend/l3backend-pdftex.def
File: l3backend-pdftex.def 2025-10-09 L3 backend support: PDF output (pdfTeX)
\l__color_backend_stack_int=\count429
))
Package biblatex Info: ... and expl3
(biblatex)             2026-01-19 L3 programming layer (loader) 
(biblatex)             is new enough (at least 2020/04/06),
(biblatex)             setting 'casechanger=expl3'.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-case-expl3.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/l3packages/xparse/xparse.sty
Package: xparse 2025-10-09 L3 Experimental document command parser
)
Package: blx-case-expl3 2025/07/10 v3.21 expl3 case changing code for biblatex
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pdfpages/pdfpages.sty
Package: pdfpages 2025/07/23 v0.6g Insert pages of external PDF documents (AM)

(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/calc.sty
Package: calc 2025/03/01 v4.3b Infix arithmetic (KKT,FJ)
\calc@Acount=\count430
\calc@Bcount=\count431
\calc@Adimen=\dimen150
\calc@Bdimen=\dimen151
\calc@Askip=\skip73
\calc@Bskip=\skip74
LaTeX Info: Redefining \setlength on input line 86.
LaTeX Info: Redefining \addtolength on input line 87.
\calc@Ccount=\count432
\calc@Cskip=\skip75
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/eso-pic/eso-pic.sty
Package: eso-pic 2025/12/10 v3.0d eso-pic (RN)
\ESO@tempdima=\dimen152
\ESO@tempdimb=\dimen153

(/usr/local/texlive/2026/texmf-dist/tex/latex/xcolor/xcolor.sty
Package: xcolor 2024/09/29 v3.02 LaTeX color extensions (UK)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-cfg/color.cfg
File: color.cfg 2016/01/02 v1.6 sample color configuration
)
Package xcolor Info: Driver file: pdftex.def on input line 274.

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-def/pdftex.def
File: pdftex.def 2025/09/29 v1.2d Graphics/color driver for pdftex
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/mathcolor.ltx)
Package xcolor Info: Model `cmy' substituted by `cmy0' on input line 1349.
Package xcolor Info: Model `hsb' substituted by `rgb' on input line 1353.
Package xcolor Info: Model `RGB' extended on input line 1365.
Package xcolor Info: Model `HTML' substituted by `rgb' on input line 1367.
Package xcolor Info: Model `Hsb' substituted by `hsb' on input line 1368.
Package xcolor Info: Model `tHsb' substituted by `hsb' on input line 1369.
Package xcolor Info: Model `HSB' substituted by `hsb' on input line 1370.
Package xcolor Info: Model `Gray' substituted by `gray' on input line 1371.
Package xcolor Info: Model `wave' substituted by `hsb' on input line 1372.
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/graphicx.sty
Package: graphicx 2024/12/31 v1.2e Enhanced LaTeX Graphics (DPC,SPQR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/graphics.sty
Package: graphics 2024/08/06 v1.4g Standard LaTeX Graphics (DPC,SPQR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/trig.sty
Package: trig 2023/12/02 v1.11 sin cos tan (DPC)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-cfg/graphics.cfg
File: graphics.cfg 2016/06/04 v1.11 sample graphics configuration
)
Package graphics Info: Driver file: pdftex.def on input line 106.
)
\Gin@req@height=\dimen154
\Gin@req@width=\dimen155
)
\AM@pagewidth=\dimen156
\AM@pageheight=\dimen157
\AM@fboxrule=\dimen158

(/usr/local/texlive/2026/texmf-dist/tex/latex/pdfpages/pppdftex.def
File: pppdftex.def 2025/07/23 v0.6g Pdfpages driver for pdfTeX (AM)
)
\pdfpages@includegraphics@status=\count433
\AM@pagebox=\box53
\AM@global@opts=\toks22
\AM@pagecnt=\count434
\AM@toc@title=\toks23
\AM@lof@heading=\toks24
\c@AM@survey=\count435
\AM@templatesizebox=\box54
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsmath.sty
Package: amsmath 2025/07/09 v2.17z AMS math features
\@mathmargin=\skip76

For additional information on amsmath, use the `?' option.
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amstext.sty
Package: amstext 2024/11/17 v2.01 AMS text

(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsgen.sty
File: amsgen.sty 1999/11/30 v2.0 generic functions
\@emptytoks=\toks25
\ex@=\dimen159
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsbsy.sty
Package: amsbsy 1999/11/29 v1.2d Bold Symbols
\pmbraise@=\dimen160
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsopn.sty
Package: amsopn 2022/04/08 v2.04 operator names
)
\inf@bad=\count436
LaTeX Info: Redefining \frac on input line 233.
\uproot@=\count437
\leftroot@=\count438
LaTeX Info: Redefining \overline on input line 398.
LaTeX Info: Redefining \colon on input line 409.
\classnum@=\count439
\DOTSCASE@=\count440
LaTeX Info: Redefining \ldots on input line 495.
LaTeX Info: Redefining \dots on input line 498.
LaTeX Info: Redefining \cdots on input line 619.
\Mathstrutbox@=\box55
\strutbox@=\box56
LaTeX Info: Redefining \big on input line 721.
LaTeX Info: Redefining \Big on input line 722.
LaTeX Info: Redefining \bigg on input line 723.
LaTeX Info: Redefining \Bigg on input line 724.
\big@size=\dimen161
LaTeX Font Info:    Redeclaring font encoding OML on input line 742.
LaTeX Font Info:    Redeclaring font encoding OMS on input line 743.
\macc@depth=\count441
LaTeX Info: Redefining \bmod on input line 904.
LaTeX Info: Redefining \pmod on input line 909.
LaTeX Info: Redefining \smash on input line 939.
LaTeX Info: Redefining \relbar on input line 969.
LaTeX Info: Redefining \Relbar on input line 970.
\c@MaxMatrixCols=\count442
\dotsspace@=\muskip22
\c@parentequation=\count443
\dspbrk@lvl=\count444
\tag@help=\toks26
\row@=\count445
\column@=\count446
\maxfields@=\count447
\andhelp@=\toks27
\eqnshift@=\dimen162
\alignsep@=\dimen163
\tagshift@=\dimen164
\tagwidth@=\dimen165
\totwidth@=\dimen166
\lineht@=\dimen167
\@envbody=\toks28
\multlinegap=\skip77
\multlinetaggap=\skip78
\mathdisplay@stack=\toks29
LaTeX Info: Redefining \[ on input line 2950.
LaTeX Info: Redefining \] on input line 2951.
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/cancel/cancel.sty
Package: cancel 2013/04/12 v2.2 Cancel math terms
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/jknapltx/mathrsfs.sty
Package: mathrsfs 1996/01/01 Math RSFS package v1.0 (jk)
\symrsfs=\mathgroup4
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/float/float.sty
Package: float 2001/11/08 v1.3d Float enhancements (AL)
\c@float@type=\count448
\float@exts=\toks30
\float@box=\box57
\@float@everytoks=\toks31
\@floatcapt=\box58
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/placeins/placeins.sty
Package: placeins 2005/04/18  v 2.2
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/subcaption.sty
Package: subcaption 2023/07/28 v1.6b Sub-captions (AR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/caption.sty
Package: caption 2023/08/05 v3.6o Customizing captions (AR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/caption3.sty
Package: caption3 2023/07/31 v2.4d caption3 kernel (AR)
\caption@tempdima=\dimen168
\captionmargin=\dimen169
\caption@leftmargin=\dimen170
\caption@rightmargin=\dimen171
\caption@width=\dimen172
\caption@indent=\dimen173
\caption@parindent=\dimen174
\caption@hangindent=\dimen175
Package caption Info: Standard document class detected.
)
\c@caption@flags=\count449
\c@continuedfloat=\count450
Package caption Info: float package is loaded.
)
Package caption Info: New subtype `subfigure' on input line 238.
\c@subfigure=\count451
Package caption Info: New subtype `subtable' on input line 238.
\c@subtable=\count452
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/colortbl/colortbl.sty
Package: colortbl 2024/10/29 v1.0k Color table columns (DPC)

(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/array.sty
Package: array 2025/09/25 v2.6n Tabular extension package (FMi)
\col@sep=\dimen176
\ar@mcellbox=\box59
\extrarowheight=\dimen177
\NC@list=\toks32
\extratabsurround=\skip79
\backup@length=\skip80
\ar@cellbox=\box60
)
\everycr=\toks33
\minrowclearance=\skip81
\rownum=\count453
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/makecell/makecell.sty
Package: makecell 2009/08/03 V0.1e Managing of Tab Column Heads and Cells
\rotheadsize=\dimen178
\c@nlinenum=\count454
\TeXr@lab=\toks34
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/longtable.sty
Package: longtable 2025-10-13 v4.24 Multi-page Table package (DPC)
\LTleft=\skip82
\LTright=\skip83
\LTpre=\skip84
\LTpost=\skip85
\LTchunksize=\count455
\LTcapwidth=\dimen179
\LT@head=\box61
\LT@firsthead=\box62
\LT@foot=\box63
\LT@lastfoot=\box64
\LT@gbox=\box65
\LT@cols=\count456
\LT@rows=\count457
\c@LT@tables=\count458
\c@LT@chunks=\count459
\LT@p@ftn=\toks35
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/tabularx.sty
Package: tabularx 2023/12/11 v2.12a `tabularx' package (DPC)
\TX@col@width=\dimen180
\TX@old@table=\dimen181
\TX@old@col=\dimen182
\TX@target=\dimen183
\TX@delta=\dimen184
\TX@cols=\count460
\TX@ftn=\toks36
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/booktabs/booktabs.sty
Package: booktabs 2020/01/12 v1.61803398 Publication quality tables
\heavyrulewidth=\dimen185
\lightrulewidth=\dimen186
\cmidrulewidth=\dimen187
\belowrulesep=\dimen188
\belowbottomsep=\dimen189
\aboverulesep=\dimen190
\abovetopsep=\dimen191
\cmidrulesep=\dimen192
\cmidrulekern=\dimen193
\defaultaddspace=\dimen194
\@cmidla=\count461
\@cmidlb=\count462
\@aboverulesep=\dimen195
\@belowrulesep=\dimen196
\@thisruleclass=\count463
\@lastruleclass=\count464
\@thisrulewidth=\dimen197
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/frontendlayer/tikz.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/basiclayer/pgf.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgfrcs.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfutil-common.te
x
\pgfutil@everybye=\toks37
\pgfutil@tempdima=\dimen198
\pgfutil@tempdimb=\dimen199
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfutil-latex.def
\pgfutil@abb=\box66
) (/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfrcs.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/pgf.revision.tex)
Package: pgfrcs 2025-08-29 v3.1.11a (3.1.11a)
))
Package: pgf 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/basiclayer/pgfcore.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/systemlayer/pgfsys.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys.code.tex
Package: pgfsys 2025-08-29 v3.1.11a (3.1.11a)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeys.code.tex
\pgfkeys@pathtoks=\toks38
\pgfkeys@temptoks=\toks39

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeyslibraryfil
tered.code.tex
\pgfkeys@tmptoks=\toks40
))
\pgf@x=\dimen256
\pgf@y=\dimen257
\pgf@xa=\dimen258
\pgf@ya=\dimen259
\pgf@xb=\dimen260
\pgf@yb=\dimen261
\pgf@xc=\dimen262
\pgf@yc=\dimen263
\pgf@xd=\dimen264
\pgf@yd=\dimen265
\w@pgf@writea=\write4
\r@pgf@reada=\read4
\c@pgf@counta=\count465
\c@pgf@countb=\count466
\c@pgf@countc=\count467
\c@pgf@countd=\count468
\t@pgf@toka=\toks41
\t@pgf@tokb=\toks42
\t@pgf@tokc=\toks43
\pgf@sys@id@count=\count469

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgf.cfg
File: pgf.cfg 2025-08-29 v3.1.11a (3.1.11a)
)
Driver file for pgf: pgfsys-pdftex.def

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys-pdftex.d
ef
File: pgfsys-pdftex.def 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys-common-p
df.def
File: pgfsys-common-pdf.def 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsyssoftpath.
code.tex
File: pgfsyssoftpath.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfsyssoftpath@smallbuffer@items=\count470
\pgfsyssoftpath@bigbuffer@items=\count471
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsysprotocol.
code.tex
File: pgfsysprotocol.code.tex 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcore.code.tex
Package: pgfcore 2025-08-29 v3.1.11a (3.1.11a)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmath.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathutil.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathparser.code.tex
\pgfmath@dimen=\dimen266
\pgfmath@count=\count472
\pgfmath@box=\box67
\pgfmath@toks=\toks44
\pgfmath@stack@operand=\toks45
\pgfmath@stack@operation=\toks46
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.code.
tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.basic
.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.trigo
nometric.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.rando
m.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.compa
rison.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.base.
code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.round
.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.misc.
code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.integ
erarithmetics.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathcalc.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfloat.code.tex
\c@pgfmathroundto@lastzeros=\count473
)) (/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfint.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepoints.co
de.tex
File: pgfcorepoints.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@picminx=\dimen267
\pgf@picmaxx=\dimen268
\pgf@picminy=\dimen269
\pgf@picmaxy=\dimen270
\pgf@pathminx=\dimen271
\pgf@pathmaxx=\dimen272
\pgf@pathminy=\dimen273
\pgf@pathmaxy=\dimen274
\pgf@xx=\dimen275
\pgf@xy=\dimen276
\pgf@yx=\dimen277
\pgf@yy=\dimen278
\pgf@zx=\dimen279
\pgf@zy=\dimen280
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathconst
ruct.code.tex
File: pgfcorepathconstruct.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@path@lastx=\dimen281
\pgf@path@lasty=\dimen282
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathusage
.code.tex
File: pgfcorepathusage.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@shorten@end@additional=\dimen283
\pgf@shorten@start@additional=\dimen284
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorescopes.co
de.tex
File: pgfcorescopes.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfpic=\box68
\pgf@hbox=\box69
\pgf@layerbox@main=\box70
\pgf@picture@serial@count=\count474
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoregraphicst
ate.code.tex
File: pgfcoregraphicstate.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgflinewidth=\dimen285
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoretransform
ations.code.tex
File: pgfcoretransformations.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@pt@x=\dimen286
\pgf@pt@y=\dimen287
\pgf@pt@temp=\dimen288
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorequick.cod
e.tex
File: pgfcorequick.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreobjects.c
ode.tex
File: pgfcoreobjects.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathproce
ssing.code.tex
File: pgfcorepathprocessing.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorearrows.co
de.tex
File: pgfcorearrows.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfarrowsep=\dimen289
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreshade.cod
e.tex
File: pgfcoreshade.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@max=\dimen290
\pgf@sys@shading@range@num=\count475
\pgf@shadingcount=\count476
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreimage.cod
e.tex
File: pgfcoreimage.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreexternal.
code.tex
File: pgfcoreexternal.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfexternal@startupbox=\box71
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorelayers.co
de.tex
File: pgfcorelayers.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoretranspare
ncy.code.tex
File: pgfcoretransparency.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepatterns.
code.tex
File: pgfcorepatterns.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorerdf.code.
tex
File: pgfcorerdf.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduleshapes.cod
e.tex
File: pgfmoduleshapes.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfnodeparttextbox=\box72
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduleplot.code.
tex
File: pgfmoduleplot.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/compatibility/pgfcomp-version
-0-65.sty
Package: pgfcomp-version-0-65 2025-08-29 v3.1.11a (3.1.11a)
\pgf@nodesepstart=\dimen291
\pgf@nodesepend=\dimen292
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/compatibility/pgfcomp-version
-1-18.sty
Package: pgfcomp-version-1-18 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgffor.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgfkeys.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeys.code.tex)
) (/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/math/pgfmath.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmath.code.tex))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgffor.code.tex
Package: pgffor 2025-08-29 v3.1.11a (3.1.11a)
\pgffor@iter=\dimen293
\pgffor@skip=\dimen294
\pgffor@stack=\toks47
\pgffor@toks=\toks48
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/tikz.cod
e.tex
Package: tikz 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryplothan
dlers.code.tex
File: pgflibraryplothandlers.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@plot@mark@count=\count477
\pgfplotmarksize=\dimen295
)
\tikz@lastx=\dimen296
\tikz@lasty=\dimen297
\tikz@lastxsaved=\dimen298
\tikz@lastysaved=\dimen299
\tikz@lastmovetox=\dimen300
\tikz@lastmovetoy=\dimen301
\tikzleveldistance=\dimen302
\tikzsiblingdistance=\dimen303
\tikz@figbox=\box73
\tikz@figbox@bg=\box74
\tikz@tempbox=\box75
\tikz@tempbox@bg=\box76
\tikztreelevel=\count478
\tikznumberofchildren=\count479
\tikznumberofcurrentchild=\count480
\tikz@fig@count=\count481

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmodulematrix.cod
e.tex
File: pgfmodulematrix.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfmatrixcurrentrow=\count482
\pgfmatrixcurrentcolumn=\count483
\pgf@matrix@numberofcolumns=\count484
)
\tikz@expandcount=\count485

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarytopaths.code.tex
File: tikzlibrarytopaths.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshapes.geometric.code.tex
File: tikzlibraryshapes.geometric.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/shapes/pgflibrary
shapes.geometric.code.tex
File: pgflibraryshapes.geometric.code.tex 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshapes.multipart.code.tex
File: tikzlibraryshapes.multipart.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/shapes/pgflibrary
shapes.multipart.code.tex
File: pgflibraryshapes.multipart.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfnodepartlowerbox=\box77
\pgfnodeparttwobox=\box78
\pgfnodepartthreebox=\box79
\pgfnodepartfourbox=\box80
\pgfnodeparttwentybox=\box81
\pgfnodepartnineteenbox=\box82
\pgfnodeparteighteenbox=\box83
\pgfnodepartseventeenbox=\box84
\pgfnodepartsixteenbox=\box85
\pgfnodepartfifteenbox=\box86
\pgfnodepartfourteenbox=\box87
\pgfnodepartthirteenbox=\box88
\pgfnodeparttwelvebox=\box89
\pgfnodepartelevenbox=\box90
\pgfnodeparttenbox=\box91
\pgfnodepartninebox=\box92
\pgfnodeparteightbox=\box93
\pgfnodepartsevenbox=\box94
\pgfnodepartsixbox=\box95
\pgfnodepartfivebox=\box96
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarypositioning.code.tex
File: tikzlibrarypositioning.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryarrows.
meta.code.tex
File: pgflibraryarrows.meta.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfarrowinset=\dimen304
\pgfarrowlength=\dimen305
\pgfarrowwidth=\dimen306
\pgfarrowlinewidth=\dimen307
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarycalc.code.tex
File: tikzlibrarycalc.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshadows.code.tex
File: tikzlibraryshadows.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryfadings.code.tex
File: tikzlibraryfadings.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryfadings
.code.tex
File: pgflibraryfadings.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarydecorations.pathreplacing.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarydecorations.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduledecoration
s.code.tex
\pgfdecoratedcompleteddistance=\dimen308
\pgfdecoratedremainingdistance=\dimen309
\pgfdecoratedinputsegmentcompleteddistance=\dimen310
\pgfdecoratedinputsegmentremainingdistance=\dimen311
\pgf@decorate@distancetomove=\dimen312
\pgf@decorate@repeatstate=\count486
\pgfdecorationsegmentamplitude=\dimen313
\pgfdecorationsegmentlength=\dimen314
)
\tikz@lib@dec@box=\box97
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/decorations/pgfli
brarydecorations.pathreplacing.code.tex))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarybabel.code.tex
File: tikzlibrarybabel.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/enumitem/enumitem.sty
Package: enumitem 2025/02/06 v3.11 Customized lists
\labelindent=\skip86
\enit@outerparindent=\dimen315
\enit@toks=\toks49
\enit@inbox=\box98
\enit@count@id=\count487
\enitdp@description=\count488
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/listings.sty
\lst@mode=\count489
\lst@gtempboxa=\box99
\lst@token=\toks50
\lst@length=\count490
\lst@currlwidth=\dimen316
\lst@column=\count491
\lst@pos=\count492
\lst@lostspace=\dimen317
\lst@width=\dimen318
\lst@newlines=\count493
\lst@lineno=\count494
\lst@maxwidth=\dimen319

(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/lstpatch.sty
File: lstpatch.sty 2025/11/14 1.11b (Carsten Heinz)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/lstmisc.sty
File: lstmisc.sty 2025/11/14 1.11b (Carsten Heinz)
\c@lstnumber=\count495
\lst@skipnumbers=\count496
\lst@framebox=\box100
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/listings.cfg
File: listings.cfg 2025/11/14 1.11b listings configuration
))
Package: listings 2025/11/14 1.11b (Carsten Heinz)

==> First Aid for listings.sty no longer applied!
    Expected:
        2024/09/23 1.10c (Carsten Heinz)
    but found:
        2025/11/14 1.11b (Carsten Heinz)
    so I'm assuming it got fixed.
(/usr/local/texlive/2026/texmf-dist/tex/latex/tocloft/tocloft.sty
Package: tocloft 2017/08/31 v2.3i parameterised ToC, etc., typesetting
Package tocloft Info: The document has section divisions on input line 51.
\cftparskip=\skip87
\cftbeforetoctitleskip=\skip88
\cftaftertoctitleskip=\skip89
\cftbeforepartskip=\skip90
\cftpartnumwidth=\skip91
\cftpartindent=\skip92
\cftbeforesecskip=\skip93
\cftsecindent=\skip94
\cftsecnumwidth=\skip95
\cftbeforesubsecskip=\skip96
\cftsubsecindent=\skip97
\cftsubsecnumwidth=\skip98
\cftbeforesubsubsecskip=\skip99
\cftsubsubsecindent=\skip100
\cftsubsubsecnumwidth=\skip101
\cftbeforeparaskip=\skip102
\cftparaindent=\skip103
\cftparanumwidth=\skip104
\cftbeforesubparaskip=\skip105
\cftsubparaindent=\skip106
\cftsubparanumwidth=\skip107
\cftbeforeloftitleskip=\skip108
\cftafterloftitleskip=\skip109
\cftbeforefigskip=\skip110
\cftfigindent=\skip111
\cftfignumwidth=\skip112
\c@lofdepth=\count497
\c@lotdepth=\count498
\cftbeforelottitleskip=\skip113
\cftafterlottitleskip=\skip114
\cftbeforetabskip=\skip115
\cfttabindent=\skip116
\cfttabnumwidth=\skip117
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/geometry/geometry.sty
Package: geometry 2026/03/07 v6.0 Page Geometry

(/usr/local/texlive/2026/texmf-dist/tex/generic/iftex/ifvtex.sty
Package: ifvtex 2019/10/25 v1.7 ifvtex legacy package. Use iftex instead.
)
\Gm@cnth=\count499
\Gm@cntv=\count500
\c@Gm@tempcnt=\count501
\Gm@bindingoffset=\dimen320
\Gm@wd@mp=\dimen321
\Gm@odd@mp=\dimen322
\Gm@even@mp=\dimen323
\Gm@layoutwidth=\dimen324
\Gm@layoutheight=\dimen325
\Gm@layouthoffset=\dimen326
\Gm@layoutvoffset=\dimen327
\Gm@dimlist=\toks51
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/setspace/setspace.sty
Package: setspace 2022/12/04 v6.7b set line spacing
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/parskip/parskip.sty
Package: parskip 2021-03-14 v2.0h non-zero parskip adjustments
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/lipsum/lipsum.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/l3packages/l3keys2e/l3keys2e.sty
Package: l3keys2e 2025-10-09 LaTeX2e option processing using LaTeX3 keys
)
Package: lipsum 2021-09-20 v2.7 150 paragraphs of Lorem Ipsum dummy text
\g__lipsum_par_int=\count502
\l__lipsum_a_int=\count503
\l__lipsum_b_int=\count504
(/usr/local/texlive/2026/texmf-dist/tex/latex/lipsum/lipsum.ltd.tex))
(/usr/local/texlive/2026/texmf-dist/tex/latex/fancyhdr/fancyhdr.sty
Package: fancyhdr 2025/02/07 v5.2 Extensive control of page headers and footers

\f@nch@headwidth=\skip118
\f@nch@offset@elh=\skip119
\f@nch@offset@erh=\skip120
\f@nch@offset@olh=\skip121
\f@nch@offset@orh=\skip122
\f@nch@offset@elf=\skip123
\f@nch@offset@erf=\skip124
\f@nch@offset@olf=\skip125
\f@nch@offset@orf=\skip126
\f@nch@height=\skip127
\f@nch@footalignment=\skip128
\f@nch@widthL=\skip129
\f@nch@widthC=\skip130
\f@nch@widthR=\skip131
\@temptokenb=\toks52
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/hyperref.sty
Package: hyperref 2026-01-29 v7.01p Hypertext links for LaTeX

(/usr/local/texlive/2026/texmf-dist/tex/generic/kvdefinekeys/kvdefinekeys.sty
Package: kvdefinekeys 2019-12-19 v1.6 Define keys (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pdfescape/pdfescape.sty
Package: pdfescape 2019/12/09 v1.15 Implements pdfTeX's escape features (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hycolor/hycolor.sty
Package: hycolor 2020-01-27 v1.10 Color options for hyperref/bookmark (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/nameref.sty
Package: nameref 2026-01-29 v2.58 Cross-referencing by name of section

(/usr/local/texlive/2026/texmf-dist/tex/latex/refcount/refcount.sty
Package: refcount 2019/12/15 v3.6 Data extraction from label references (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/gettitlestring/gettitlestring.s
ty
Package: gettitlestring 2019/12/15 v1.6 Cleanup title references (HO)
)
\c@section@level=\count505
) (/usr/local/texlive/2026/texmf-dist/tex/generic/stringenc/stringenc.sty
Package: stringenc 2019/11/29 v1.12 Convert strings between diff. encodings (HO
)
)
\@linkdim=\dimen328
\Hy@linkcounter=\count506
\Hy@pagecounter=\count507

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/pd1enc.def
File: pd1enc.def 2026-01-29 v7.01p Hyperref: PDFDocEncoding definition (HO)
Now handling font encoding PD1 ...
... no UTF-8 mapping file for font encoding PD1
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/intcalc/intcalc.sty
Package: intcalc 2019/12/15 v1.3 Expandable calculations with integers (HO)
)
\Hy@SavedSpaceFactor=\count508

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/puenc.def
File: puenc.def 2026-01-29 v7.01p Hyperref: PDF Unicode definition (HO)
Now handling font encoding PU ...
... no UTF-8 mapping file for font encoding PU
)
Package hyperref Info: Hyper figures OFF on input line 4201.
Package hyperref Info: Link nesting OFF on input line 4206.
Package hyperref Info: Hyper index ON on input line 4209.
Package hyperref Info: Plain pages OFF on input line 4216.
Package hyperref Info: Backreferencing OFF on input line 4221.
Package hyperref Info: Implicit mode ON; LaTeX internals redefined.
Package hyperref Info: Bookmarks ON on input line 4468.
\c@Hy@tempcnt=\count509
LaTeX Info: Redefining \url on input line 4807.
\XeTeXLinkMargin=\dimen329

(/usr/local/texlive/2026/texmf-dist/tex/generic/bitset/bitset.sty
Package: bitset 2019/12/09 v1.3 Handle bit-vector datatype (HO)

(/usr/local/texlive/2026/texmf-dist/tex/generic/bigintcalc/bigintcalc.sty
Package: bigintcalc 2019/12/15 v1.5 Expandable calculations on big integers (HO
)
))
\Fld@menulength=\count510
\Field@Width=\dimen330
\Fld@charsize=\dimen331
Package hyperref Info: Hyper figures OFF on input line 6084.
Package hyperref Info: Link nesting OFF on input line 6089.
Package hyperref Info: Hyper index ON on input line 6092.
Package hyperref Info: backreferencing OFF on input line 6099.
Package hyperref Info: Link coloring OFF on input line 6104.
Package hyperref Info: Link coloring with OCG OFF on input line 6109.
Package hyperref Info: PDF/A mode OFF on input line 6114.
\Hy@abspage=\count511
\c@Item=\count512
\c@Hfootnote=\count513
)
Package hyperref Info: Driver (autodetected): hpdftex.

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/hpdftex.def
File: hpdftex.def 2026-01-29 v7.01p Hyperref driver for pdfTeX
\Fld@listcount=\count514
\c@bookmark@seq@number=\count515

(/usr/local/texlive/2026/texmf-dist/tex/latex/rerunfilecheck/rerunfilecheck.sty
Package: rerunfilecheck 2025-06-21 v1.11 Rerun checks for auxiliary files (HO)

(/usr/local/texlive/2026/texmf-dist/tex/generic/uniquecounter/uniquecounter.sty
Package: uniquecounter 2019/12/15 v1.4 Provide unlimited unique counter (HO)
)
Package uniquecounter Info: New unique counter `rerunfilecheck' on input line 2
84.
)
\Hy@SectionHShift=\skip132
)
Package hyperref Info: Option `colorlinks' set `true' on input line 208.
Package csquotes Info: Checking for multilingual support...
Package csquotes Info: ... found 'babel' package.
Package csquotes Info: Adjusting default style.
Package csquotes Info: Redefining alias 'default' -> 'spanish'.
 (./main.aux
LaTeX Info: Redefining \. on input line 9.
LaTeX Info: Redefining \% on input line 9.
Package babel Info: 'spanish' activates 'spanish' shorthands.
(babel)             Reported on input line 9.
)
\openout1 = `main.aux'.

LaTeX Font Info:    Checking defaults for OML/cmm/m/it on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OMS/cmsy/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OT1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for T1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for TS1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OMX/cmex/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for U/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for PD1/pdf/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for PU/pdf/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Info: Redefining \. on input line 211.
LaTeX Info: Redefining \% on input line 211.
Package biblatex Info: Trying to load language 'spanish' -> 'spanish-apa'...
Package biblatex Info: ... file 'spanish-apa.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/spanish-apa.lbx
File: spanish-apa.lbx 2025/08/27 v9.20 APA biblatex localisation
Package biblatex Info: Trying to load language 'spanish'...
Package biblatex Info: ... file 'spanish.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/lbx/spanish.lbx
File: spanish.lbx 2025/07/10 v3.21 biblatex localization (PK/MW)
)
Package biblatex Info: Trying to load language 'spanish'...
Package biblatex Info: ... file 'spanish.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/lbx/spanish.lbx
File: spanish.lbx 2025/07/10 v3.21 biblatex localization (PK/MW)
))
Package biblatex Info: Input encoding 'utf8' detected.
Package biblatex Info: Automatic encoding selection.
(biblatex)             Assuming data encoding 'utf8'.
\openout3 = `main.bcf'.

Package biblatex Info: Trying to load bibliographic data...
Package biblatex Info: ... file 'main.bbl' found.

(./main.bbl)
Package biblatex Info: Reference section=0 on input line 211.
Package biblatex Info: Reference segment=0 on input line 211.

(/usr/local/texlive/2026/texmf-dist/tex/context/base/mkii/supp-pdf.mkii
[Loading MPS to PDF converter (version 2006.09.02).]
\scratchcounter=\count516
\scratchdimen=\dimen332
\scratchbox=\box101
\nofMPsegments=\count517
\nofMParguments=\count518
\everyMPshowfont=\toks53
\MPscratchCnt=\count519
\MPscratchDim=\dimen333
\MPnumerator=\count520
\makeMPintoPDFobject=\count521
\everyMPtoPDFconversion=\toks54
) (/usr/local/texlive/2026/texmf-dist/tex/latex/epstopdf-pkg/epstopdf-base.sty
Package: epstopdf-base 2020-01-24 v2.11 Base part for package epstopdf
Package epstopdf-base Info: Redefining graphics rule for `.eps' on input line 4
85.

(/usr/local/texlive/2026/texmf-dist/tex/latex/latexconfig/epstopdf-sys.cfg
File: epstopdf-sys.cfg 2010/07/13 v1.3 Configuration of (r)epstopdf for TeX Liv
e
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pdflscape/pdflscape.sty
Package: pdflscape 2025-06-23 v0.14 Display of landscape pages in PDF

(/usr/local/texlive/2026/texmf-dist/tex/latex/pdflscape/pdflscape-nometadata.st
y
Package: pdflscape-nometadata 2025-06-23 v0.14 Display of landscape pages in PD
F (HO)
 (/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/lscape.sty
Package: lscape 2020/05/28 v3.02 Landscape Pages (DPC)
)
Package pdflscape Info: Auto-detected driver: pdftex on input line 81.
))
Package caption Info: Begin \AtBeginDocument code.
Package caption Info: hyperref package is loaded.
Package caption Info: listings package is loaded.
Package caption Info: longtable package is loaded.

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/ltcaption.sty
Package: ltcaption 2021/01/08 v1.4c longtable captions (AR)
)
Package caption Info: End \AtBeginDocument code.
\c@lstlisting=\count522

*geometry* driver: auto-detecting
*geometry* detected driver: pdftex
*geometry* verbose mode - [ preamble ] result:
* driver: pdftex
* paper: custom
* layout: <same size as paper>
* layoutoffset:(h,v)=(0.0pt,0.0pt)
* modes: 
* h-part:(L,W,R)=(71.13188pt, 472.03113pt, 71.13188pt)
* v-part:(T,H,B)=(99.58464pt, 610.02716pt, 85.35826pt)
* \paperwidth=614.29489pt
* \paperheight=794.97006pt
* \textwidth=472.03113pt
* \textheight=610.02716pt
* \oddsidemargin=-1.1381pt
* \evensidemargin=-1.1381pt
* \topmargin=-74.68535pt
* \headheight=77.0pt
* \headsep=25.0pt
* \topskip=11.0pt
* \footskip=30.0pt
* \marginparwidth=59.0pt
* \marginparsep=10.0pt
* \columnsep=10.0pt
* \skip\footins=10.0pt plus 4.0pt minus 2.0pt
* \hoffset=0.0pt
* \voffset=0.0pt
* \mag=1000
* \@twocolumnfalse
* \@twosidefalse
* \@mparswitchfalse
* \@reversemarginfalse
* (1in=72.27pt=25.4mm, 1cm=28.453pt)

Package hyperref Info: Link coloring ON on input line 211.
(./main.out) (./main.out)
\@outlinefile=\write5
\openout5 = `main.out'.

 (./Portada.tex
LaTeX Font Info:    Trying to load font information for U+rsfs on input line 6.


(/usr/local/texlive/2026/texmf-dist/tex/latex/jknapltx/ursfs.fd
File: ursfs.fd 1998/03/24 rsfs font definition file (jk)
)
<portada_img/der.png, id=195, 332.24126pt x 393.47pt>
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 8.
(pdftex.def)             Requested size: 56.9055pt x 67.38733pt.
<portada_img/izq.png, id=197, 254.9525pt x 301.125pt>
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 14.
(pdftex.def)             Requested size: 56.9055pt x 67.20801pt.
) [1

{/usr/local/texlive/2026/texmf-var/fonts/map/pdftex/updmap/pdftex.map} <./porta
da_img/der.png> <./portada_img/izq.png>] (./main.toc
LaTeX Info: Redefining \sptext on input line 1.
LaTeX Info: Redefining \. on input line 1.
LaTeX Info: Redefining \% on input line 1.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 31.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 31.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

pdfTeX warning (ext4): destination with the same identifier (name{page.1}) has 
been already used, duplicate ignored
<to be read again> 
                   \relax 
l.31 ...l conjunto de prueba}{30}{subsection.11.4}
                                                  % [1])
\tf@toc=\write6
\openout6 = `main.toc'.

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 216.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 216.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [2]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 234.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 234.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

pdfTeX warning (ext4): destination with the same identifier (name{page.1}) has 
been already used, duplicate ignored
<to be read again> 
                   \relax 
l.234 \item V
             erificar el formulario contra el Pipeline guardado y ofrecer un...
[1]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 251.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 251.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

pdfTeX warning (ext4): destination with the same identifier (name{page.2}) has 
been already used, duplicate ignored
<to be read again> 
                   \relax 
l.251 \subsection
                 {Poblaciones y sesgos} [2]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 265.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 265.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [3]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 282.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 282.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [4]
<figuras/eda_plays_log.png, id=293, 505.89pt x 289.08pt>
File: figuras/eda_plays_log.png Graphic file (type png)
<use figuras/eda_plays_log.png>
Package pdftex.def Info: figuras/eda_plays_log.png  used on input line 285.
(pdftex.def)             Requested size: 448.38805pt x 256.22174pt.
<figuras/graficas_logaritmicas_corregidas.jpg, id=294, 1284.8pt x 722.7pt>
File: figuras/graficas_logaritmicas_corregidas.jpg Graphic file (type jpg)
<use figuras/graficas_logaritmicas_corregidas.jpg>
Package pdftex.def Info: figuras/graficas_logaritmicas_corregidas.jpg  used on 
input line 288.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 289.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 289.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [5 <./figuras/eda_plays_log.png>]
Underfull \hbox (badness 10000) in paragraph at lines 300--300
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 304--304
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 307--307
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 309--309
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 310--310
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 311.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 311.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[6 <./figuras/graficas_logaritmicas_corregidas.jpg>]
Underfull \hbox (badness 5022) in paragraph at lines 341--341
[]|\OT1/cmr/m/n/10.95 Card & Board
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 346.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 346.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[7]
Underfull \hbox (badness 10000) in paragraph at lines 363--363
[]|\OT1/cmr/m/n/10.95 Ubisoft En-ter-tain-
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 390.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 390.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[8]
<figuras/clustering_03_kmeans.png, id=319, 722.7pt x 289.08pt>
File: figuras/clustering_03_kmeans.png Graphic file (type png)
<use figuras/clustering_03_kmeans.png>
Package pdftex.def Info: figuras/clustering_03_kmeans.png  used on input line 3
99.
(pdftex.def)             Requested size: 472.03212pt x 188.81284pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 400.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 400.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [9]
<figuras/clustering_03_proyeccion.png, id=325, 722.7pt x 289.08pt>
File: figuras/clustering_03_proyeccion.png Graphic file (type png)
<use figuras/clustering_03_proyeccion.png>
Package pdftex.def Info: figuras/clustering_03_proyeccion.png  used on input li
ne 406.
(pdftex.def)             Requested size: 472.03212pt x 188.81284pt.

Underfull \hbox (badness 1237) in paragraph at lines 423--424
[]|\OT1/cmr/m/n/10.95 Condemned: Cri-mi-nal Ori-
 []

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 424.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 424.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[10 <./figuras/clustering_03_kmeans.png> <./figuras/clustering_03_proyeccion.pn
g>]
<figuras/clustering_03_dbscan_kdistancia.png, id=335, 578.16pt x 289.08pt>
File: figuras/clustering_03_dbscan_kdistancia.png Graphic file (type png)
<use figuras/clustering_03_dbscan_kdistancia.png>
Package pdftex.def Info: figuras/clustering_03_dbscan_kdistancia.png  used on i
nput line 431.
(pdftex.def)             Requested size: 472.02992pt x 236.01495pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 432.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 432.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [11]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 443.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 443.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [12 <./figuras/clustering_03_dbscan_kdistancia.png>]
Underfull \hbox (badness 3930) in paragraph at lines 453--453
[]|\OT1/cmr/m/n/10.95 Exactitud prue-
 []


Underfull \hbox (badness 3930) in paragraph at lines 454--454
[]|\OT1/cmr/m/n/10.95 Exactitud prue-
 []

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 466.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 466.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[13]
<figuras/graficas_permutacion_corregida.jpg, id=356, 1284.8pt x 903.375pt>
File: figuras/graficas_permutacion_corregida.jpg Graphic file (type jpg)
<use figuras/graficas_permutacion_corregida.jpg>
Package pdftex.def Info: figuras/graficas_permutacion_corregida.jpg  used on in
put line 469.
(pdftex.def)             Requested size: 442.4723pt x 311.11334pt.

ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 485.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 485.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [14 <./figuras/graficas_permutacion_corregida.jpg>]
<figuras/RandomForest.png, id=365, 2055.68pt x 1541.76pt>
File: figuras/RandomForest.png Graphic file (type png)
<use figuras/RandomForest.png>
Package pdftex.def Info: figuras/RandomForest.png  used on input line 501.
(pdftex.def)             Requested size: 472.01228pt x 354.0092pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 502.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 502.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [15]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 502.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 502.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [16 <./figuras/RandomForest.png>]
<figuras/kmeans_resultado.png, id=379, 2055.68pt x 1541.76pt>
File: figuras/kmeans_resultado.png Graphic file (type png)
<use figuras/kmeans_resultado.png>
Package pdftex.def Info: figuras/kmeans_resultado.png  used on input line 512.
(pdftex.def)             Requested size: 447.32637pt x 335.49477pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 513.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 513.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [17]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 513.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 513.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [18 <./figuras/kmeans_resultado.png>]
<figuras/dbscan_resultado.png, id=389, 2055.68pt x 1541.76pt>
File: figuras/dbscan_resultado.png Graphic file (type png)
<use figuras/dbscan_resultado.png>
Package pdftex.def Info: figuras/dbscan_resultado.png  used on input line 517.
(pdftex.def)             Requested size: 422.95412pt x 317.21559pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 525.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 525.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [19 <./figuras/dbscan_resultado.png>]
<figuras/inicio_actual.jpg, id=395, 1284.8pt x 722.7pt>
File: figuras/inicio_actual.jpg Graphic file (type jpg)
<use figuras/inicio_actual.jpg>
Package pdftex.def Info: figuras/inicio_actual.jpg  used on input line 526.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
<figuras/formulario_verificado.jpg, id=396, 1284.8pt x 722.7pt>
File: figuras/formulario_verificado.jpg Graphic file (type jpg)
<use figuras/formulario_verificado.jpg>
Package pdftex.def Info: figuras/formulario_verificado.jpg  used on input line 
529.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 530.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 530.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [20 <./figuras/inicio_actual.jpg>]
<figuras/sin_critica_verificado.jpg, id=402, 1284.8pt x 722.7pt>
File: figuras/sin_critica_verificado.jpg Graphic file (type jpg)
<use figuras/sin_critica_verificado.jpg>
Package pdftex.def Info: figuras/sin_critica_verificado.jpg  used on input line
 534.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 535.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 535.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [21 <./figuras/formulario_verificado.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 545.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 545.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [22 <./figuras/sin_critica_verificado.jpg>]
<figuras/sensibilidad_escenarios.png, id=414, 578.16pt x 361.35pt>
File: figuras/sensibilidad_escenarios.png Graphic file (type png)
<use figuras/sensibilidad_escenarios.png>
Package pdftex.def Info: figuras/sensibilidad_escenarios.png  used on input lin
e 567.
(pdftex.def)             Requested size: 472.03113pt x 295.0187pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 567.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 567.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [23]
<figuras/escenario_S1.jpg, id=420, 1284.8pt x 722.7pt>
File: figuras/escenario_S1.jpg Graphic file (type jpg)
<use figuras/escenario_S1.jpg>
Package pdftex.def Info: figuras/escenario_S1.jpg  used on input line 569.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 569.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 569.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [24 <./figuras/sensibilidad_escenarios.png>]
<figuras/escenario_S2.jpg, id=427, 1284.8pt x 722.7pt>
File: figuras/escenario_S2.jpg Graphic file (type jpg)
<use figuras/escenario_S2.jpg>
Package pdftex.def Info: figuras/escenario_S2.jpg  used on input line 570.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 570.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 570.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [25 <./figuras/escenario_S1.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 570.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 570.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [26 <./figuras/escenario_S2.jpg>]
<figuras/escenario_S3.jpg, id=438, 1284.8pt x 722.7pt>
File: figuras/escenario_S3.jpg Graphic file (type jpg)
<use figuras/escenario_S3.jpg>
Package pdftex.def Info: figuras/escenario_S3.jpg  used on input line 571.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
<figuras/escenario_S4.jpg, id=439, 1284.8pt x 722.7pt>
File: figuras/escenario_S4.jpg Graphic file (type jpg)
<use figuras/escenario_S4.jpg>
Package pdftex.def Info: figuras/escenario_S4.jpg  used on input line 572.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 572.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 572.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [27

 <./figuras/escenario_S3.jpg>]
<figuras/escenario_S5.jpg, id=445, 1284.8pt x 722.7pt>
File: figuras/escenario_S5.jpg Graphic file (type jpg)
<use figuras/escenario_S5.jpg>
Package pdftex.def Info: figuras/escenario_S5.jpg  used on input line 573.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 573.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 573.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [28 <./figuras/escenario_S4.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 573.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 573.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [29 <./figuras/escenario_S5.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 595.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 595.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [30

]
ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 623.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 623.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [31]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 631.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 631.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [32]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 647.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 647.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [33]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 669.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 669.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [34]
<figuras/exploracion_actual.jpg, id=497, 1284.8pt x 722.7pt>
File: figuras/exploracion_actual.jpg Graphic file (type jpg)
<use figuras/exploracion_actual.jpg>
Package pdftex.def Info: figuras/exploracion_actual.jpg  used on input line 680
.
(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 680.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 680.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [35]
<figuras/prediccion_actual.jpg, id=507, 1284.8pt x 722.7pt>
File: figuras/prediccion_actual.jpg Graphic file (type jpg)
<use figuras/prediccion_actual.jpg>
Package pdftex.def Info: figuras/prediccion_actual.jpg  used on input line 681.

(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 681.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 681.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

[36 <./figuras/exploracion_actual.jpg> <./figuras/prediccion_actual.jpg>]
<figuras/modelo_actual.jpg, id=514, 1284.8pt x 722.7pt>
File: figuras/modelo_actual.jpg Graphic file (type jpg)
<use figuras/modelo_actual.jpg>
Package pdftex.def Info: figuras/modelo_actual.jpg  used on input line 682.
(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 684.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 684.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

[37

 <./figuras/modelo_actual.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 685.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 685.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [38

] (./main.aux
LaTeX Info: Redefining \sptext on input line 9.
LaTeX Info: Redefining \. on input line 9.
LaTeX Info: Redefining \% on input line 9.
)
 ***********
LaTeX2e <2025-11-01>
L3 programming layer <2026-01-19>
 ***********
Package rerunfilecheck Info: File `main.out' has not changed.
(rerunfilecheck)             Checksum: E145AEEE38ED714DB9813847441FB869;8783.
Package logreq Info: Writing requests to 'main.run.xml'.
\openout1 = `main.run.xml'.

 ) 
Here is how much of TeX's memory you used:
 38095 strings out of 467525
 740768 string characters out of 5418982
 1781089 words of memory out of 5000000
 66307 multiletter control sequences out of 15000+600000
 634266 words of font info for 64 fonts, out of 8000000 for 9000
 1141 hyphenation exceptions out of 8191
 84i,16n,94p,1197b,2807s stack positions out of 10000i,1000n,20000p,200000b,200000s
</usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmbx10.pfb
></usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmbx12.pfb>
</usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmex10.pfb><
/usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmmi10.pfb></
usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmmi8.pfb></us
r/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr10.pfb></usr/
local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr12.pfb></usr/lo
cal/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr17.pfb></usr/loca
l/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr8.pfb></usr/local/t
exlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmsy10.pfb></usr/local/te
xlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmsy8.pfb></usr/local/texl
ive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmti10.pfb></usr/local/texli
ve/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmtt10.pfb>
Output written on main.pdf (41 pages, 4491881 bytes).
PDF statistics:
 618 PDF objects out of 1000 (max. 8388607)
 498 compressed objects within 5 object streams
 137 named destinations out of 1000 (max. 500000)
 552 words of extra memory for PDF output out of 10000 (max. 10000000)


````

## Origen: DocumentoFinal/main.log

SHA-256: `8c0116445f4bb80a2580271acd686f50b71c8dcb8e1989f1d280807f97d6ed0e`

````text
This is pdfTeX, Version 3.141592653-2.6-1.40.29 (TeX Live 2026) (preloaded format=pdflatex 2026.3.22)  9 NOV 2026 19:55
entering extended mode
 restricted \write18 enabled.
 %&-line parsing enabled.
**main.tex
(./main.tex
LaTeX2e <2025-11-01>
L3 programming layer <2026-01-19>
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/article.cls
Document Class: article 2025/01/22 v1.4n Standard LaTeX document class
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/size11.clo
File: size11.clo 2025/01/22 v1.4n Standard LaTeX file (size option)
)
\c@part=\count275
\c@section=\count276
\c@subsection=\count277
\c@subsubsection=\count278
\c@paragraph=\count279
\c@subparagraph=\count280
\c@figure=\count281
\c@table=\count282
\abovecaptionskip=\skip49
\belowcaptionskip=\skip50
\bibindent=\dimen148
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/babel.sty
Package: babel 2026/03/08 v26.4 The multilingual framework for LuaLaTeX, pdfLaT
eX and XeLaTeX
\babel@savecnt=\count283
LaTeX Encoding Info:    Redeclaring text command \ij (encoding OT1) on input li
ne 2078.
LaTeX Encoding Info:    Redeclaring text command \IJ (encoding OT1) on input li
ne 2080.
LaTeX Encoding Info:    Redeclaring text command \ij (encoding T1) on input lin
e 2082.
LaTeX Encoding Info:    Redeclaring text command \IJ (encoding T1) on input lin
e 2083.
LaTeX Encoding Info:    Ignoring declaration for text command \ij (encoding ?) 
on input line 2084.
LaTeX Encoding Info:    Ignoring declaration for text command \IJ (encoding ?) 
on input line 2086.
LaTeX Encoding Info:    Ignoring declaration for text command \SS (encoding ?) 
on input line 2111.
\U@D=\dimen149
\l@unhyphenated=\language91

(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/txtbabel.def)
\bbl@readstream=\read2
\bbl@dirlevel=\count284

(/usr/local/texlive/2026/texmf-dist/tex/generic/babel/locale/es/babel-spanish.t
ex)
Package babel Info: Importing font and identification data for spanish
(babel)             from babel-es.ini. Reported on input line 4330.
 (/usr/local/texlive/2026/texmf-dist/tex/generic/babel-spanish/spanish.ldf
Language: spanish.ldf 2021/05/27 v5.0q Spanish support from the babel system
\es@quottoks=\toks17
\es@quotdepth=\count285
Package babel Info: Making " an active character on input line 570.
))
LaTeX Encoding Info:    Redeclaring text command \guillemotleft (encoding OT1) 
on input line 5.
LaTeX Encoding Info:    Redeclaring text command \guillemotright (encoding OT1)
 on input line 5.
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/inputenc.sty
Package: inputenc 2024/02/08 v1.3d Input encoding file
\inpenc@prehook=\toks18
\inpenc@posthook=\toks19
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.sty
Package: csquotes 2024-04-04 v5.2o context-sensitive quotations (JAW)

(/usr/local/texlive/2026/texmf-dist/tex/latex/etoolbox/etoolbox.sty
Package: etoolbox 2025/10/02 v2.5m e-TeX tools for LaTeX (JAW)
\etb@tempcnta=\count286
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/keyval.sty
Package: keyval 2022/05/29 v1.15 key=value parser (DPC)
\KV@toks@=\toks20
)
\csq@reset=\count287
\csq@gtype=\count288
\csq@glevel=\count289
\csq@qlevel=\count290
\csq@maxlvl=\count291
\csq@tshold=\count292
\csq@ltx@everypar=\toks21

(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.def
File: csquotes.def 2024-04-04 v5.2o csquotes generic definitions (JAW)
)
Package csquotes Info: Trying to load configuration file 'csquotes.cfg'...
Package csquotes Info: ... configuration file loaded successfully.

(/usr/local/texlive/2026/texmf-dist/tex/latex/csquotes/csquotes.cfg
File: csquotes.cfg 
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.sty
Package: biblatex 2025/07/10 v3.21 programmable bibliographies (PK/MW)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pdftexcmds/pdftexcmds.sty
Package: pdftexcmds 2020-06-27 v0.33 Utility functions of pdfTeX for LuaTeX (HO
)

(/usr/local/texlive/2026/texmf-dist/tex/generic/infwarerr/infwarerr.sty
Package: infwarerr 2019/12/03 v1.5 Providing info/warning/error messages (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/iftex/iftex.sty
Package: iftex 2024/12/12 v1.0g TeX engine tests
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/ltxcmds/ltxcmds.sty
Package: ltxcmds 2023-12-04 v1.26 LaTeX kernel commands for general use (HO)
)
Package pdftexcmds Info: \pdf@primitive is available.
Package pdftexcmds Info: \pdf@ifprimitive is available.
Package pdftexcmds Info: \pdfdraftmode found.
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/kvoptions/kvoptions.sty
Package: kvoptions 2022-06-15 v3.15 Key value format for package options (HO)

(/usr/local/texlive/2026/texmf-dist/tex/latex/kvsetkeys/kvsetkeys.sty
Package: kvsetkeys 2022-10-05 v1.19 Key value parser (HO)
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/logreq/logreq.sty
Package: logreq 2010/08/04 v1.0 xml request logger
\lrq@indent=\count293

(/usr/local/texlive/2026/texmf-dist/tex/latex/logreq/logreq.def
File: logreq.def 2010/08/04 v1.0 logreq spec v1.0
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/base/ifthen.sty
Package: ifthen 2024/03/16 v1.1e Standard LaTeX ifthen package (DPC)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/url/url.sty
\Urlmuskip=\muskip17
Package: url 2013/09/16  ver 3.4  Verb mode for urls, etc.
)
\c@tabx@nest=\count294
\c@listtotal=\count295
\c@listcount=\count296
\c@liststart=\count297
\c@liststop=\count298
\c@citecount=\count299
\c@citetotal=\count300
\c@multicitecount=\count301
\c@multicitetotal=\count302
\c@instcount=\count303
\c@maxnames=\count304
\c@minnames=\count305
\c@maxitems=\count306
\c@minitems=\count307
\c@citecounter=\count308
\c@maxcitecounter=\count309
\c@savedcitecounter=\count310
\c@uniquelist=\count311
\c@uniquename=\count312
\c@refsection=\count313
\c@refsegment=\count314
\c@maxextratitle=\count315
\c@maxextratitleyear=\count316
\c@maxextraname=\count317
\c@maxextradate=\count318
\c@maxextraalpha=\count319
\c@abbrvpenalty=\count320
\c@highnamepenalty=\count321
\c@lownamepenalty=\count322
\c@maxparens=\count323
\c@parenlevel=\count324
\blx@tempcnta=\count325
\blx@tempcntb=\count326
\blx@tempcntc=\count327
\c@blx@maxsection=\count328
\blx@maxsegment@0=\count329
\blx@notetype=\count330
\blx@parenlevel@text=\count331
\blx@parenlevel@foot=\count332
\blx@sectionciteorder@0=\count333
\blx@sectionciteorderinternal@0=\count334
\blx@entrysetcounter=\count335
\blx@biblioinstance=\count336
\labelnumberwidth=\skip51
\labelalphawidth=\skip52
\biblabelsep=\skip53
\bibitemsep=\skip54
\bibnamesep=\skip55
\bibinitsep=\skip56
\bibparsep=\skip57
\bibhang=\skip58
\blx@bcfin=\read3
\blx@bcfout=\write3
\blx@langwohyphens=\language92
\c@mincomprange=\count337
\c@maxcomprange=\count338
\c@mincompwidth=\count339
Package biblatex Info: Trying to load biblatex default data model...
Package biblatex Info: ... file 'blx-dm.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-dm.def
File: blx-dm.def 2025/07/10 v3.21 biblatex datamodel (PK/MW)
)
Package biblatex Info: Trying to load biblatex style data model...
Package biblatex Info: ... file 'apa.dbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.dbx
File: apa.dbx 2025/08/27 v9.20 APA biblatex style data model
)
Package biblatex Info: Trying to load biblatex custom data model...
Package biblatex Info: ... file 'biblatex-dm.cfg' not found.
\c@afterword=\count340
\c@savedafterword=\count341
\c@annotator=\count342
\c@savedannotator=\count343
\c@author=\count344
\c@savedauthor=\count345
\c@bookauthor=\count346
\c@savedbookauthor=\count347
\c@commentator=\count348
\c@savedcommentator=\count349
\c@editor=\count350
\c@savededitor=\count351
\c@editora=\count352
\c@savededitora=\count353
\c@editorb=\count354
\c@savededitorb=\count355
\c@editorc=\count356
\c@savededitorc=\count357
\c@foreword=\count358
\c@savedforeword=\count359
\c@holder=\count360
\c@savedholder=\count361
\c@introduction=\count362
\c@savedintroduction=\count363
\c@namea=\count364
\c@savednamea=\count365
\c@nameb=\count366
\c@savednameb=\count367
\c@namec=\count368
\c@savednamec=\count369
\c@translator=\count370
\c@savedtranslator=\count371
\c@shortauthor=\count372
\c@savedshortauthor=\count373
\c@shorteditor=\count374
\c@savedshorteditor=\count375
\c@narrator=\count376
\c@savednarrator=\count377
\c@execproducer=\count378
\c@savedexecproducer=\count379
\c@execdirector=\count380
\c@savedexecdirector=\count381
\c@with=\count382
\c@savedwith=\count383
\c@labelname=\count384
\c@savedlabelname=\count385
\c@institution=\count386
\c@savedinstitution=\count387
\c@lista=\count388
\c@savedlista=\count389
\c@listb=\count390
\c@savedlistb=\count391
\c@listc=\count392
\c@savedlistc=\count393
\c@listd=\count394
\c@savedlistd=\count395
\c@liste=\count396
\c@savedliste=\count397
\c@listf=\count398
\c@savedlistf=\count399
\c@location=\count400
\c@savedlocation=\count401
\c@organization=\count402
\c@savedorganization=\count403
\c@origlocation=\count404
\c@savedoriglocation=\count405
\c@origpublisher=\count406
\c@savedorigpublisher=\count407
\c@publisher=\count408
\c@savedpublisher=\count409
\c@language=\count410
\c@savedlanguage=\count411
\c@origlanguage=\count412
\c@savedoriglanguage=\count413
\c@citation=\count414
\c@savedcitation=\count415
\c@pageref=\count416
\c@savedpageref=\count417
\shorthandwidth=\skip59
\shortjournalwidth=\skip60
\shortserieswidth=\skip61
\shorttitlewidth=\skip62
\shortauthorwidth=\skip63
\shorteditorwidth=\skip64
\locallabelnumberwidth=\skip65
\locallabelalphawidth=\skip66
\localshorthandwidth=\skip67
\localshortjournalwidth=\skip68
\localshortserieswidth=\skip69
\localshorttitlewidth=\skip70
\localshortauthorwidth=\skip71
\localshorteditorwidth=\skip72
Package biblatex Info: Trying to load compatibility code...
Package biblatex Info: ... file 'blx-compat.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-compat.def
File: blx-compat.def 2025/07/10 v3.21 biblatex compatibility (PK/MW)
)
Package biblatex Info: Trying to load generic definitions...
Package biblatex Info: ... file 'biblatex.def' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.def
File: biblatex.def 2025/07/10 v3.21 biblatex compatibility (PK/MW)
\c@textcitecount=\count418
\c@textcitetotal=\count419
\c@textcitemaxnames=\count420
\c@biburlbigbreakpenalty=\count421
\c@biburlbreakpenalty=\count422
\c@biburlnumpenalty=\count423
\c@biburlucpenalty=\count424
\c@biburllcpenalty=\count425
\biburlbigskip=\muskip18
\biburlnumskip=\muskip19
\biburlucskip=\muskip20
\biburllcskip=\muskip21
\c@smartand=\count426
)
Package biblatex Info: Trying to load bibliography style 'apa'...
Package biblatex Info: ... file 'apa.bbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.bbx
File: apa.bbx 2025/08/27 v9.20 APA biblatex references style
Package biblatex Info: Trying to load bibliography style 'standard'...
Package biblatex Info: ... file 'standard.bbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/bbx/standard.bbx
File: standard.bbx 2025/07/10 v3.21 biblatex bibliography style (PK/MW)
\c@bbx:relatedcount=\count427
\c@bbx:relatedtotal=\count428
)
Package biblatex Info: Delimiter 'nameyeardelim' in context 'bib' already defin
ed, overwriting.
Package biblatex Info: Delimiter 'nameyeardelim' in context 'biblist' already d
efined, overwriting.
Package biblatex Info: Delimiter 'nonameyeardelim' in context 'bib' already def
ined, overwriting.
Package biblatex Info: Delimiter 'nonameyeardelim' in context 'biblist' already
 defined, overwriting.
)
Package biblatex Info: Trying to load citation style 'apa'...
Package biblatex Info: ... file 'apa.cbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/apa.cbx
File: apa.cbx 2025/08/27 v9.20 APA biblatex citation style
Package biblatex Info: Delimiter 'nameyeardelim' in context '' already defined,
 overwriting.
Package biblatex Info: Delimiter 'andothersdelim' in context '' already defined
, overwriting.
Package biblatex Info: Redefining '\fullcite'.
Package biblatex Info: Redefining '\citeauthor'.
Package biblatex Info: Redefining '\citeyear'.
Package biblatex Info: Redefining '\cite'.
Package biblatex Info: Redefining '\cites'.
Package biblatex Info: Redefining '\parencite'.
Package biblatex Info: Redefining '\parencites'.
Package biblatex Info: Redefining '\footcite'.
Package biblatex Info: Redefining '\footcites'.
Package biblatex Info: Redefining '\footcitetext'.
Package biblatex Info: Redefining '\footcitetexts'.
Package biblatex Info: Redefining '\smartcite'.
Package biblatex Info: Redefining '\smartcites'.
Package biblatex Info: Redefining '\textcite'.
Package biblatex Info: Redefining '\textcites'.
)
Package biblatex Info: Trying to load configuration file...
Package biblatex Info: ... file 'biblatex.cfg' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/biblatex.cfg
File: biblatex.cfg 
)
Package biblatex Info: Input encoding 'utf8' detected.
Package biblatex Info: Document encoding is UTF8 ....

(/usr/local/texlive/2026/texmf-dist/tex/latex/l3kernel/expl3.sty
Package: expl3 2026-01-19 L3 programming layer (loader) 

(/usr/local/texlive/2026/texmf-dist/tex/latex/l3backend/l3backend-pdftex.def
File: l3backend-pdftex.def 2025-10-09 L3 backend support: PDF output (pdfTeX)
\l__color_backend_stack_int=\count429
))
Package biblatex Info: ... and expl3
(biblatex)             2026-01-19 L3 programming layer (loader) 
(biblatex)             is new enough (at least 2020/04/06),
(biblatex)             setting 'casechanger=expl3'.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/blx-case-expl3.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/l3packages/xparse/xparse.sty
Package: xparse 2025-10-09 L3 Experimental document command parser
)
Package: blx-case-expl3 2025/07/10 v3.21 expl3 case changing code for biblatex
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pdfpages/pdfpages.sty
Package: pdfpages 2025/07/23 v0.6g Insert pages of external PDF documents (AM)

(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/calc.sty
Package: calc 2025/03/01 v4.3b Infix arithmetic (KKT,FJ)
\calc@Acount=\count430
\calc@Bcount=\count431
\calc@Adimen=\dimen150
\calc@Bdimen=\dimen151
\calc@Askip=\skip73
\calc@Bskip=\skip74
LaTeX Info: Redefining \setlength on input line 86.
LaTeX Info: Redefining \addtolength on input line 87.
\calc@Ccount=\count432
\calc@Cskip=\skip75
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/eso-pic/eso-pic.sty
Package: eso-pic 2025/12/10 v3.0d eso-pic (RN)
\ESO@tempdima=\dimen152
\ESO@tempdimb=\dimen153

(/usr/local/texlive/2026/texmf-dist/tex/latex/xcolor/xcolor.sty
Package: xcolor 2024/09/29 v3.02 LaTeX color extensions (UK)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-cfg/color.cfg
File: color.cfg 2016/01/02 v1.6 sample color configuration
)
Package xcolor Info: Driver file: pdftex.def on input line 274.

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-def/pdftex.def
File: pdftex.def 2025/09/29 v1.2d Graphics/color driver for pdftex
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/mathcolor.ltx)
Package xcolor Info: Model `cmy' substituted by `cmy0' on input line 1349.
Package xcolor Info: Model `hsb' substituted by `rgb' on input line 1353.
Package xcolor Info: Model `RGB' extended on input line 1365.
Package xcolor Info: Model `HTML' substituted by `rgb' on input line 1367.
Package xcolor Info: Model `Hsb' substituted by `hsb' on input line 1368.
Package xcolor Info: Model `tHsb' substituted by `hsb' on input line 1369.
Package xcolor Info: Model `HSB' substituted by `hsb' on input line 1370.
Package xcolor Info: Model `Gray' substituted by `gray' on input line 1371.
Package xcolor Info: Model `wave' substituted by `hsb' on input line 1372.
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/graphicx.sty
Package: graphicx 2024/12/31 v1.2e Enhanced LaTeX Graphics (DPC,SPQR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/graphics.sty
Package: graphics 2024/08/06 v1.4g Standard LaTeX Graphics (DPC,SPQR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/trig.sty
Package: trig 2023/12/02 v1.11 sin cos tan (DPC)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/graphics-cfg/graphics.cfg
File: graphics.cfg 2016/06/04 v1.11 sample graphics configuration
)
Package graphics Info: Driver file: pdftex.def on input line 106.
)
\Gin@req@height=\dimen154
\Gin@req@width=\dimen155
)
\AM@pagewidth=\dimen156
\AM@pageheight=\dimen157
\AM@fboxrule=\dimen158

(/usr/local/texlive/2026/texmf-dist/tex/latex/pdfpages/pppdftex.def
File: pppdftex.def 2025/07/23 v0.6g Pdfpages driver for pdfTeX (AM)
)
\pdfpages@includegraphics@status=\count433
\AM@pagebox=\box53
\AM@global@opts=\toks22
\AM@pagecnt=\count434
\AM@toc@title=\toks23
\AM@lof@heading=\toks24
\c@AM@survey=\count435
\AM@templatesizebox=\box54
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsmath.sty
Package: amsmath 2025/07/09 v2.17z AMS math features
\@mathmargin=\skip76

For additional information on amsmath, use the `?' option.
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amstext.sty
Package: amstext 2024/11/17 v2.01 AMS text

(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsgen.sty
File: amsgen.sty 1999/11/30 v2.0 generic functions
\@emptytoks=\toks25
\ex@=\dimen159
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsbsy.sty
Package: amsbsy 1999/11/29 v1.2d Bold Symbols
\pmbraise@=\dimen160
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/amsmath/amsopn.sty
Package: amsopn 2022/04/08 v2.04 operator names
)
\inf@bad=\count436
LaTeX Info: Redefining \frac on input line 233.
\uproot@=\count437
\leftroot@=\count438
LaTeX Info: Redefining \overline on input line 398.
LaTeX Info: Redefining \colon on input line 409.
\classnum@=\count439
\DOTSCASE@=\count440
LaTeX Info: Redefining \ldots on input line 495.
LaTeX Info: Redefining \dots on input line 498.
LaTeX Info: Redefining \cdots on input line 619.
\Mathstrutbox@=\box55
\strutbox@=\box56
LaTeX Info: Redefining \big on input line 721.
LaTeX Info: Redefining \Big on input line 722.
LaTeX Info: Redefining \bigg on input line 723.
LaTeX Info: Redefining \Bigg on input line 724.
\big@size=\dimen161
LaTeX Font Info:    Redeclaring font encoding OML on input line 742.
LaTeX Font Info:    Redeclaring font encoding OMS on input line 743.
\macc@depth=\count441
LaTeX Info: Redefining \bmod on input line 904.
LaTeX Info: Redefining \pmod on input line 909.
LaTeX Info: Redefining \smash on input line 939.
LaTeX Info: Redefining \relbar on input line 969.
LaTeX Info: Redefining \Relbar on input line 970.
\c@MaxMatrixCols=\count442
\dotsspace@=\muskip22
\c@parentequation=\count443
\dspbrk@lvl=\count444
\tag@help=\toks26
\row@=\count445
\column@=\count446
\maxfields@=\count447
\andhelp@=\toks27
\eqnshift@=\dimen162
\alignsep@=\dimen163
\tagshift@=\dimen164
\tagwidth@=\dimen165
\totwidth@=\dimen166
\lineht@=\dimen167
\@envbody=\toks28
\multlinegap=\skip77
\multlinetaggap=\skip78
\mathdisplay@stack=\toks29
LaTeX Info: Redefining \[ on input line 2950.
LaTeX Info: Redefining \] on input line 2951.
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/cancel/cancel.sty
Package: cancel 2013/04/12 v2.2 Cancel math terms
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/jknapltx/mathrsfs.sty
Package: mathrsfs 1996/01/01 Math RSFS package v1.0 (jk)
\symrsfs=\mathgroup4
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/float/float.sty
Package: float 2001/11/08 v1.3d Float enhancements (AL)
\c@float@type=\count448
\float@exts=\toks30
\float@box=\box57
\@float@everytoks=\toks31
\@floatcapt=\box58
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/placeins/placeins.sty
Package: placeins 2005/04/18  v 2.2
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/subcaption.sty
Package: subcaption 2023/07/28 v1.6b Sub-captions (AR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/caption.sty
Package: caption 2023/08/05 v3.6o Customizing captions (AR)

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/caption3.sty
Package: caption3 2023/07/31 v2.4d caption3 kernel (AR)
\caption@tempdima=\dimen168
\captionmargin=\dimen169
\caption@leftmargin=\dimen170
\caption@rightmargin=\dimen171
\caption@width=\dimen172
\caption@indent=\dimen173
\caption@parindent=\dimen174
\caption@hangindent=\dimen175
Package caption Info: Standard document class detected.
)
\c@caption@flags=\count449
\c@continuedfloat=\count450
Package caption Info: float package is loaded.
)
Package caption Info: New subtype `subfigure' on input line 238.
\c@subfigure=\count451
Package caption Info: New subtype `subtable' on input line 238.
\c@subtable=\count452
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/colortbl/colortbl.sty
Package: colortbl 2024/10/29 v1.0k Color table columns (DPC)

(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/array.sty
Package: array 2025/09/25 v2.6n Tabular extension package (FMi)
\col@sep=\dimen176
\ar@mcellbox=\box59
\extrarowheight=\dimen177
\NC@list=\toks32
\extratabsurround=\skip79
\backup@length=\skip80
\ar@cellbox=\box60
)
\everycr=\toks33
\minrowclearance=\skip81
\rownum=\count453
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/makecell/makecell.sty
Package: makecell 2009/08/03 V0.1e Managing of Tab Column Heads and Cells
\rotheadsize=\dimen178
\c@nlinenum=\count454
\TeXr@lab=\toks34
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/longtable.sty
Package: longtable 2025-10-13 v4.24 Multi-page Table package (DPC)
\LTleft=\skip82
\LTright=\skip83
\LTpre=\skip84
\LTpost=\skip85
\LTchunksize=\count455
\LTcapwidth=\dimen179
\LT@head=\box61
\LT@firsthead=\box62
\LT@foot=\box63
\LT@lastfoot=\box64
\LT@gbox=\box65
\LT@cols=\count456
\LT@rows=\count457
\c@LT@tables=\count458
\c@LT@chunks=\count459
\LT@p@ftn=\toks35
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/tools/tabularx.sty
Package: tabularx 2023/12/11 v2.12a `tabularx' package (DPC)
\TX@col@width=\dimen180
\TX@old@table=\dimen181
\TX@old@col=\dimen182
\TX@target=\dimen183
\TX@delta=\dimen184
\TX@cols=\count460
\TX@ftn=\toks36
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/booktabs/booktabs.sty
Package: booktabs 2020/01/12 v1.61803398 Publication quality tables
\heavyrulewidth=\dimen185
\lightrulewidth=\dimen186
\cmidrulewidth=\dimen187
\belowrulesep=\dimen188
\belowbottomsep=\dimen189
\aboverulesep=\dimen190
\abovetopsep=\dimen191
\cmidrulesep=\dimen192
\cmidrulekern=\dimen193
\defaultaddspace=\dimen194
\@cmidla=\count461
\@cmidlb=\count462
\@aboverulesep=\dimen195
\@belowrulesep=\dimen196
\@thisruleclass=\count463
\@lastruleclass=\count464
\@thisrulewidth=\dimen197
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/frontendlayer/tikz.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/basiclayer/pgf.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgfrcs.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfutil-common.te
x
\pgfutil@everybye=\toks37
\pgfutil@tempdima=\dimen198
\pgfutil@tempdimb=\dimen199
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfutil-latex.def
\pgfutil@abb=\box66
) (/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfrcs.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/pgf.revision.tex)
Package: pgfrcs 2025-08-29 v3.1.11a (3.1.11a)
))
Package: pgf 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/basiclayer/pgfcore.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/systemlayer/pgfsys.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys.code.tex
Package: pgfsys 2025-08-29 v3.1.11a (3.1.11a)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeys.code.tex
\pgfkeys@pathtoks=\toks38
\pgfkeys@temptoks=\toks39

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeyslibraryfil
tered.code.tex
\pgfkeys@tmptoks=\toks40
))
\pgf@x=\dimen256
\pgf@y=\dimen257
\pgf@xa=\dimen258
\pgf@ya=\dimen259
\pgf@xb=\dimen260
\pgf@yb=\dimen261
\pgf@xc=\dimen262
\pgf@yc=\dimen263
\pgf@xd=\dimen264
\pgf@yd=\dimen265
\w@pgf@writea=\write4
\r@pgf@reada=\read4
\c@pgf@counta=\count465
\c@pgf@countb=\count466
\c@pgf@countc=\count467
\c@pgf@countd=\count468
\t@pgf@toka=\toks41
\t@pgf@tokb=\toks42
\t@pgf@tokc=\toks43
\pgf@sys@id@count=\count469

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgf.cfg
File: pgf.cfg 2025-08-29 v3.1.11a (3.1.11a)
)
Driver file for pgf: pgfsys-pdftex.def

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys-pdftex.d
ef
File: pgfsys-pdftex.def 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsys-common-p
df.def
File: pgfsys-common-pdf.def 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsyssoftpath.
code.tex
File: pgfsyssoftpath.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfsyssoftpath@smallbuffer@items=\count470
\pgfsyssoftpath@bigbuffer@items=\count471
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/systemlayer/pgfsysprotocol.
code.tex
File: pgfsysprotocol.code.tex 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcore.code.tex
Package: pgfcore 2025-08-29 v3.1.11a (3.1.11a)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmath.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathutil.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathparser.code.tex
\pgfmath@dimen=\dimen266
\pgfmath@count=\count472
\pgfmath@box=\box67
\pgfmath@toks=\toks44
\pgfmath@stack@operand=\toks45
\pgfmath@stack@operation=\toks46
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.code.
tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.basic
.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.trigo
nometric.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.rando
m.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.compa
rison.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.base.
code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.round
.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.misc.
code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfunctions.integ
erarithmetics.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathcalc.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmathfloat.code.tex
\c@pgfmathroundto@lastzeros=\count473
)) (/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfint.code.tex)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepoints.co
de.tex
File: pgfcorepoints.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@picminx=\dimen267
\pgf@picmaxx=\dimen268
\pgf@picminy=\dimen269
\pgf@picmaxy=\dimen270
\pgf@pathminx=\dimen271
\pgf@pathmaxx=\dimen272
\pgf@pathminy=\dimen273
\pgf@pathmaxy=\dimen274
\pgf@xx=\dimen275
\pgf@xy=\dimen276
\pgf@yx=\dimen277
\pgf@yy=\dimen278
\pgf@zx=\dimen279
\pgf@zy=\dimen280
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathconst
ruct.code.tex
File: pgfcorepathconstruct.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@path@lastx=\dimen281
\pgf@path@lasty=\dimen282
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathusage
.code.tex
File: pgfcorepathusage.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@shorten@end@additional=\dimen283
\pgf@shorten@start@additional=\dimen284
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorescopes.co
de.tex
File: pgfcorescopes.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfpic=\box68
\pgf@hbox=\box69
\pgf@layerbox@main=\box70
\pgf@picture@serial@count=\count474
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoregraphicst
ate.code.tex
File: pgfcoregraphicstate.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgflinewidth=\dimen285
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoretransform
ations.code.tex
File: pgfcoretransformations.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@pt@x=\dimen286
\pgf@pt@y=\dimen287
\pgf@pt@temp=\dimen288
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorequick.cod
e.tex
File: pgfcorequick.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreobjects.c
ode.tex
File: pgfcoreobjects.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepathproce
ssing.code.tex
File: pgfcorepathprocessing.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorearrows.co
de.tex
File: pgfcorearrows.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfarrowsep=\dimen289
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreshade.cod
e.tex
File: pgfcoreshade.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@max=\dimen290
\pgf@sys@shading@range@num=\count475
\pgf@shadingcount=\count476
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreimage.cod
e.tex
File: pgfcoreimage.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoreexternal.
code.tex
File: pgfcoreexternal.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfexternal@startupbox=\box71
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorelayers.co
de.tex
File: pgfcorelayers.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcoretranspare
ncy.code.tex
File: pgfcoretransparency.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorepatterns.
code.tex
File: pgfcorepatterns.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/basiclayer/pgfcorerdf.code.
tex
File: pgfcorerdf.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduleshapes.cod
e.tex
File: pgfmoduleshapes.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfnodeparttextbox=\box72
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduleplot.code.
tex
File: pgfmoduleplot.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/compatibility/pgfcomp-version
-0-65.sty
Package: pgfcomp-version-0-65 2025-08-29 v3.1.11a (3.1.11a)
\pgf@nodesepstart=\dimen291
\pgf@nodesepend=\dimen292
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/compatibility/pgfcomp-version
-1-18.sty
Package: pgfcomp-version-1-18 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgffor.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/utilities/pgfkeys.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgfkeys.code.tex)
) (/usr/local/texlive/2026/texmf-dist/tex/latex/pgf/math/pgfmath.sty
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/math/pgfmath.code.tex))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/utilities/pgffor.code.tex
Package: pgffor 2025-08-29 v3.1.11a (3.1.11a)
\pgffor@iter=\dimen293
\pgffor@skip=\dimen294
\pgffor@stack=\toks47
\pgffor@toks=\toks48
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/tikz.cod
e.tex
Package: tikz 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryplothan
dlers.code.tex
File: pgflibraryplothandlers.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgf@plot@mark@count=\count477
\pgfplotmarksize=\dimen295
)
\tikz@lastx=\dimen296
\tikz@lasty=\dimen297
\tikz@lastxsaved=\dimen298
\tikz@lastysaved=\dimen299
\tikz@lastmovetox=\dimen300
\tikz@lastmovetoy=\dimen301
\tikzleveldistance=\dimen302
\tikzsiblingdistance=\dimen303
\tikz@figbox=\box73
\tikz@figbox@bg=\box74
\tikz@tempbox=\box75
\tikz@tempbox@bg=\box76
\tikztreelevel=\count478
\tikznumberofchildren=\count479
\tikznumberofcurrentchild=\count480
\tikz@fig@count=\count481

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmodulematrix.cod
e.tex
File: pgfmodulematrix.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfmatrixcurrentrow=\count482
\pgfmatrixcurrentcolumn=\count483
\pgf@matrix@numberofcolumns=\count484
)
\tikz@expandcount=\count485

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarytopaths.code.tex
File: tikzlibrarytopaths.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshapes.geometric.code.tex
File: tikzlibraryshapes.geometric.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/shapes/pgflibrary
shapes.geometric.code.tex
File: pgflibraryshapes.geometric.code.tex 2025-08-29 v3.1.11a (3.1.11a)
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshapes.multipart.code.tex
File: tikzlibraryshapes.multipart.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/shapes/pgflibrary
shapes.multipart.code.tex
File: pgflibraryshapes.multipart.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfnodepartlowerbox=\box77
\pgfnodeparttwobox=\box78
\pgfnodepartthreebox=\box79
\pgfnodepartfourbox=\box80
\pgfnodeparttwentybox=\box81
\pgfnodepartnineteenbox=\box82
\pgfnodeparteighteenbox=\box83
\pgfnodepartseventeenbox=\box84
\pgfnodepartsixteenbox=\box85
\pgfnodepartfifteenbox=\box86
\pgfnodepartfourteenbox=\box87
\pgfnodepartthirteenbox=\box88
\pgfnodeparttwelvebox=\box89
\pgfnodepartelevenbox=\box90
\pgfnodeparttenbox=\box91
\pgfnodepartninebox=\box92
\pgfnodeparteightbox=\box93
\pgfnodepartsevenbox=\box94
\pgfnodepartsixbox=\box95
\pgfnodepartfivebox=\box96
))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarypositioning.code.tex
File: tikzlibrarypositioning.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryarrows.
meta.code.tex
File: pgflibraryarrows.meta.code.tex 2025-08-29 v3.1.11a (3.1.11a)
\pgfarrowinset=\dimen304
\pgfarrowlength=\dimen305
\pgfarrowwidth=\dimen306
\pgfarrowlinewidth=\dimen307
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarycalc.code.tex
File: tikzlibrarycalc.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryshadows.code.tex
File: tikzlibraryshadows.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibraryfadings.code.tex
File: tikzlibraryfadings.code.tex 2025-08-29 v3.1.11a (3.1.11a)

(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/pgflibraryfadings
.code.tex
File: pgflibraryfadings.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarydecorations.pathreplacing.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarydecorations.code.tex
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/modules/pgfmoduledecoration
s.code.tex
\pgfdecoratedcompleteddistance=\dimen308
\pgfdecoratedremainingdistance=\dimen309
\pgfdecoratedinputsegmentcompleteddistance=\dimen310
\pgfdecoratedinputsegmentremainingdistance=\dimen311
\pgf@decorate@distancetomove=\dimen312
\pgf@decorate@repeatstate=\count486
\pgfdecorationsegmentamplitude=\dimen313
\pgfdecorationsegmentlength=\dimen314
)
\tikz@lib@dec@box=\box97
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/libraries/decorations/pgfli
brarydecorations.pathreplacing.code.tex))
(/usr/local/texlive/2026/texmf-dist/tex/generic/pgf/frontendlayer/tikz/librarie
s/tikzlibrarybabel.code.tex
File: tikzlibrarybabel.code.tex 2025-08-29 v3.1.11a (3.1.11a)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/enumitem/enumitem.sty
Package: enumitem 2025/02/06 v3.11 Customized lists
\labelindent=\skip86
\enit@outerparindent=\dimen315
\enit@toks=\toks49
\enit@inbox=\box98
\enit@count@id=\count487
\enitdp@description=\count488
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/listings.sty
\lst@mode=\count489
\lst@gtempboxa=\box99
\lst@token=\toks50
\lst@length=\count490
\lst@currlwidth=\dimen316
\lst@column=\count491
\lst@pos=\count492
\lst@lostspace=\dimen317
\lst@width=\dimen318
\lst@newlines=\count493
\lst@lineno=\count494
\lst@maxwidth=\dimen319

(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/lstpatch.sty
File: lstpatch.sty 2025/11/14 1.11b (Carsten Heinz)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/lstmisc.sty
File: lstmisc.sty 2025/11/14 1.11b (Carsten Heinz)
\c@lstnumber=\count495
\lst@skipnumbers=\count496
\lst@framebox=\box100
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/listings/listings.cfg
File: listings.cfg 2025/11/14 1.11b listings configuration
))
Package: listings 2025/11/14 1.11b (Carsten Heinz)

==> First Aid for listings.sty no longer applied!
    Expected:
        2024/09/23 1.10c (Carsten Heinz)
    but found:
        2025/11/14 1.11b (Carsten Heinz)
    so I'm assuming it got fixed.
(/usr/local/texlive/2026/texmf-dist/tex/latex/tocloft/tocloft.sty
Package: tocloft 2017/08/31 v2.3i parameterised ToC, etc., typesetting
Package tocloft Info: The document has section divisions on input line 51.
\cftparskip=\skip87
\cftbeforetoctitleskip=\skip88
\cftaftertoctitleskip=\skip89
\cftbeforepartskip=\skip90
\cftpartnumwidth=\skip91
\cftpartindent=\skip92
\cftbeforesecskip=\skip93
\cftsecindent=\skip94
\cftsecnumwidth=\skip95
\cftbeforesubsecskip=\skip96
\cftsubsecindent=\skip97
\cftsubsecnumwidth=\skip98
\cftbeforesubsubsecskip=\skip99
\cftsubsubsecindent=\skip100
\cftsubsubsecnumwidth=\skip101
\cftbeforeparaskip=\skip102
\cftparaindent=\skip103
\cftparanumwidth=\skip104
\cftbeforesubparaskip=\skip105
\cftsubparaindent=\skip106
\cftsubparanumwidth=\skip107
\cftbeforeloftitleskip=\skip108
\cftafterloftitleskip=\skip109
\cftbeforefigskip=\skip110
\cftfigindent=\skip111
\cftfignumwidth=\skip112
\c@lofdepth=\count497
\c@lotdepth=\count498
\cftbeforelottitleskip=\skip113
\cftafterlottitleskip=\skip114
\cftbeforetabskip=\skip115
\cfttabindent=\skip116
\cfttabnumwidth=\skip117
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/geometry/geometry.sty
Package: geometry 2026/03/07 v6.0 Page Geometry

(/usr/local/texlive/2026/texmf-dist/tex/generic/iftex/ifvtex.sty
Package: ifvtex 2019/10/25 v1.7 ifvtex legacy package. Use iftex instead.
)
\Gm@cnth=\count499
\Gm@cntv=\count500
\c@Gm@tempcnt=\count501
\Gm@bindingoffset=\dimen320
\Gm@wd@mp=\dimen321
\Gm@odd@mp=\dimen322
\Gm@even@mp=\dimen323
\Gm@layoutwidth=\dimen324
\Gm@layoutheight=\dimen325
\Gm@layouthoffset=\dimen326
\Gm@layoutvoffset=\dimen327
\Gm@dimlist=\toks51
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/setspace/setspace.sty
Package: setspace 2022/12/04 v6.7b set line spacing
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/parskip/parskip.sty
Package: parskip 2021-03-14 v2.0h non-zero parskip adjustments
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/lipsum/lipsum.sty
(/usr/local/texlive/2026/texmf-dist/tex/latex/l3packages/l3keys2e/l3keys2e.sty
Package: l3keys2e 2025-10-09 LaTeX2e option processing using LaTeX3 keys
)
Package: lipsum 2021-09-20 v2.7 150 paragraphs of Lorem Ipsum dummy text
\g__lipsum_par_int=\count502
\l__lipsum_a_int=\count503
\l__lipsum_b_int=\count504
(/usr/local/texlive/2026/texmf-dist/tex/latex/lipsum/lipsum.ltd.tex))
(/usr/local/texlive/2026/texmf-dist/tex/latex/fancyhdr/fancyhdr.sty
Package: fancyhdr 2025/02/07 v5.2 Extensive control of page headers and footers

\f@nch@headwidth=\skip118
\f@nch@offset@elh=\skip119
\f@nch@offset@erh=\skip120
\f@nch@offset@olh=\skip121
\f@nch@offset@orh=\skip122
\f@nch@offset@elf=\skip123
\f@nch@offset@erf=\skip124
\f@nch@offset@olf=\skip125
\f@nch@offset@orf=\skip126
\f@nch@height=\skip127
\f@nch@footalignment=\skip128
\f@nch@widthL=\skip129
\f@nch@widthC=\skip130
\f@nch@widthR=\skip131
\@temptokenb=\toks52
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/hyperref.sty
Package: hyperref 2026-01-29 v7.01p Hypertext links for LaTeX

(/usr/local/texlive/2026/texmf-dist/tex/generic/kvdefinekeys/kvdefinekeys.sty
Package: kvdefinekeys 2019-12-19 v1.6 Define keys (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/pdfescape/pdfescape.sty
Package: pdfescape 2019/12/09 v1.15 Implements pdfTeX's escape features (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hycolor/hycolor.sty
Package: hycolor 2020-01-27 v1.10 Color options for hyperref/bookmark (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/nameref.sty
Package: nameref 2026-01-29 v2.58 Cross-referencing by name of section

(/usr/local/texlive/2026/texmf-dist/tex/latex/refcount/refcount.sty
Package: refcount 2019/12/15 v3.6 Data extraction from label references (HO)
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/gettitlestring/gettitlestring.s
ty
Package: gettitlestring 2019/12/15 v1.6 Cleanup title references (HO)
)
\c@section@level=\count505
) (/usr/local/texlive/2026/texmf-dist/tex/generic/stringenc/stringenc.sty
Package: stringenc 2019/11/29 v1.12 Convert strings between diff. encodings (HO
)
)
\@linkdim=\dimen328
\Hy@linkcounter=\count506
\Hy@pagecounter=\count507

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/pd1enc.def
File: pd1enc.def 2026-01-29 v7.01p Hyperref: PDFDocEncoding definition (HO)
Now handling font encoding PD1 ...
... no UTF-8 mapping file for font encoding PD1
)
(/usr/local/texlive/2026/texmf-dist/tex/generic/intcalc/intcalc.sty
Package: intcalc 2019/12/15 v1.3 Expandable calculations with integers (HO)
)
\Hy@SavedSpaceFactor=\count508

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/puenc.def
File: puenc.def 2026-01-29 v7.01p Hyperref: PDF Unicode definition (HO)
Now handling font encoding PU ...
... no UTF-8 mapping file for font encoding PU
)
Package hyperref Info: Hyper figures OFF on input line 4201.
Package hyperref Info: Link nesting OFF on input line 4206.
Package hyperref Info: Hyper index ON on input line 4209.
Package hyperref Info: Plain pages OFF on input line 4216.
Package hyperref Info: Backreferencing OFF on input line 4221.
Package hyperref Info: Implicit mode ON; LaTeX internals redefined.
Package hyperref Info: Bookmarks ON on input line 4468.
\c@Hy@tempcnt=\count509
LaTeX Info: Redefining \url on input line 4807.
\XeTeXLinkMargin=\dimen329

(/usr/local/texlive/2026/texmf-dist/tex/generic/bitset/bitset.sty
Package: bitset 2019/12/09 v1.3 Handle bit-vector datatype (HO)

(/usr/local/texlive/2026/texmf-dist/tex/generic/bigintcalc/bigintcalc.sty
Package: bigintcalc 2019/12/15 v1.5 Expandable calculations on big integers (HO
)
))
\Fld@menulength=\count510
\Field@Width=\dimen330
\Fld@charsize=\dimen331
Package hyperref Info: Hyper figures OFF on input line 6084.
Package hyperref Info: Link nesting OFF on input line 6089.
Package hyperref Info: Hyper index ON on input line 6092.
Package hyperref Info: backreferencing OFF on input line 6099.
Package hyperref Info: Link coloring OFF on input line 6104.
Package hyperref Info: Link coloring with OCG OFF on input line 6109.
Package hyperref Info: PDF/A mode OFF on input line 6114.
\Hy@abspage=\count511
\c@Item=\count512
\c@Hfootnote=\count513
)
Package hyperref Info: Driver (autodetected): hpdftex.

(/usr/local/texlive/2026/texmf-dist/tex/latex/hyperref/hpdftex.def
File: hpdftex.def 2026-01-29 v7.01p Hyperref driver for pdfTeX
\Fld@listcount=\count514
\c@bookmark@seq@number=\count515

(/usr/local/texlive/2026/texmf-dist/tex/latex/rerunfilecheck/rerunfilecheck.sty
Package: rerunfilecheck 2025-06-21 v1.11 Rerun checks for auxiliary files (HO)

(/usr/local/texlive/2026/texmf-dist/tex/generic/uniquecounter/uniquecounter.sty
Package: uniquecounter 2019/12/15 v1.4 Provide unlimited unique counter (HO)
)
Package uniquecounter Info: New unique counter `rerunfilecheck' on input line 2
84.
)
\Hy@SectionHShift=\skip132
)
Package hyperref Info: Option `colorlinks' set `true' on input line 208.
Package csquotes Info: Checking for multilingual support...
Package csquotes Info: ... found 'babel' package.
Package csquotes Info: Adjusting default style.
Package csquotes Info: Redefining alias 'default' -> 'spanish'.
 (./main.aux
LaTeX Info: Redefining \. on input line 9.
LaTeX Info: Redefining \% on input line 9.
Package babel Info: 'spanish' activates 'spanish' shorthands.
(babel)             Reported on input line 9.
)
\openout1 = `main.aux'.

LaTeX Font Info:    Checking defaults for OML/cmm/m/it on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OMS/cmsy/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OT1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for T1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for TS1/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for OMX/cmex/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for U/cmr/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for PD1/pdf/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Font Info:    Checking defaults for PU/pdf/m/n on input line 211.
LaTeX Font Info:    ... okay on input line 211.
LaTeX Info: Redefining \. on input line 211.
LaTeX Info: Redefining \% on input line 211.
Package biblatex Info: Trying to load language 'spanish' -> 'spanish-apa'...
Package biblatex Info: ... file 'spanish-apa.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex-apa/spanish-apa.lbx
File: spanish-apa.lbx 2025/08/27 v9.20 APA biblatex localisation
Package biblatex Info: Trying to load language 'spanish'...
Package biblatex Info: ... file 'spanish.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/lbx/spanish.lbx
File: spanish.lbx 2025/07/10 v3.21 biblatex localization (PK/MW)
)
Package biblatex Info: Trying to load language 'spanish'...
Package biblatex Info: ... file 'spanish.lbx' found.

(/usr/local/texlive/2026/texmf-dist/tex/latex/biblatex/lbx/spanish.lbx
File: spanish.lbx 2025/07/10 v3.21 biblatex localization (PK/MW)
))
Package biblatex Info: Input encoding 'utf8' detected.
Package biblatex Info: Automatic encoding selection.
(biblatex)             Assuming data encoding 'utf8'.
\openout3 = `main.bcf'.

Package biblatex Info: Trying to load bibliographic data...
Package biblatex Info: ... file 'main.bbl' found.

(./main.bbl)
Package biblatex Info: Reference section=0 on input line 211.
Package biblatex Info: Reference segment=0 on input line 211.

(/usr/local/texlive/2026/texmf-dist/tex/context/base/mkii/supp-pdf.mkii
[Loading MPS to PDF converter (version 2006.09.02).]
\scratchcounter=\count516
\scratchdimen=\dimen332
\scratchbox=\box101
\nofMPsegments=\count517
\nofMParguments=\count518
\everyMPshowfont=\toks53
\MPscratchCnt=\count519
\MPscratchDim=\dimen333
\MPnumerator=\count520
\makeMPintoPDFobject=\count521
\everyMPtoPDFconversion=\toks54
) (/usr/local/texlive/2026/texmf-dist/tex/latex/epstopdf-pkg/epstopdf-base.sty
Package: epstopdf-base 2020-01-24 v2.11 Base part for package epstopdf
Package epstopdf-base Info: Redefining graphics rule for `.eps' on input line 4
85.

(/usr/local/texlive/2026/texmf-dist/tex/latex/latexconfig/epstopdf-sys.cfg
File: epstopdf-sys.cfg 2010/07/13 v1.3 Configuration of (r)epstopdf for TeX Liv
e
))
(/usr/local/texlive/2026/texmf-dist/tex/latex/pdflscape/pdflscape.sty
Package: pdflscape 2025-06-23 v0.14 Display of landscape pages in PDF

(/usr/local/texlive/2026/texmf-dist/tex/latex/pdflscape/pdflscape-nometadata.st
y
Package: pdflscape-nometadata 2025-06-23 v0.14 Display of landscape pages in PD
F (HO)
 (/usr/local/texlive/2026/texmf-dist/tex/latex/graphics/lscape.sty
Package: lscape 2020/05/28 v3.02 Landscape Pages (DPC)
)
Package pdflscape Info: Auto-detected driver: pdftex on input line 81.
))
Package caption Info: Begin \AtBeginDocument code.
Package caption Info: hyperref package is loaded.
Package caption Info: listings package is loaded.
Package caption Info: longtable package is loaded.

(/usr/local/texlive/2026/texmf-dist/tex/latex/caption/ltcaption.sty
Package: ltcaption 2021/01/08 v1.4c longtable captions (AR)
)
Package caption Info: End \AtBeginDocument code.
\c@lstlisting=\count522

*geometry* driver: auto-detecting
*geometry* detected driver: pdftex
*geometry* verbose mode - [ preamble ] result:
* driver: pdftex
* paper: custom
* layout: <same size as paper>
* layoutoffset:(h,v)=(0.0pt,0.0pt)
* modes: 
* h-part:(L,W,R)=(71.13188pt, 472.03113pt, 71.13188pt)
* v-part:(T,H,B)=(99.58464pt, 610.02716pt, 85.35826pt)
* \paperwidth=614.29489pt
* \paperheight=794.97006pt
* \textwidth=472.03113pt
* \textheight=610.02716pt
* \oddsidemargin=-1.1381pt
* \evensidemargin=-1.1381pt
* \topmargin=-74.68535pt
* \headheight=77.0pt
* \headsep=25.0pt
* \topskip=11.0pt
* \footskip=30.0pt
* \marginparwidth=59.0pt
* \marginparsep=10.0pt
* \columnsep=10.0pt
* \skip\footins=10.0pt plus 4.0pt minus 2.0pt
* \hoffset=0.0pt
* \voffset=0.0pt
* \mag=1000
* \@twocolumnfalse
* \@twosidefalse
* \@mparswitchfalse
* \@reversemarginfalse
* (1in=72.27pt=25.4mm, 1cm=28.453pt)

Package hyperref Info: Link coloring ON on input line 211.
(./main.out) (./main.out)
\@outlinefile=\write5
\openout5 = `main.out'.

Package hyperref Info: Option `pageanchor' set `false' on input line 212.
 (./Portada.tex
LaTeX Font Info:    Trying to load font information for U+rsfs on input line 6.


(/usr/local/texlive/2026/texmf-dist/tex/latex/jknapltx/ursfs.fd
File: ursfs.fd 1998/03/24 rsfs font definition file (jk)
)
<portada_img/der.png, id=195, 332.24126pt x 393.47pt>
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 8.
(pdftex.def)             Requested size: 56.9055pt x 67.38733pt.
<portada_img/izq.png, id=197, 254.9525pt x 301.125pt>
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 14.
(pdftex.def)             Requested size: 56.9055pt x 67.20801pt.
) [1

{/usr/local/texlive/2026/texmf-var/fonts/map/pdftex/updmap/pdftex.map} <./porta
da_img/der.png> <./portada_img/izq.png>] (./main.toc
LaTeX Info: Redefining \sptext on input line 1.
LaTeX Info: Redefining \. on input line 1.
LaTeX Info: Redefining \% on input line 1.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 31.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 31.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [1])
\tf@toc=\write6
\openout6 = `main.toc'.

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 217.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 217.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [2]
Package hyperref Info: Option `pageanchor' set `true' on input line 217.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 235.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 235.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [1]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 252.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 252.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [2]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 266.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 266.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [3]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 283.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 283.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [4]
<figuras/eda_plays_log.png, id=293, 505.89pt x 289.08pt>
File: figuras/eda_plays_log.png Graphic file (type png)
<use figuras/eda_plays_log.png>
Package pdftex.def Info: figuras/eda_plays_log.png  used on input line 286.
(pdftex.def)             Requested size: 448.38805pt x 256.22174pt.
<figuras/graficas_logaritmicas_corregidas.jpg, id=294, 1284.8pt x 722.7pt>
File: figuras/graficas_logaritmicas_corregidas.jpg Graphic file (type jpg)
<use figuras/graficas_logaritmicas_corregidas.jpg>
Package pdftex.def Info: figuras/graficas_logaritmicas_corregidas.jpg  used on 
input line 289.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 290.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 290.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [5 <./figuras/eda_plays_log.png>]
Underfull \hbox (badness 10000) in paragraph at lines 301--301
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 305--305
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 308--308
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 310--310
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


Underfull \hbox (badness 10000) in paragraph at lines 311--311
[]|\OT1/cmr/m/n/10.95 Metacritic Ra-
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 312.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 312.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[6 <./figuras/graficas_logaritmicas_corregidas.jpg>]
Underfull \hbox (badness 5022) in paragraph at lines 342--342
[]|\OT1/cmr/m/n/10.95 Card & Board
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 347.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 347.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[7]
Underfull \hbox (badness 10000) in paragraph at lines 364--364
[]|\OT1/cmr/m/n/10.95 Ubisoft En-ter-tain-
 []


ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 391.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 391.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[8]
<figuras/clustering_03_kmeans.png, id=319, 722.7pt x 289.08pt>
File: figuras/clustering_03_kmeans.png Graphic file (type png)
<use figuras/clustering_03_kmeans.png>
Package pdftex.def Info: figuras/clustering_03_kmeans.png  used on input line 4
00.
(pdftex.def)             Requested size: 472.03212pt x 188.81284pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 401.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 401.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [9]
<figuras/clustering_03_proyeccion.png, id=325, 722.7pt x 289.08pt>
File: figuras/clustering_03_proyeccion.png Graphic file (type png)
<use figuras/clustering_03_proyeccion.png>
Package pdftex.def Info: figuras/clustering_03_proyeccion.png  used on input li
ne 407.
(pdftex.def)             Requested size: 472.03212pt x 188.81284pt.

Underfull \hbox (badness 1237) in paragraph at lines 424--425
[]|\OT1/cmr/m/n/10.95 Condemned: Cri-mi-nal Ori-
 []

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 425.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 425.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[10 <./figuras/clustering_03_kmeans.png> <./figuras/clustering_03_proyeccion.pn
g>]
<figuras/clustering_03_dbscan_kdistancia.png, id=335, 578.16pt x 289.08pt>
File: figuras/clustering_03_dbscan_kdistancia.png Graphic file (type png)
<use figuras/clustering_03_dbscan_kdistancia.png>
Package pdftex.def Info: figuras/clustering_03_dbscan_kdistancia.png  used on i
nput line 432.
(pdftex.def)             Requested size: 472.02992pt x 236.01495pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 433.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 433.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [11]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 444.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 444.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [12 <./figuras/clustering_03_dbscan_kdistancia.png>]
Underfull \hbox (badness 3930) in paragraph at lines 454--454
[]|\OT1/cmr/m/n/10.95 Exactitud prue-
 []


Underfull \hbox (badness 3930) in paragraph at lines 455--455
[]|\OT1/cmr/m/n/10.95 Exactitud prue-
 []

File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 467.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 467.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
[13]
<figuras/graficas_permutacion_corregida.jpg, id=356, 1284.8pt x 903.375pt>
File: figuras/graficas_permutacion_corregida.jpg Graphic file (type jpg)
<use figuras/graficas_permutacion_corregida.jpg>
Package pdftex.def Info: figuras/graficas_permutacion_corregida.jpg  used on in
put line 470.
(pdftex.def)             Requested size: 442.4723pt x 311.11334pt.

ignored: Infinite glue shrinkage found in box being split
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 486.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 486.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [14 <./figuras/graficas_permutacion_corregida.jpg>]
<figuras/RandomForest.png, id=365, 2055.68pt x 1541.76pt>
File: figuras/RandomForest.png Graphic file (type png)
<use figuras/RandomForest.png>
Package pdftex.def Info: figuras/RandomForest.png  used on input line 502.
(pdftex.def)             Requested size: 472.01228pt x 354.0092pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 503.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 503.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [15]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 503.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 503.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [16 <./figuras/RandomForest.png>]
<figuras/kmeans_resultado.png, id=379, 2055.68pt x 1541.76pt>
File: figuras/kmeans_resultado.png Graphic file (type png)
<use figuras/kmeans_resultado.png>
Package pdftex.def Info: figuras/kmeans_resultado.png  used on input line 513.
(pdftex.def)             Requested size: 447.32637pt x 335.49477pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 514.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 514.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [17]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 514.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 514.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [18 <./figuras/kmeans_resultado.png>]
<figuras/dbscan_resultado.png, id=389, 2055.68pt x 1541.76pt>
File: figuras/dbscan_resultado.png Graphic file (type png)
<use figuras/dbscan_resultado.png>
Package pdftex.def Info: figuras/dbscan_resultado.png  used on input line 518.
(pdftex.def)             Requested size: 422.95412pt x 317.21559pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 526.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 526.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [19 <./figuras/dbscan_resultado.png>]
<figuras/inicio_actual.jpg, id=395, 1284.8pt x 722.7pt>
File: figuras/inicio_actual.jpg Graphic file (type jpg)
<use figuras/inicio_actual.jpg>
Package pdftex.def Info: figuras/inicio_actual.jpg  used on input line 527.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
<figuras/formulario_verificado.jpg, id=396, 1284.8pt x 722.7pt>
File: figuras/formulario_verificado.jpg Graphic file (type jpg)
<use figuras/formulario_verificado.jpg>
Package pdftex.def Info: figuras/formulario_verificado.jpg  used on input line 
530.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 531.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 531.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [20 <./figuras/inicio_actual.jpg>]
<figuras/sin_critica_verificado.jpg, id=402, 1284.8pt x 722.7pt>
File: figuras/sin_critica_verificado.jpg Graphic file (type jpg)
<use figuras/sin_critica_verificado.jpg>
Package pdftex.def Info: figuras/sin_critica_verificado.jpg  used on input line
 535.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 536.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 536.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [21 <./figuras/formulario_verificado.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 546.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 546.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [22 <./figuras/sin_critica_verificado.jpg>]
<figuras/sensibilidad_escenarios.png, id=414, 578.16pt x 361.35pt>
File: figuras/sensibilidad_escenarios.png Graphic file (type png)
<use figuras/sensibilidad_escenarios.png>
Package pdftex.def Info: figuras/sensibilidad_escenarios.png  used on input lin
e 568.
(pdftex.def)             Requested size: 472.03113pt x 295.0187pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 568.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 568.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [23]
<figuras/escenario_S1.jpg, id=420, 1284.8pt x 722.7pt>
File: figuras/escenario_S1.jpg Graphic file (type jpg)
<use figuras/escenario_S1.jpg>
Package pdftex.def Info: figuras/escenario_S1.jpg  used on input line 570.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 570.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 570.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [24 <./figuras/sensibilidad_escenarios.png>]
<figuras/escenario_S2.jpg, id=427, 1284.8pt x 722.7pt>
File: figuras/escenario_S2.jpg Graphic file (type jpg)
<use figuras/escenario_S2.jpg>
Package pdftex.def Info: figuras/escenario_S2.jpg  used on input line 571.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 571.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 571.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [25 <./figuras/escenario_S1.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 571.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 571.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [26 <./figuras/escenario_S2.jpg>]
<figuras/escenario_S3.jpg, id=438, 1284.8pt x 722.7pt>
File: figuras/escenario_S3.jpg Graphic file (type jpg)
<use figuras/escenario_S3.jpg>
Package pdftex.def Info: figuras/escenario_S3.jpg  used on input line 572.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
<figuras/escenario_S4.jpg, id=439, 1284.8pt x 722.7pt>
File: figuras/escenario_S4.jpg Graphic file (type jpg)
<use figuras/escenario_S4.jpg>
Package pdftex.def Info: figuras/escenario_S4.jpg  used on input line 573.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 573.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 573.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [27

 <./figuras/escenario_S3.jpg>]
<figuras/escenario_S5.jpg, id=445, 1284.8pt x 722.7pt>
File: figuras/escenario_S5.jpg Graphic file (type jpg)
<use figuras/escenario_S5.jpg>
Package pdftex.def Info: figuras/escenario_S5.jpg  used on input line 574.
(pdftex.def)             Requested size: 472.03581pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 574.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 574.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [28 <./figuras/escenario_S4.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 574.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 574.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [29 <./figuras/escenario_S5.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 596.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 596.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [30

]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 624.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 624.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [31]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 630.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 630.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [32]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 646.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 646.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [33]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 669.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 669.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [34]
<figuras/exploracion_actual.jpg, id=496, 1284.8pt x 722.7pt>
File: figuras/exploracion_actual.jpg Graphic file (type jpg)
<use figuras/exploracion_actual.jpg>
Package pdftex.def Info: figuras/exploracion_actual.jpg  used on input line 681
.
(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 681.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 681.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [35]
<figuras/prediccion_actual.jpg, id=507, 1284.8pt x 722.7pt>
File: figuras/prediccion_actual.jpg Graphic file (type jpg)
<use figuras/prediccion_actual.jpg>
Package pdftex.def Info: figuras/prediccion_actual.jpg  used on input line 682.

(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 682.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 682.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

[36 <./figuras/exploracion_actual.jpg> <./figuras/prediccion_actual.jpg>]
<figuras/modelo_actual.jpg, id=514, 1284.8pt x 722.7pt>
File: figuras/modelo_actual.jpg Graphic file (type jpg)
<use figuras/modelo_actual.jpg>
Package pdftex.def Info: figuras/modelo_actual.jpg  used on input line 683.
(pdftex.def)             Requested size: 472.03113pt x 265.52013pt.
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 685.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 685.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.

[37

 <./figuras/modelo_actual.jpg>]
File: portada_img/der.png Graphic file (type png)
<use portada_img/der.png>
Package pdftex.def Info: portada_img/der.png  used on input line 686.
(pdftex.def)             Requested size: 36.0346pt x 42.67912pt.
File: portada_img/izq.png Graphic file (type png)
<use portada_img/izq.png>
Package pdftex.def Info: portada_img/izq.png  used on input line 686.
(pdftex.def)             Requested size: 36.13269pt x 42.67912pt.
 [38

] (./main.aux
LaTeX Info: Redefining \sptext on input line 9.
LaTeX Info: Redefining \. on input line 9.
LaTeX Info: Redefining \% on input line 9.
)
 ***********
LaTeX2e <2025-11-01>
L3 programming layer <2026-01-19>
 ***********
Package rerunfilecheck Info: File `main.out' has not changed.
(rerunfilecheck)             Checksum: E145AEEE38ED714DB9813847441FB869;8783.
Package logreq Info: Writing requests to 'main.run.xml'.
\openout1 = `main.run.xml'.

 ) 
Here is how much of TeX's memory you used:
 38095 strings out of 467525
 740768 string characters out of 5418982
 1781089 words of memory out of 5000000
 66307 multiletter control sequences out of 15000+600000
 634266 words of font info for 64 fonts, out of 8000000 for 9000
 1141 hyphenation exceptions out of 8191
 84i,16n,94p,1197b,2807s stack positions out of 10000i,1000n,20000p,200000b,200000s
</usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmbx10.pfb
></usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmbx12.pfb>
</usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmex10.pfb><
/usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmmi10.pfb></
usr/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmmi8.pfb></us
r/local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr10.pfb></usr/
local/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr12.pfb></usr/lo
cal/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr17.pfb></usr/loca
l/texlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmr8.pfb></usr/local/t
exlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmsy10.pfb></usr/local/te
xlive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmsy8.pfb></usr/local/texl
ive/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmti10.pfb></usr/local/texli
ve/2026/texmf-dist/fonts/type1/public/amsfonts/cm/cmtt10.pfb>
Output written on main.pdf (41 pages, 4491883 bytes).
PDF statistics:
 618 PDF objects out of 1000 (max. 8388607)
 498 compressed objects within 5 object streams
 137 named destinations out of 1000 (max. 500000)
 552 words of extra memory for PDF output out of 10000 (max. 10000000)


````

## Evidencia comercial y juegos como servicio · 12 de noviembre de 2026

Se incorporaron las secciones 4.1 y 4.2 sobre casos documentados y comparación de pérdidas por género. La primera toma el texto y las citas de `tablas/evidencia_comercial.csv`. La segunda define una cohorte comparable y una ventana de 24 meses para evaluar la recuperación de costos.

Se cotejaron los cuatro casos y sus seis fuentes con la web, se corrigió la redacción que podía confundir los datos de Backloggd con las publicaciones de las editoras y se revisó la compilación. El PDF final tiene 35 páginas. La tabla y la verificación del PDF forman parte del paquete LaTeX.

## Redacción y capturas para la entrega · 12 de noviembre de 2026

El informe conserva la plantilla del anteproyecto y explica las gráficas y la predicción con ejemplos. Los detalles de ejecución se conservan en la documentación técnica. Las capturas vigentes muestran Inicio, Exploración, los casos comerciales, Modelo y el formulario de Predicción.

Para el ejemplo del informe se comprobó con el modelo guardado que, con nota de prensa de 82 y calificación de usuarios de 3.9, la clase estimada es baja con 40.6 %. Al marcar la ausencia de la nota de prensa se mantiene la clase baja, con 42.2 %. Las 143 pruebas del proyecto pasaron y se revisó el PDF compilado.

## Revisión de la redacción y las fuentes

Se reescribieron las explicaciones con el orden de los trabajos de referencia: qué se hizo, qué se ve y qué indica el resultado. Se quitaron las citas dentro de los párrafos, incluidos los casos de juegos como servicio. Las fuentes quedan en Referencias. Se recompilaron y revisaron las 19 páginas del informe.

## Orden de la entrega y revisión del PDF

Se retiró el resumen del inicio y del índice, y se quitó la leyenda de versión de la portada. Se conservó la fecha de corte. El PDF compiló con 18 páginas. Se conservaron las 13 figuras incluidas en el informe y las evidencias de la entrega. Las imágenes de revisión de página completa se retiraron después de revisar la portada, el índice y la primera página del contenido. Los scripts reemplazados quedaron en el ZIP histórico.

## Calibracion y capturas de la web

El informe explica el ajuste de probabilidades y compara Brier y log-loss en los mismos 222 juegos de prueba. Se actualizaron cinco capturas de la web y se reprodujeron los ejemplos con y sin nota de prensa.

## Imagenes de videojuegos

Se actualizaron siete capturas de la web para mostrar las imagenes de videojuegos y el menu nuevo. El ZIP de LaTeX incluye los creditos de las imagenes.

## Capturas de tarjetas

Se agregaron las capturas de Juegos parecidos y la bitacora de algoritmos al informe. Se revisaron ambas figuras en el PDF y se actualizaron los creditos.

## Conclusion de Prediccion

Se agrego un ejemplo de la conclusion personalizada y se documento la consulta de portadas en Steam y la alternativa con organizaciones del catalogo.

`````

## MANIFIESTO.json

Ruta: `DocumentoFinal/MANIFIESTO.json` · Bytes: 7502 · SHA-256: `fef602d4c54535d93a534f899c131b3599c49fd150d869c4f2e8064fdba77d94`

````text
{
  "BITACORA_UNIFICADA.md": "cfdb13f6c88a39dc3b9281c3c838a2a9cdbe06ac63caa5c27831060907bff097",
  "Portada.tex": "bc48ac4ca28bfd257a1eaef0c3a235d9e1cd5c3f4b3819a8488b0e276d52e9d6",
  "README.md": "7c64b6a75db7737fac9021a1452b023d63b40169740f23d6d11b7e67787b23ee",
  "ajustar_formato_redaccion.py": "9aa13dff0df4e4a66e46fdca34343e10d93b037666b925b9ecfbf0e1241a1200",
  "analizar_escenarios.py": "3db3a7955e40c594f0586c7c934882dcf7f69cc3a08281e1330135642a406a86",
  "cifras_informe.tex": "973381de2d897dbe8f160f58b902841b0d769b21ec43f5cb171e89c189b12edb",
  "evidencias/BITACORA_UNIFICADA.md": "9e2c60880eb9761c3d68d33e0955be14856d39029ad99cc391db1f6ba85bc4f1",
  "evidencias/auditoria.json": "d8bf0c35c3457054fe0240546fec201bcb1a4718564501869c27a284b23e3d8a",
  "evidencias/clase_ward_cortes.csv": "81f5b1e7280fd69929d57122b3d8aa7c600b5345a01c51c9d8d54913e7fa4ab7",
  "evidencias/clase_ward_perfiles.csv": "47de46769cd8969ad459e83934f2b6460bfde556beee0f0dcd9b0ceef37b88b3",
  "evidencias/clustering.md": "722f376b0c0eae85fad24a35e799ffffe8cbc449558c34b5abecfaac48352b50",
  "evidencias/comparativo_herramientas.csv": "ad0cd5bcd5eaf2e9af4f5a4d68d62ca14b509c11b3c37fdbb0545566436ef9b1",
  "evidencias/creditos_imagenes_web.md": "92a6b49936f14d3e55bd2b20b8286f1a9915c4563d2c0321d8af6e28e44b05f3",
  "evidencias/decision.json": "cd3c19e80e1eef1cd9b55801e659edd5d653e8dc0450b2cf2ef08ed5dfcf9e38",
  "evidencias/escenarios/BITACORA_UNIFICADA.md": "b499805b116a5bb16a7d87810de44b6883fc2b46bf21c34240656ae401ab3af3",
  "evidencias/escenarios/contraejemplos.csv": "06367ca6046ea2e626ecf309f125f71aa9421b9d66b03c58d6900262f657dbdd",
  "evidencias/escenarios/contraejemplos.json": "931cecb65532e3a1823da15569d6890713b5e82b3d67dc8e3e80086429ef6403",
  "evidencias/escenarios/hipoteticos.csv": "d55fc932ca7140456083308af47746a1efb11005d6820791b2434927eff6d117",
  "evidencias/escenarios/hipoteticos.json": "7c22668556909dace3401d5314190e7c1c257d0a4e99a47c9a3dac96984225bd",
  "evidencias/escenarios/rejilla.csv": "2ce1fadc1cd4b7afdf169e9cdd2ab6813971c4fded353c3a05470277e3baa41f",
  "evidencias/inspeccion.md": "52ae5a3d981eb4808a1107714f45469794e804b3222ab3a0e0c18b2e27a12c2b",
  "evidencias/integridad_final.json": "90e1137d1c8fcc542b15d7f84670248c35134f5288086b6c057dc1ab4667a7b5",
  "evidencias/limpieza_log.md": "4bbe6551fdc5073800ce59ed9e227cf85a3b02f7de01df4217c0bcc1168c2482",
  "evidencias/metadata.json": "2d01aa7876413ef6e2f0e38f5940681a1cd7ade33c2da97efcf2f6f69e7884c8",
  "evidencias/modelo.md": "3bc1bb3ce18ec56df55ea7ce11b91705c7ff0907f2ba7e7a630e0e6a3ab9f2b7",
  "evidencias/modelo_confusion_RandomForestClassifier.csv": "6e8923011f35fbe970d2569dba66daf31d6b737b7f1923dcf0ab2433ea7ae6d1",
  "evidencias/rubrica_proyecto.pdf": "dd62ef24a2822d83205eb0352095519af4d94900e146df55d207b23b0c892dbc",
  "evidencias/trazabilidad_historica.md": "59ab6b572a61f5b3b2eba4dbde7a599a47e9f02cbc5c239e6daf1094fc2f2a9a",
  "evidencias/verificacion_weka_orange.md": "fcf1f3ddb3ee6c1cd87458da24a55e155e6144e438b72a3d9ed3fba66037cb89",
  "evidencias/weka_J48.txt": "88ceace97d84c7c67628688f9876a4d3de22c07935e6111dd954f3c401a88c8c",
  "evidencias/weka_NaiveBayes.txt": "5aac3e1f7f662eb504b71c7f77d1e31f2121a15ba7771c97b630a65bfd3027c6",
  "evidencias/weka_RandomForest.txt": "bed5274c54f92bc20ff70c7d64d600839b65e76ea4860e88d8e003dcd5bb47df",
  "evidencias/weka_ZeroR.txt": "abc7807ce09733680834ddcfcbf72f7a71f72e62ad1d519db547385bc4fe1cad",
  "evidencias/weka_dbscan.txt": "7d0866476ee480a90daee39e1469861c532b52da9dbef7bfb9c05eedcf11de94",
  "evidencias/weka_kmeans.txt": "b6be17cf0eaf134d171be3850e8e4c683ef631592cb3e142195ae0358191983a",
  "figuras/RandomForest.png": "75fd874d38afb1b00f10cf700ec2a5adede66120ac7d87f702d4d0c7a6367d8c",
  "figuras/clase_ward_dendrograma.png": "a98f0f2b12ec4a2d0a00937e1921cfe2469508de337fc6b35fce598156fac7ea",
  "figuras/clustering_03_kmeans.png": "de7fbe2d10efb23f90f682d5edc829bd7c511f6992f94d672e6f09170bab75b7",
  "figuras/pca_tres_metodos.png": "9ce21e8a1588cc6553a139d9535d92a5529dc54272267c1d558f7b942061abbf",
  "figuras/sensibilidad_escenarios.png": "20acc80a5d0e5f13cd8ac8c0ce505a599bd4d0c1ffd22703ef59ff6cb1cb7b2a",
  "figuras/web_actividad_nueva.jpg": "50c61a681ee4c428f2ea91ac2244385f7a02a7bcf51aad811ac5d8446201495c",
  "figuras/web_bitacora_algoritmos.jpg": "244cc978b09cc3ea315ffd3772fa4c3f2fd8d2e674c9998ddc85e10b399b904b",
  "figuras/web_calibracion.jpg": "23c28121ced76bdbe7a84a1d4c62481d68197e27ffd09da3501b09af3c803d9b",
  "figuras/web_comercial_nueva.jpg": "e9f4073d4ae058c39ab3c5ea5ad3fe4eeafb88ab0cc52edd03bf574fe637522e",
  "figuras/web_conclusion_prediccion.jpg": "787fdb6af7770e553b79b1235c05f6741c5fb9af08d41aaacdb2ba0681bbe55b",
  "figuras/web_exploracion_nueva.jpg": "24a87722319382c1efdd6cec0e10e14d58b7ac73cd0cb4172aca7873cd69aea0",
  "figuras/web_inicio_nueva.jpg": "2e6bf7b88502edfb45f3a4a233710e1b33448a2261f8013924954705f08306d9",
  "figuras/web_juegos_destacados.jpg": "57a72cee377ade7eb89728e61c5cd3ff82d16b88a16dd11f34ab6ba1cdf6a676",
  "figuras/web_juegos_parecidos.jpg": "6af1ee1855f82f6cfbe9e9cd4ecb44c18ede23dc63f7ec62792017a075c5ab63",
  "figuras/web_modelo_nueva.jpg": "81ee45a0fc05ab914e2ed68f62c84cfa70b3d2d57ca82b3c4d9a05ade10eaf10",
  "figuras/web_niveles_popularidad.jpg": "838ffe25a251406cf1d20c613f3c60233980799078bc17da325601bffb4a70e6",
  "figuras/web_prediccion_formulario.jpg": "0df9a02fcbf93215a8b55fa966f82aa4793ef4efa64775f1e1c7f39540c4a30a",
  "figuras/web_prediccion_resultado.jpg": "cd6072fd5e6ef8a75b944ebf1c550e14645e7582501bb7dfd39e7872c4cfb7ca",
  "figuras/web_prediccion_sin_nota.jpg": "77ec01b5dcb6f6d91b620948f31501bd47ea57ba7d0daba56dcbd8fe6029aad1",
  "informe.tex": "ddf337597c9e892c1fd9fa43376b49245e03aed9d5e1e58535b2aa1b91e8bc70",
  "main.pdf": "82961284abdf6cecdf6f2d6f8e52b0b0ac4b66cfa79a8df515a5abd7ab049a57",
  "main.tex": "3f19476bb2b20052c435742935062d64cf3063c9f10eebe5d94fb8444f484f0b",
  "portada_img/der.png": "99dbfff9fda6ba78364f314688169e8ea2260c59ec2398a77e5f130b6e43e983",
  "portada_img/izq.png": "dc30f458781af02df77bccdb4af094c6e2f3aa1d161ad54c8e37c6f7a04b8a95",
  "referencias.bib": "558785022341f97ac3ebc35f48c81fe1c883626fc9ae2de667f6491dead9a6ee",
  "revision/BITACORA_UNIFICADA.md": "5b2320305ae0c183e3370fca58cacf966aec3bdffe5a9b888428d48556ff6bc9",
  "revision/verificacion.json": "0aa3ae3bc5c151d458db93c820a39ce35a782bd7f64ad8527458e51692532e52",
  "tablas/busqueda_resumen.csv": "08f959d3c26813eff03a0c8643f43df75daf36b031a33f0c53ff302580177fec",
  "tablas/clase_comparacion_clustering.csv": "dde60cb80ed624af021692903140847d31c5802f0713e53237c557e5af303128",
  "tablas/clustering_03_correlaciones_generos.csv": "5869c0c310fe9e29da498effb41c0134dcb473c8d659db8004a7d7b7f5a1cdda",
  "tablas/clustering_03_correlaciones_organizaciones.csv": "86304ee58a3749c71dbfed9eded58fee43a3d7dd81232f33082909e42f53cd95",
  "tablas/clustering_03_correlaciones_ranking_generos.csv": "149d78bb3b84b1aeb32e3dbdb34cf0eef72ae8e2947d5333a3af132965ce5131",
  "tablas/clustering_03_correlaciones_senales.csv": "c56c343f3b8b0b6b7acaebc9c831f18cbeefd81726457fb88a4e7243507d8a7a",
  "tablas/clustering_03_ejemplos.csv": "da04a559e0664d3f002be8225a2d058577a92cd13572d029a67bace4e371e1bf",
  "tablas/evidencia_comercial.csv": "98401cccf085730db6a794219269f740b89d6621181ed18a348aa7ed2abc271c",
  "tablas/modelo_comparacion.csv": "b6246eed686acf999728840dbc1090bff2e6efe41845e4a6cfada6241c28c4d8",
  "tablas/modelo_importancia_gini.csv": "c62d7edb420d7105006553b0fd58672a6ab6afdf93b771856ccc9c0a47b40708"
}

````

## Portada.tex

Ruta: `DocumentoFinal/Portada.tex` · Bytes: 1429 · SHA-256: `bc48ac4ca28bfd257a1eaef0c3a235d9e1cd5c3f4b3819a8488b0e276d52e9d6`

````text
\thispagestyle{empty} % Sin encabezado ni pie en la portada

% --- ENCABEZADO DE PORTADA (TABLA DE 3 COLUMNAS) ---
\begin{center}
    % La tabla usa 'm' para centrar verticalmente las imagenes y el texto
    \begin{tabular}{m{0.15\textwidth} m{0.60\textwidth} m{0.15\textwidth}}
        % Logo Izquierdo (UNAM)
        \includegraphics[width=2cm]{portada_img/der.png} & 
        
        % Titulo Central
        \centering\LARGE\textbf{Universidad Nacional Autonoma de Mexico} &
        
        % Logo Derecho (Facultad)
        \raggedleft\includegraphics[width=2cm]{portada_img/izq.png}
    \end{tabular}
\end{center}

\vspace{0.3cm}

% --- INFORMACION DEL REPORTE ---
\begin{center}
    {\LARGE \textbf{Facultad de Ingenieria}}\\[0.45cm]

    {\LARGE \textbf{Alumno:}}\\[0.3cm]
    {\Large Lara Hernandez Angel Husiel - 320060829} \\[0.45cm]
    {\Large Lugo Manzano Rodrigo - 320206968} \\[0.45cm]
    {\Large Garcia Cortes Adolfo de Jesus - 320317264} \\[0.45cm]


    {\LARGE \textbf{Mineria de datos.}} \\[0.45cm]

	{\LARGE Grupo: 01 - Semestre: 2027-1} \\[0.45cm]
    
    {\LARGE \textbf{Proyecto final}}\\[0.5cm]

    {\LARGE {Analisis de recepcion y popularidad de videojuegos mediante mineria de datos}}\\[0.45cm]

    {\LARGE \textbf{Profesor:}}\\[0.2cm]
    {\Large MTRO. GERARDO GABRIEL CARRASCO ZUÑIGA}\\[0.45cm]

    {\Large \textbf{Fecha de corte:}}\\[0.2cm]
    {\Large 12 de noviembre de 2026}
\end{center}
````

## ProyectoMineriaDatos_LaTeX.zip

Ruta: `DocumentoFinal/ProyectoMineriaDatos_LaTeX.zip` · Bytes: 4717122 · SHA-256: `2e07552cd71364faa505005c0951d8874603e09966be6f043bfda2ddeaedf9a8`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## README.md

Ruta: `DocumentoFinal/README.md` · Bytes: 1378 · SHA-256: `7c64b6a75db7737fac9021a1452b023d63b40169740f23d6d11b7e67787b23ee`

````text
# Documento final

El [PDF](main.pdf) usa la plantilla del anteproyecto. Explica las gráficas, los resultados de Random Forest y Weka, y la configuración del formulario de predicción con capturas de la web vigente. La bibliografía usa biblatex con estilo APA.

Las secciones 4.1 y 4.2 incorporan evidencia publicada por las editoras y el diseño para evaluar pérdidas por género. El datasheet del apéndice A describe el catálogo y sus cambios. La [tabla de evidencia comercial](tablas/evidencia_comercial.csv) se incluye en el paquete LaTeX.

## Compilar

Desde esta carpeta, con LaTeX y biber instalados:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

## Regenerar desde el repositorio local

Desde la raíz, con el entorno Python de Final activo:

```bash
Final/.venv/bin/python DocumentoFinal/analizar_escenarios.py
python3 DocumentoFinal/ajustar_formato_redaccion.py
latexmk -pdf -interaction=nonstopmode -halt-on-error -cd DocumentoFinal/main.tex
python3 herramientas/empaquetar_documento.py
```

Las tablas se alimentan de `Final/reports/tables/` y `Final/models/metadata.json`. Los escenarios son hipotéticos y los contraejemplos proceden de la prueba histórica ya observada. El registro de Git acredita la primera evidencia disponible, con independencia de cuándo se terminó cada actividad. La aplicación se ejecuta localmente.

````

## ajustar_formato_redaccion.py

Ruta: `DocumentoFinal/ajustar_formato_redaccion.py` · Bytes: 9604 · SHA-256: `9aa13dff0df4e4a66e46fdca34343e10d93b037666b925b9ecfbf0e1241a1200`

````text
"""Actualiza las cifras y compone el informe con la plantilla del anteproyecto."""
import csv
import json
from pathlib import Path
import shutil
import unicodedata

DOCUMENTO = Path(__file__).resolve().parent
RAIZ = DOCUMENTO.parent
REPORTES = RAIZ / 'Final/reports'
TABLAS = REPORTES / 'tables'
MODELOS = {
    'DummyClassifier': 'Referencia mayoritaria',
    'CategoricalNB': 'Naive Bayes categórico',
    'DecisionTreeClassifier': 'Árbol de decisión',
    'RandomForestClassifier': 'Random Forest',
    'MLPClassifier': 'Red neuronal',
}


def leer(nombre):
    with (TABLAS / f'{nombre}.csv').open(encoding='utf-8', newline='') as archivo:
        return list(csv.DictReader(archivo))


def escapar(valor):
    especiales = {'&': r'\&', '%': r'\%', '_': r'\_', '#': r'\#', '$': r'\$',
                  '{': r'\{', '}': r'\}', '–': '--', '—': '---'}
    return ''.join(especiales.get(c, c) for c in str(valor))


def sin_acentos(texto):
    """Quita los acentos y conserva la ñ y la diéresis."""
    descompuesto = unicodedata.normalize('NFD', texto)
    return unicodedata.normalize('NFC', ''.join(
        c for c in descompuesto if c not in '\u0300\u0301\u0302\u030c'
    ))


def tabla(titulo, columnas, alineacion, filas):
    encabezado = ' & '.join(map(escapar, columnas)) + r'\\'
    return '\n'.join([
        r'\begin{table}[!htbp]', r'\centering\small', r'\caption{' + titulo + '}',
        r'\begin{tabular}{' + alineacion + '}', r'\toprule', encabezado, r'\midrule',
        *(' & '.join(map(escapar, fila)) + r'\\' for fila in filas),
        r'\bottomrule', r'\end{tabular}', r'\end{table}', r'\FloatBarrier',
    ])


def cifras():
    correlacion = leer('correlacion_catalogo')[0]
    procedencia = {fila['etapa']: fila for fila in leer('procedencia_datos')}
    h = procedencia['Antecedente enriquecido']
    d = procedencia['Maestro curado']
    p = leer('metricas_prueba')[0]
    metadata = json.loads((RAIZ / 'Final/models/metadata.json').read_text(encoding='utf-8'))
    calibracion = metadata['calibracion_web']
    m = leer('matriz_confusion')
    db = next(f for f in leer('metricas_clusters') if f['metodo'] == 'DBSCAN' and float(f['factor_eps']) == 1)
    test = next(f for f in leer('comparacion_estadistica')
                if f['prueba'].startswith('t corregida') and f['modelo_b'] == 'MLPClassifier')
    casos_comerciales = leer('evidencia_comercial')
    escenarios = {f['id']: f for f in leer('escenarios_prediccion')}
    casos = leer('contraejemplos_prediccion')
    errores = [f for f in casos if f['acierto'].lower() == 'false']
    generos = {'Adventure': 'Aventura', 'RPG': 'Rol', 'Shooter': 'Disparos', 'Platform': 'Plataformas'}
    asociaciones = []
    for nombre, cantidad in [('correlacion_generos', 4), ('correlacion_organizaciones', 3)]:
        grupos = [f for f in leer(nombre) if f['estado'] == 'incluido']
        for f in sorted(grupos, key=lambda f: int(f['n']), reverse=True)[:cantidad]:
            asociaciones.append((generos.get(f['grupo'], f['grupo']), f['n'],
                                  f"{float(f['pearson_r']):.3f}", f"{float(f['spearman_rho']):.3f}",
                                  f"{float(f['brecha_absoluta_media']):.2f}"))
    return {
        'Historico': f"{int(h['filas']):,}", 'Catalogo': f"{int(d['filas']):,}",
        'Descartes': int(h['filas']) - int(d['filas']), 'Elegibles': f"{int(correlacion['n_juegos']):,}",
        'Pares': correlacion['n'], 'PearsonGlobal': f"{float(correlacion['pearson_r']):.4f}",
        'SpearmanGlobal': f"{float(correlacion['spearman_rho']):.4f}",
        'JuegosPrueba': p['n'], 'ExactitudPrueba': f"{float(p['exactitud_pct']):.2f}" + r'\,\%',
        'FPrueba': f"{float(p['f1_macro']):.4f}", 'GruposDbscan': db['k'], 'RuidoDbscan': db['ruido'],
        'PComparacion': f"$p={float(test['p_valor']):.4f}$",
        'JuegosCalibracion': calibracion['n_ajuste'],
        'MetricasCalibracion': tabla('Calidad de las probabilidades en los juegos de prueba.',
            ['Medida', 'Antes del ajuste', 'Despues del ajuste'], 'lrr',
            [(nombre, f"{metadata['metricas'][clave]:.4f}", f"{calibracion['metricas_prueba'][clave]:.4f}")
             for nombre, clave in [('Brier multiclase', 'brier_multiclase'), ('Log-loss', 'log_loss')]]),
        'AsociacionGrupos': tabla('Relación y separación de notas en grupos con más pares.',
            ['Grupo', 'Pares', 'Pearson', 'Spearman', 'Brecha media absoluta'], 'lrrrr', asociaciones),
        'SilTitulo': tabla('Comparación de los cortes seleccionados.',
            ['Método', 'Grupos', 'Silueta', 'Calinski--Harabasz', 'Davies--Bouldin'], 'lrrrr',
            [(f['metodo'], f['k'], f"{float(f['silhouette']):.3f}",
              f"{float(f['calinski_harabasz']):.1f}", f"{float(f['davies_bouldin']):.3f}")
             for f in leer('clase_comparacion_clustering')]),
        'EscenariosNotas': tabla('Ejemplo con los mismos géneros, organización y década.',
            ['Prueba', 'Usuarios', 'Prensa', 'Nivel estimado'], 'lrrl',
            [(nombre, f['rating'], f['metacritic'] or 'Ausente', f['prediccion'].capitalize())
             for nombre, f in [('Con ambas notas', escenarios['S2']), ('Sin nota de prensa', escenarios['S5'])]]),
        'EjemplosError': tabla('Juegos de prueba en los que el modelo asignó otro nivel.',
            ['Juego', 'Nivel real', 'Nivel asignado'], r'p{.52\linewidth}ll',
            [(f['titulo'], f['real'].capitalize(), f['prediccion'].capitalize()) for f in errores]),
        'PlanTrabajo': tabla('Actividades planeadas y primera evidencia fechada de su realización.',
            ['Actividad', 'Periodo planeado', 'Evidencia fechada'], 'lll',
            [(f['actividad'], f['baseline'].replace('--', '–'), f['evidencia_git'])
             for f in leer('plan_baseline_git') if f['evidencia_git']]),
        'TotalMedio': sum(int(m[1][c]) for c in ('bajo', 'medio', 'alto')), 'AciertosMedio': m[1]['medio'],
        'ComparacionModelos': tabla('Resultados promedio de la comparación en Python.',
            ['Modelo', 'Exactitud (%)', 'F1 macro', 'Variación del F1'], 'lrrr',
            [(MODELOS[f['modelo']], f"{float(f['exactitud_pct_media']):.2f}", f"{float(f['f1_macro_media']):.4f}",
              f"{float(f['f1_macro_de']):.4f}") for f in leer('comparativo_modelos')]),
        'MatrizConfusion': tabla('Juegos por nivel real y nivel asignado en la prueba.',
            ['Nivel real', 'Asignado bajo', 'Asignado medio', 'Asignado alto'], 'lrrr',
            [(f['real'].capitalize(), f['bajo'], f['medio'], f['alto']) for f in m]),
        'ResultadosWeka': tabla('Resultados de clasificación en Weka.',
            ['Modelo', 'Exactitud (%)', 'F1 macro', 'F1 ponderado'], 'lrrr',
            [(f['modelo'], f"{float(f['exactitud_pct']):.2f}", f"{float(f['f1_macro']):.3f}",
              f"{float(f['f1_ponderado']):.3f}") for f in leer('comparativo_herramientas')
             if f['herramienta'].startswith('Weka') and f['exactitud_pct']]),
        'Perfiles': tabla('Promedios de los grupos de K-Means.',
            ['Grupo', 'Juegos', 'Partidas registradas', 'Juegos pendientes', 'Nota de usuarios'], 'lrrrr',
            [(f['cluster'], f['n'], f"{float(f['media_Plays']):,.0f}", f"{float(f['media_Backlogs']):,.0f}",
              f"{float(f['media_Rating']):.2f}") for f in leer('perfiles_clusters') if f['metodo'] == 'K-Means']),
        'ProcedenciaDatos': tabla('Tamaño del catálogo en cada etapa.', ['Etapa', 'Registros', 'Columnas'], 'lrr',
            [(nombre, f['filas'], f['columnas']) for nombre, f in
             [('Anteproyecto (tamaño declarado)', procedencia['Anteproyecto']), ('Versión con notas de prensa', h),
              ('Catálogo con el que trabajamos', d), ('Datos después de limpiar', procedencia['Depurado actual'])]]),
        'CasosComerciales': '\n\n'.join(
            r'\noindent\textbf{' + escapar(f['juego']) + '.} ' + escapar(f['evidencia'])
            for f in casos_comerciales),
        'FuentesComerciales': ','.join(f[campo] for f in casos_comerciales
                                     for campo in ('cita', 'cita_contexto') if f[campo]),
    }


def main():
    plantilla = (RAIZ / 'Proyecto/main.tex').read_text(encoding='utf-8')
    preambulo = plantilla.split(r'\begin{document}', 1)[0]
    preambulo += r'''
\usepackage{xurl}
\usepackage{caption}
\captionsetup[table]{skip=8pt}
\addto\captionsspanish{\renewcommand{\contentsname}{Indice}}
\setcounter{tocdepth}{1}
\newcommand{\captura}[3]{%
  \begin{figure}[!htbp]
  \centering
  \includegraphics[width=\linewidth,height=.40\textheight,keepaspectratio]{figuras/#1}
  \caption{#2}\label{#3}
  \end{figure}\FloatBarrier
}
'''
    portada = r'''\begin{document}
\hypersetup{pageanchor=false}
\begin{titlepage}\input{Portada.tex}\end{titlepage}
\newpage
{\makeatletter\let\ps@plain\ps@indice\makeatother
\pagestyle{indice}\thispagestyle{indice}\hypersetup{linkcolor=black}\tableofcontents\thispagestyle{indice}}
\newpage\setcounter{page}{1}\hypersetup{pageanchor=true}\singlespacing
'''
    datos = '\n'.join(rf'\newcommand{{\{clave}}}{{{valor}}}' for clave, valor in cifras().items())
    (DOCUMENTO / 'cifras_informe.tex').write_text(sin_acentos(datos) + '\n', encoding='utf-8')
    cuerpo = r'\input{cifras_informe.tex}' + '\n' + (DOCUMENTO / 'informe.tex').read_text(encoding='utf-8')
    (DOCUMENTO / 'main.tex').write_text(preambulo + portada + sin_acentos(cuerpo), encoding='utf-8')
    shutil.copyfile(TABLAS / 'evidencia_comercial.csv', DOCUMENTO / 'tablas/evidencia_comercial.csv')


if __name__ == '__main__':
    main()

````

## analizar_escenarios.py

Ruta: `DocumentoFinal/analizar_escenarios.py` · Bytes: 5398 · SHA-256: `3db3a7955e40c594f0586c7c934882dcf7f69cc3a08281e1330135642a406a86`

````text
"""Escenarios hipotéticos y contraejemplos de prueba sin reentrenar el modelo.

Ejecutar desde la raíz con Final/.venv/bin/python DocumentoFinal/analizar_escenarios.py.
"""
from pathlib import Path
import sys,json,os
D=Path(__file__).resolve().parent;F=D.parent/'Final';sys.path.insert(0,str(F))
import joblib,numpy as np,pandas as pd
cache=D/'revision/cache_matplotlib';cache.mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR']=str(cache)
os.environ['XDG_CACHE_HOME']=str(cache)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.inferencia import predecir_formulario
from src.features import lista_cruda
from src.objetivo import aplicar_referencia
from src.config import FEATURES
m=joblib.load(F/'models/modelo_popularidad.joblib');meta=json.loads((F/'models/metadata.json').read_text())
out=D/'evidencias/escenarios';out.mkdir(exist_ok=True)
casos=[('S1','Notas bajas',['Adventure','RPG'],['Otro'],2020,45,1.0),('S2','Notas altas',['Adventure','RPG'],['Otro'],2020,99,4.8),('S3','Usuarios altos y prensa baja',['Adventure','RPG'],['Otro'],2020,45,4.8),('S4','Usuarios bajos y prensa alta',['Adventure','RPG'],['Otro'],2020,99,1.0),('S5','Usuarios altos sin prensa',['Adventure','RPG'],['Otro'],2020,None,4.8),('S6','Cambio de organización',['Adventure','RPG'],['Nintendo'],2020,99,4.8),('S7','Cambio de década',['Adventure','RPG'],['Otro'],1980,99,4.8),('S8','Cambio de género',['Shooter'],['Otro'],2020,99,4.8)]
filas=[]
for id,nombre,gs,org,d,crit,rating in casos:
 f,c,p=predecir_formulario(m,gs,org,d,crit,rating)
 filas.append(dict(id=id,escenario=nombre,generos=gs,organizaciones=org,decada=d,metacritic=crit,rating=rating,prediccion=c,**{f'p_{k}':v for k,v in p.items()}))
(out/'hipoteticos.json').write_text(json.dumps(filas,ensure_ascii=False,indent=2));pd.DataFrame(filas).to_csv(out/'hipoteticos.csv',index=False)
rejilla=[]
for rating in [1,2,3,4,4.8]:
 for crit in [45,60,80,99,None]:
  _,c,p=predecir_formulario(m,['Adventure','RPG'],['Otro'],2020,crit,rating)
  rejilla.append(dict(rating=rating,metacritic=crit,prediccion=c,**p))
pd.DataFrame(rejilla).to_csv(out/'rejilla.csv',index=False)
fig,ax=plt.subplots(figsize=(8,5));z=np.array([r['alto'] for r in rejilla]).reshape(5,5)
im=ax.imshow(z,vmin=0,vmax=1,cmap='Blues');ax.set_xticks(range(5),['45','60','80','99','Sin nota']);ax.set_yticks(range(5),['1.0','2.0','3.0','4.0','4.8']);ax.set_xlabel('Metacritic Rating');ax.set_ylabel('Rating de usuarios');ax.set_title('Sensibilidad del modelo con los demás atributos fijos')
for i in range(5):
 for j in range(5):
  r=rejilla[i*5+j];ax.text(j,i,f"{r['prediccion']}\n{r['alto']:.2f}",ha='center',va='center',fontsize=9,color='white' if z[i,j]>.55 else 'black')
fig.colorbar(im,ax=ax,label='Probabilidad no calibrada de alto');fig.tight_layout();fig.savefig(D/'figuras/sensibilidad_escenarios.png',dpi=180);plt.close(fig)
datos=pd.read_csv(F/'data/clean/juegos_modelo.csv');test=datos.loc[datos.particion.eq('prueba')].copy()
for c in ['generos','estudio']:test[c]=test[c].map(lista_cruda)
p=m.predict_proba(test[FEATURES]);test['prediccion']=m.predict(test[FEATURES]);test['probabilidad_maxima']=p.max(axis=1)
assert np.array_equal(aplicar_referencia(test,meta['definicion_objetivo']).nivel_popularidad,test.nivel_popularidad)
# La selección usa resultados de prueba ya observados; es ilustración posterior, no validación nueva.
seleccion=[]
for clase in ['bajo','medio','alto']:
 for acierto in [False,True]:
  sub=test.loc[test.nivel_popularidad.eq(clase)&test.prediccion.eq(test.nivel_popularidad).eq(acierto)].sort_values('probabilidad_maxima',ascending=False)
  f=sub.iloc[0];idx=test.index.get_loc(f.name)
  seleccion.append(dict(id_juego=int(f.id_juego),titulo=f.Title,real=clase,prediccion=f.prediccion,acierto=acierto,probabilidad_maxima=float(f.probabilidad_maxima),Plays=float(f.Plays),Wishlist=float(f.Wishlist),Backlogs=float(f.Backlogs),indice=float(f.popularidad_indice),generos=f.generos,estudio=f.estudio,decada=None if pd.isna(f.decada) else int(f.decada),Rating=None if pd.isna(f.Rating) else float(f.Rating),Metacritic=None if pd.isna(f['Metacritic Rating']) else float(f['Metacritic Rating']),probabilidades=dict(zip(m.classes_,map(float,p[idx])))))
(out/'contraejemplos.json').write_text(json.dumps(seleccion,ensure_ascii=False,indent=2));pd.DataFrame(seleccion).to_csv(out/'contraejemplos.csv',index=False)
print(pd.DataFrame(filas)[['id','prediccion','p_alto','p_medio','p_bajo']].to_string(index=False))
print(pd.DataFrame(seleccion)[['titulo','real','prediccion','acierto','probabilidad_maxima']].to_string(index=False))

tablas = F / 'reports/tables'
pd.DataFrame(filas).to_csv(tablas / 'escenarios_prediccion.csv', index=False)
pd.DataFrame(seleccion).to_csv(tablas / 'contraejemplos_prediccion.csv', index=False)
calibracion = pd.read_csv(tablas / 'calibracion.csv')
fig, ax = plt.subplots(figsize=(6, 4), layout='constrained')
ax.plot([0, 1], [0, 1], color='#50545e', linestyle=':', label='Referencia ideal')
for (clase, grupo), color in zip(calibracion.groupby('clase'), ['#116e78', '#563b8a', '#a54a2a']):
    ax.plot(grupo.probabilidad_media, grupo.fraccion_observada, 'o-', label=clase.title(), color=color)
ax.set(xlabel='Probabilidad media estimada', ylabel='Fracción observada',
       xlim=(0, 1), ylim=(0, 1))
ax.legend()
fig.savefig(D / 'figuras/fiabilidad_rf.png', dpi=180)
plt.close(fig)

````

## cifras_informe.tex

Ruta: `DocumentoFinal/cifras_informe.tex` · Bytes: 6239 · SHA-256: `973381de2d897dbe8f160f58b902841b0d769b21ec43f5cb171e89c189b12edb`

````text
\newcommand{\Historico}{1,512}
\newcommand{\Catalogo}{1,117}
\newcommand{\Descartes}{395}
\newcommand{\Elegibles}{1,114}
\newcommand{\Pares}{887}
\newcommand{\PearsonGlobal}{0.5439}
\newcommand{\SpearmanGlobal}{0.5242}
\newcommand{\JuegosPrueba}{222}
\newcommand{\ExactitudPrueba}{56.76\,\%}
\newcommand{\FPrueba}{0.5577}
\newcommand{\GruposDbscan}{1}
\newcommand{\RuidoDbscan}{21}
\newcommand{\PComparacion}{$p=0.7597$}
\newcommand{\JuegosCalibracion}{892}
\newcommand{\MetricasCalibracion}{\begin{table}[!htbp]
\centering\small
\caption{Calidad de las probabilidades en los juegos de prueba.}
\begin{tabular}{lrr}
\toprule
Medida & Antes del ajuste & Despues del ajuste\\
\midrule
Brier multiclase & 0.5570 & 0.5508\\
Log-loss & 0.9274 & 0.9102\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\AsociacionGrupos}{\begin{table}[!htbp]
\centering\small
\caption{Relacion y separacion de notas en grupos con mas pares.}
\begin{tabular}{lrrrr}
\toprule
Grupo & Pares & Pearson & Spearman & Brecha media absoluta\\
\midrule
Aventura & 598 & 0.575 & 0.544 & 10.11\\
Rol & 286 & 0.501 & 0.517 & 9.35\\
Disparos & 223 & 0.560 & 0.529 & 12.82\\
Plataformas & 188 & 0.643 & 0.553 & 10.55\\
Nintendo & 125 & 0.441 & 0.461 & 9.74\\
Capcom & 51 & 0.672 & 0.541 & 9.18\\
Square Enix & 49 & 0.598 & 0.598 & 7.39\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\SilTitulo}{\begin{table}[!htbp]
\centering\small
\caption{Comparacion de los cortes seleccionados.}
\begin{tabular}{lrrrr}
\toprule
Metodo & Grupos & Silueta & Calinski--Harabasz & Davies--Bouldin\\
\midrule
K-Means & 2 & 0.319 & 542.9 & 1.182\\
Ward & 2 & 0.281 & 409.7 & 1.330\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\EscenariosNotas}{\begin{table}[!htbp]
\centering\small
\caption{Ejemplo con los mismos generos, organizacion y decada.}
\begin{tabular}{lrrl}
\toprule
Prueba & Usuarios & Prensa & Nivel estimado\\
\midrule
Con ambas notas & 4.8 & 99.0 & Alto\\
Sin nota de prensa & 4.8 & Ausente & Bajo\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\EjemplosError}{\begin{table}[!htbp]
\centering\small
\caption{Juegos de prueba en los que el modelo asigno otro nivel.}
\begin{tabular}{p{.52\linewidth}ll}
\toprule
Juego & Nivel real & Nivel asignado\\
\midrule
Resident Evil 4: Wii Edition & Bajo & Alto\\
Uncharted: The Nathan Drake Collection & Medio & Alto\\
Jet Set Radio & Alto & Bajo\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\PlanTrabajo}{\begin{table}[!htbp]
\centering\small
\caption{Actividades planeadas y primera evidencia fechada de su realizacion.}
\begin{tabular}{lll}
\toprule
Actividad & Periodo planeado & Evidencia fechada\\
\midrule
Anteproyecto y revision & 1--5 oct. & 2026-10-07\\
Preparacion y limpieza & 6--15 oct. & 2026-11-08\\
EDA y correlaciones & 15--29 oct. & 2026-11-08\\
Clustering & 29 oct.--10 nov. & 2026-11-08\\
Clasificacion & 5--11 nov. & 2026-11-08\\
Weka & Durante modelado & 2026-11-08\\
Web & 8--16 nov. & 2026-11-08\\
Documento y revision & 10--24 nov. & 2026-11-09\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\TotalMedio}{80}
\newcommand{\AciertosMedio}{27}
\newcommand{\ComparacionModelos}{\begin{table}[!htbp]
\centering\small
\caption{Resultados promedio de la comparacion en Python.}
\begin{tabular}{lrrr}
\toprule
Modelo & Exactitud (\%) & F1 macro & Variacion del F1\\
\midrule
Referencia mayoritaria & 33.30 & 0.1665 & 0.0043\\
Naive Bayes categorico & 54.24 & 0.5308 & 0.0540\\
Arbol de decision & 50.00 & 0.4904 & 0.0471\\
Random Forest & 55.83 & 0.5495 & 0.0474\\
Red neuronal & 55.80 & 0.5538 & 0.0561\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\MatrizConfusion}{\begin{table}[!htbp]
\centering\small
\caption{Juegos por nivel real y nivel asignado en la prueba.}
\begin{tabular}{lrrr}
\toprule
Nivel real & Asignado bajo & Asignado medio & Asignado alto\\
\midrule
Bajo & 43 & 14 & 10\\
Medio & 32 & 27 & 21\\
Alto & 9 & 10 & 56\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\ResultadosWeka}{\begin{table}[!htbp]
\centering\small
\caption{Resultados de clasificacion en Weka.}
\begin{tabular}{lrrr}
\toprule
Modelo & Exactitud (\%) & F1 macro & F1 ponderado\\
\midrule
ZeroR & 33.07 & 0.253 & 0.253\\
NaiveBayes & 50.90 & 0.503 & 0.503\\
J48 & 51.01 & 0.506 & 0.506\\
RandomForest & 53.48 & 0.530 & 0.530\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\Perfiles}{\begin{table}[!htbp]
\centering\small
\caption{Promedios de los grupos de K-Means.}
\begin{tabular}{lrrrr}
\toprule
Grupo & Juegos & Partidas registradas & Juegos pendientes & Nota de usuarios\\
\midrule
0 & 465 & 7,681 & 2,022 & 3.91\\
1 & 422 & 2,981 & 476 & 3.38\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\ProcedenciaDatos}{\begin{table}[!htbp]
\centering\small
\caption{Tamaño del catalogo en cada etapa.}
\begin{tabular}{lrr}
\toprule
Etapa & Registros & Columnas\\
\midrule
Anteproyecto (tamaño declarado) & 1512 & 15\\
Version con notas de prensa & 1512 & 20\\
Catalogo con el que trabajamos & 1117 & 42\\
Datos despues de limpiar & 1117 & 38\\
\bottomrule
\end{tabular}
\end{table}
\FloatBarrier}
\newcommand{\CasosComerciales}{\noindent\textbf{Concord.} PlayStation anuncio la retirada del juego y el reembolso de compras de PS5 y PC. Despues confirmo el cierre definitivo de Concord y el cierre de Firewalk Studios.

\noindent\textbf{XDefiant.} Ubisoft anuncio el fin del desarrollo, comunico que mantendria los servidores activos hasta el 3 de junio de 2025 y anuncio el cierre de dos estudios de produccion. Señalo dificultades para retener a suficientes jugadores.

\noindent\textbf{Helldivers 2.} Sony clasifico el juego como servicio y reporto 12 millones de unidades vendidas en conjunto en PS5 y PC al 5 de mayo de 2024. La cifra es una estimacion de Sony del volumen vendido al consumidor.

\noindent\textbf{Forspoken.} Square Enix califico de debiles las ventas del juego en su presentacion de resultados. La observacion describe el desempeño reportado por la editora.}
\newcommand{\FuentesComerciales}{hulst2024firewalk,ellis2024concord,ubisoft2024xdefiant,sony2024suplemento,sony2024resultados,squareenix2023forspoken}

````

## informe.tex

Ruta: `DocumentoFinal/informe.tex` · Bytes: 20415 · SHA-256: `ddf337597c9e892c1fd9fa43376b49245e03aed9d5e1e58535b2aa1b91e8bc70`

````text
\section{Objetivos del proyecto}
\begin{itemize}
\item Revisar como se relacionan las notas de usuarios y prensa en el catalogo, por genero y por organizacion.
\item Comparar la actividad acumulada, la actividad actual, los juegos pendientes y las listas de deseos para entender que muestra cada indicador.
\item Buscar grupos de juegos con actividad, interes y recepcion parecidos.
\item Estimar el nivel de popularidad de un juego a partir de su genero, organizacion, decada y calificaciones, y revisar en que casos se equivoca el modelo.
\item Mostrar los resultados en una aplicacion donde se puedan filtrar los juegos y probar los parametros de una prediccion.
\end{itemize}

\section{Datos del proyecto}
\subsection{De donde salen los datos}
Primero usamos como base un catalogo de Backloggd que Arnab Chaki publico en Kaggle. Antes de hacer el analisis ya se habian agregado las notas de Metacritic. Esa version tenia \Historico\ registros y, despues de revisar titulos y fechas repetidos, quedaron \Catalogo. En el datasheet, en el apartado~\ref{sec:datos-cambios}, se ve cuantos registros habia en cada paso. Si dos juegos tienen el mismo nombre, tambien revisamos la fecha para distinguirlos.

\subsection{Que significan las columnas}
\begin{description}
\item[Partidas registradas.] Es el conteo acumulado de registros de personas que marcaron el juego como jugado en Backloggd. Una persona puede haberlo marcado aunque ya no lo este jugando.
\item[Jugando actualmente.] Es cuantas personas lo tenian marcado como juego en curso al momento de recopilar los datos.
\item[Juegos pendientes.] Es cuantas personas lo agregaron a su lista para jugarlo mas adelante.
\item[Lista de deseos.] Es cuantas personas lo agregaron a la lista de titulos que les interesan.
\item[Calificacion de usuarios y nota de prensa.] La primera va de 0 a 5 y la segunda de 0 a 100. Cuando comparamos las dos notas, primero las ponemos en la misma escala.
\item[Generos, organizacion y fecha.] Un juego puede tener mas de un genero. El campo de organizaciones puede incluir a estudios y editoras. De la fecha se obtiene la decada de lanzamiento.
\end{description}

\section{Como se hizo el analisis}
Para ordenar el trabajo seguimos CRISP-DM. Primero vimos que queriamos averiguar y que datos teniamos para hacerlo. Despues limpiamos el catalogo, hicimos las graficas y probamos los grupos y las predicciones. Al final pusimos los resultados en Streamlit para poder revisar que pasa al cambiar los datos del formulario.

\subsection{Preparacion de los datos}
Lo primero que revisamos fue como venian los conteos. Si un dato viene como 1.2 mil, hay que leerlo como 1,200. En este caso los conteos ya venian como numeros. Tambien revisamos las fechas y dejamos sin decada los juegos cuya fecha no se pudo leer. Un mismo juego puede ser de aventura y de rol, asi que lo contamos en ambos cuando comparamos generos.

Para comparar las notas usamos los juegos que tenian las dos. Algunas cifras que venian en la columna de prensa se habian estimado, asi que las dejamos fuera de esa comparacion. Ahora bien, si queremos probar un juego en la web y no tenemos su nota de prensa, podemos marcar esa opcion. Lo que hace el modelo en ese caso es usar la mediana, que es la nota que queda en medio al ordenar las notas de entrenamiento.

\section{Problematica a atender}
Una nota alta nos dice que a quienes calificaron el juego les gusto. Ahora bien, para saber que tanto se jugo o si la gente tiene ganas de jugarlo tenemos que ver los otros conteos. En los juegos como servicio hay otra pregunta. Si se sigue gastando en mantener el juego despues del lanzamiento, ¿cuanto de lo que se gasto se llega a recuperar?

\subsection{Que encontramos en los casos publicados}
\CasosComerciales

En estos casos cada empresa dio un dato distinto. En uno sabemos que se cerro el juego y se devolvio el dinero. En otro sabemos cuantas copias se vendieron en cierto tiempo. Para decir que genero tuvo mas juegos con perdidas tendriamos que conocer cuanto ingreso y cuanto costo cada juego, incluyendo los que recuperaron su dinero y los que quedaron por debajo.

\subsection{Como se podria comparar el riesgo por genero}
Para hacer esa comparacion primero escogeriamos juegos que salieron en fechas parecidas. Despues sumariamos los gastos de desarrollo, publicidad y operacion, y revisariamos si cada juego los recupero en sus primeros 24 meses. Tambien separariamos los juegos como servicio y tomariamos en cuenta el presupuesto, la plataforma, el tamaño del estudio y si el juego ya venia de una franquicia. Si queremos saber si una prediccion ayuda a evitar perdidas, habria que comparar que paso con proyectos donde si se uso el modelo y proyectos que siguieron el proceso habitual.

\section{Que vimos en las graficas}
\subsection{Actividad e interes por genero}
En la figura~\ref{fig:actividad} lo que vemos es una fila por genero. La linea de cada caja nos dice que conteo quedo a la mitad y la caja nos muestra donde se concentra la mitad central de los juegos. Los puntos que quedan aparte son juegos con conteos alejados del resto. Si dos generos tienen la linea casi en el mismo lugar, podemos ver cual tiene los juegos mas dispersos fijandonos en cual caja es mas larga.

Ahora bien, si vemos los numeros de abajo, de 100 a 1,000 hay el mismo espacio que de 1,000 a 10,000. Esto pasa porque cada salto multiplica por diez. Usamos esa escala para que en la misma grafica alcancen a verse los juegos que tienen pocos registros y los que tienen muchos.

\captura{web_actividad_nueva.jpg}{Distribucion de actividad por genero en la pestaña Señales de actividad.}{fig:actividad}

\subsection{Como se comparan usuarios y prensa}
Primero pasamos la nota de usuarios a la escala de 100. Por ejemplo, 4 de 5 se vuelve 80. Si para el mismo juego la prensa puso 90, al restar quedan $-10$ puntos. El signo menos nos dice que la prensa le dio mas y el 10 nos dice por cuanto.

De los juegos que tenian las dos notas usamos \Pares. Pearson nos dio \PearsonGlobal\ y Spearman \SpearmanGlobal. Lo que nos dicen esos numeros es que las notas suelen moverse en el mismo sentido. Pearson usa los valores de las notas y Spearman se fija en el lugar que ocupa cada juego al ordenarlas. Para hacer el calculo por genero u organizacion usamos grupos con al menos 20 juegos con las dos notas.

\AsociacionGrupos

En la tabla podemos ver el caso de Disparos. La relacion sale positiva y, al mismo tiempo, hay casi 13 puntos de diferencia entre notas en promedio. Pensemos en dos listas donde los primeros juegos son los mismos, pero una lista tiene calificaciones mas altas. Los juegos quedan en lugares parecidos aunque las notas no sean iguales.

\subsection{Como escogimos la cantidad de grupos}
Para hacer los grupos usamos cuatro conteos y las dos notas. Como los conteos pueden venir en miles y una de las notas llega a 5, primero ajustamos los conteos grandes y despues pusimos las seis medidas en una escala que se pudiera comparar. De esa forma, el conteo no domina el grupo solo porque su numero es mas grande.

La grafica de la izquierda de la figura~\ref{fig:kmeans} nos muestra que tan cerca quedan los juegos del centro de su grupo. En la de la derecha, el punto mas alto queda en dos grupos. A ese valor le llamamos silueta y nos ayuda a ver que tan bien se separan los grupos. Para Ward tambien quedaron dos. Si vemos el arbol de la figura~\ref{fig:ward}, las ramas que se juntan abajo corresponden a grupos mas parecidos. Las que se unen arriba estaban mas separadas.

\captura{clustering_03_kmeans.png}{Comparacion de cortes para K-Means. A la derecha se muestra la separacion entre grupos.}{fig:kmeans}
\captura{clase_ward_dendrograma.png}{Arbol de Ward. Los numeros entre parentesis indican cuantos juegos resume cada rama.}{fig:ward}

\SilTitulo

En la tabla buscamos valores altos en Silueta y Calinski--Harabasz y un valor bajo en Davies--Bouldin. En este caso, al usar los mismos juegos, K-Means quedo mejor en las tres medidas.

\Perfiles
Lo que se ve al comparar los promedios es que un grupo reune juegos con mas actividad, mas pendientes y notas mas altas. En el otro grupo esos numeros son menores. Como estamos viendo promedios, puede haber juegos individuales que se salgan de ese patron.

Con DBSCAN revisamos donde se juntaban muchos puntos. Nos dio \GruposDbscan\ grupo y dejo \RuidoDbscan\ juegos aparte porque tenian pocos vecinos cercanos. En la figura~\ref{fig:pca}, cada punto es un juego y el color nos dice en que grupo quedo. Los dos ejes resumen las seis medidas. Si vemos el panel de DBSCAN, aparece un conjunto grande y unos cuantos puntos separados.

\captura{pca_tres_metodos.png}{Mapa de juegos con los grupos de K-Means, Ward y DBSCAN.}{fig:pca}

\section{El modelo de popularidad}
\subsection{Que aprende el modelo}
Primero ordenamos los juegos tres veces. Una por partidas registradas, otra por deseos y otra por pendientes. De los tres lugares que tuvo cada juego sacamos un promedio. Despues separamos los juegos en tres partes de tamaño parecido. De ahi salen los niveles bajo, medio y alto. Cuando le pedimos al modelo que estime uno de esos niveles, le damos el genero, la organizacion, la decada y las dos notas. Los tres conteos sirven para saber cual era el nivel del juego y comprobar si le atino.

Apartamos \JuegosPrueba\ juegos para la prueba final. Con los demas hicimos diez bloques. Entrenamos con nueve y revisamos el que quedo fuera, hasta pasar por todos. Volvimos a formar los bloques cinco veces. La configuracion se escogio con los datos usados para entrenar en cada vuelta y mantuvimos juntos los registros con el mismo titulo.

\subsection{Como se eligio el modelo para la web}
\ComparacionModelos

La exactitud nos dice cuantos juegos quedaron en el nivel correcto. El F1 macro le da el mismo peso a cada nivel, asi que tambien toma en cuenta como salio el que mas le cuesta al modelo. Si vemos los promedios, la red neuronal quedo un poco arriba. La prueba que compara esa diferencia dio \PComparacion. Con ese resultado todavia no podemos decir cual rinde mejor. Para la web dejamos Random Forest porque sus resultados cambiaron menos entre vueltas y podemos revisar que datos uso mas.

\subsection{Que paso en la prueba}
\MatrizConfusion

En la diagonal estan los aciertos. En la fila de nivel medio vemos que acerto \AciertosMedio\ de \TotalMedio. Si seguimos leyendo esa fila, vemos cuantos quedaron como bajos y cuantos como altos. El resultado de toda la prueba fue \ExactitudPrueba\ de exactitud y \FPrueba\ de F1 macro. Como ya habiamos probado la red neuronal con esos mismos juegos, para saber como saldria con lanzamientos nuevos tendriamos que probar con otro grupo.

Para ver un error concreto, en la tabla de abajo aparece Resident Evil 4: Wii Edition. Segun los conteos del catalogo quedo en el nivel bajo y el modelo lo puso en alto. Lo podemos comparar con los otros ejemplos para ver en que niveles se equivoco, usando como referencia las partidas registradas, los pendientes y los deseos.

\EjemplosError

\subsection{Como ajustamos las probabilidades}
Si a varios juegos les damos cerca de 70\,\% de probabilidad de quedar en alto, esperamos que alrededor de siete de cada diez terminen en ese nivel. Para acercar los porcentajes a lo que observamos usamos un ajuste llamado escalado de temperatura. Lo calculamos con \JuegosCalibracion\ juegos de entrenamiento. Para obtener el porcentaje de cada juego usamos un bosque que se entreno dejando fuera su bloque. Despues comparamos los porcentajes con y sin el ajuste en los \JuegosPrueba\ juegos apartados para la prueba.

\MetricasCalibracion

Las dos medidas bajaron en esta prueba. Brier compara las tres probabilidades con el nivel que realmente obtuvo cada juego. Log-loss aumenta sobre todo cuando el modelo asigna una probabilidad muy baja al nivel que si ocurrio. El ajuste cambia los porcentajes y mantiene el nivel con la barra mas larga.

En la pagina Modelo podemos elegir alto, medio o bajo. En la figura~\ref{fig:fiabilidad} elegimos alto. Cada punto agrupa juegos a los que el bosque les dio porcentajes parecidos. Abajo leemos la probabilidad media y a la izquierda vemos que parte de esos juegos quedo en alto. Si el punto cae sobre la diagonal, los dos porcentajes coinciden. La linea morada muestra los valores originales y la azul los ajustados.

\captura{web_calibracion.jpg}{Probabilidades antes y despues del ajuste para el nivel alto en la pagina Modelo.}{fig:fiabilidad}

\section{Comparacion con Weka}
Tambien hicimos la comparacion en Weka. Lo que vemos en la parte de arriba de la figura~\ref{fig:weka} es cuantos juegos acerto el bosque. Abajo se ve cuales confundio con otro nivel. En Weka salio con la exactitud mas alta de los cuatro modelos. En ese caso la prueba se hizo por diez bloques. En la web mostramos el porcentaje obtenido con los juegos que se dejaron aparte para la prueba final.

\ResultadosWeka
\captura{RandomForest.png}{Resultado del bosque en Weka, con exactitud y matriz de aciertos y errores.}{fig:weka}

\section{Como usamos la aplicacion}
Primero abrimos Inicio. Desde ahi podemos pasar a Exploracion para cambiar el genero, la decada o el rango de notas y ver como cambia la consulta. En la parte de arriba estan las pestañas de actividad, notas, grupos y casos comerciales. Si queremos ver los aciertos y errores de la prueba entramos a Modelo.

\captura{web_inicio_nueva.jpg}{Inicio del observatorio con arte de Halo Infinite y Link en el menu lateral.}{fig:inicio}
\captura{web_juegos_destacados.jpg}{Tarjetas de Inicio con imagenes de Zelda, God of War y Super Mario Odyssey.}{fig:juegos-destacados}
\captura{web_exploracion_nueva.jpg}{Filtros y pestañas del tablero de exploracion.}{fig:exploracion}
\captura{web_comercial_nueva.jpg}{Caso comercial en la pestaña de juegos como servicio.}{fig:comercial}
\captura{web_modelo_nueva.jpg}{Ficha de Random Forest en la pagina Modelo.}{fig:modelo}
\captura{web_bitacora_algoritmos.jpg}{Bitacora con los cinco algoritmos y el detalle de la red neuronal seleccionada.}{fig:bitacora-algoritmos}

\subsection{Como se configuran los parametros de prediccion}
Para hacer la prueba entramos a Prediccion. En la figura~\ref{fig:formulario} se ve el formulario. Para repetir lo que aparece en la captura, dejamos los valores asi.

\begin{enumerate}
\item Elegimos uno o varios generos. En este caso dejamos Aventura y Rol, que aparecen como \emph{Adventure} y \emph{RPG} en el menu.
\item En organizacion dejamos «Otro / Organizacion no frecuente». Esta opcion sirve cuando la organizacion no aparece entre las opciones del modelo.
\item Seleccionamos la decada de 2020. La decada se refiere al lanzamiento que queremos representar.
\item Dejamos 82 de 100 en la nota de prensa y 3.9 de 5 en la calificacion de usuarios. Si no conocemos la de prensa, podemos marcar la casilla que simula su ausencia.
\item Presionamos «Analizar lanzamiento» y revisamos el nivel, las tres barras y los juegos similares.
\end{enumerate}

\captura{web_prediccion_formulario.jpg}{Formulario de Prediccion con el fondo de Spider-Man 2 y los valores del ejemplo.}{fig:formulario}

\subsection{Como se lee el resultado}
Con estos valores la web nos regreso el nivel bajo. En la figura~\ref{fig:prediccion}, la barra de bajo quedo en 44.9\,\%, la de medio en 27.8\,\% y la de alto en 27.4\,\%. Bajo es el nivel que el bosque estima como mas probable para este ejemplo.

Si abrimos el menu debajo de las barras, podemos ver los dos cortes del indice y donde empieza cada nivel, como en la figura~\ref{fig:niveles}. Los cortes se calcularon con los juegos de entrenamiento. El indice resume partidas registradas, pendientes y listas de deseos. Los porcentajes de las barras indican que tan probable estima el bosque que el juego caiga en cada rango de ese indice.

\captura{web_prediccion_resultado.jpg}{Probabilidades calibradas con nota de prensa de 82.}{fig:prediccion}
\captura{web_niveles_popularidad.jpg}{Menu desplegado con la definicion y los cortes de los tres niveles.}{fig:niveles}

Debajo del resultado podemos revisar los cinco juegos que mas se parecen a los datos del formulario. En la figura~\ref{fig:juegos-parecidos} cada juego aparece con su portada, su año y la distancia calculada. Una distancia menor indica que el juego se parece mas al ejemplo que ingresamos.

\captura{web_juegos_parecidos.jpg}{Juegos parecidos para el ejemplo de Aventura y Rol con nota de prensa de 82.}{fig:juegos-parecidos}

Cuando falta una portada local, la web busca el titulo y el año en la tienda de Steam. Si no encuentra una ficha que coincida, muestra la organizacion que figura en el catalogo.

\subsubsection*{Conclusion de la consulta}
Cada consulta explica cual de los tres niveles quedo primero y por cuantos puntos porcentuales. Tambien muestra las notas que se usaron. Si quitamos la nota de prensa, indica con que valor se completo. En la figura~\ref{fig:conclusion-prediccion} dejamos Aventura y Rol, y cambiamos las notas a 5 de 5 y 100 de 100. El nivel alto obtuvo 65.4\,\% y el nivel medio quedo segundo con 19.7\,\%.

\captura{web_conclusion_prediccion.jpg}{Conclusion que genero la web con las notas de usuarios y prensa al maximo.}{fig:conclusion-prediccion}

\subsubsection*{Prueba sin nota de prensa}
Dejamos todo igual y marcamos la casilla para quitar la nota de Metacritic. Al volver a presionar el boton, la figura~\ref{fig:sinnnota} muestra que el nivel se mantuvo en bajo y que la barra subio a 47.5\,\%. En ese caso se completo la nota con el valor de en medio de las notas de entrenamiento. Mas abajo se muestran cinco juegos del entrenamiento con caracteristicas parecidas a las que elegimos.

\captura{web_prediccion_sin_nota.jpg}{Probabilidades calibradas al simular que falta la nota de prensa.}{fig:sinnnota}

Despues hicimos otra prueba con 4.8 de usuarios y 99 de prensa. Dejamos los generos, la organizacion y la decada como estaban. Con las dos notas salio alto y al quitar la de prensa salio bajo. La tabla de abajo deja los valores para repetir esa prueba.

\EscenariosNotas

\section{Conclusiones}
Despues de revisar los resultados vimos que una sola nota deja fuera parte de lo que pasa con un juego. Hay casos donde la gente lo tiene en deseos o en pendientes y todavia no lo marca como jugado. Tambien hay juegos donde la prensa dio mas puntos que los usuarios. Al tener los datos por separado podemos ver cual de esas cosas esta pasando.

Con los grupos pudimos ver que juegos se parecen por actividad y por notas. En la prediccion se ve que el bosque separo mejor los niveles bajo y alto que el nivel medio. Ademas, trabajamos con juegos que aparecen en Backloggd, asi que los generos con poca presencia pueden quedar menos representados.

En cuanto a los juegos como servicio, ya podemos mostrar ejemplos de lo que publicaron las empresas. Para responder que genero pierde mas dinero todavia necesitamos tener los ingresos y costos de juegos comparables. Lo que si podemos probar en la web es como cambia la popularidad estimada cuando cambiamos las entradas del formulario.

\appendix
\section{Datasheet del catalogo}
\label{sec:datasheet}
\subsection{Como quedo el catalogo}
\label{sec:datos-cambios}
\ProcedenciaDatos

La version que ya tenia notas de prensa traia \Historico\ registros. Cuando repetimos la revision por nombre y fecha, vimos que \Descartes\ filas habian quedado fuera porque repetian esos dos datos. Al volver a limpiar el catalogo con el que trabajamos se mantuvieron sus \Catalogo\ registros.

\subsection{Cuantos juegos entraron en las comparaciones}
Hubo tres registros con diferencias que no pudimos aclarar. Los dejamos en el catalogo y los apartamos de los calculos principales. De ahi quedaron \Elegibles\ juegos para revisar. De esos, \Pares\ tenian completos los datos que usamos para comparar notas y formar grupos. Si sumamos por genero, un mismo juego puede aparecer en varias filas.

\section{Plan de trabajo}
En la primera columna vemos la actividad. En las siguientes esta cuando pensabamos hacerla y cuando quedo el primer registro que encontramos. Si se guardaron varias actividades juntas, esa fecha puede ser posterior al dia en que se hicieron.

\PlanTrabajo

\nocite{chaki2023popular,chapman2000crisp,frank2016weka,\FuentesComerciales}
\clearpage
\pagestyle{referencias}
\printbibliography[heading=bibintoc,title={Referencias}]
\end{document}

````

## main.pdf

Ruta: `DocumentoFinal/main.pdf` · Bytes: 2342007 · SHA-256: `82961284abdf6cecdf6f2d6f8e52b0b0ac4b66cfa79a8df515a5abd7ab049a57`

Contenido no textual o tabla de datos: consultar el original para inspección visual o recálculo.

## main.tex

Ruta: `DocumentoFinal/main.tex` · Bytes: 27295 · SHA-256: `3f19476bb2b20052c435742935062d64cf3063c9f10eebe5d94fb8444f484f0b`

````text
\documentclass[letterpaper,11pt]{article}

% --- PAQUETES DE IDIOMA
\usepackage[spanish,mexico]{babel}
\usepackage[utf8]{inputenc}
\usepackage{csquotes}
\usepackage[backend=biber,style=apa]{biblatex}
\DeclareLanguageMapping{spanish}{spanish-apa}
\addbibresource{referencias.bib}
\usepackage{iftex}

\usepackage{pdfpages}

% --- PAQUETES MATEMÁTICOS --
\usepackage{amsmath}
\usepackage{cancel}
\usepackage{mathrsfs}

% --- PAQUETES GRÁFICOS Y DE DISEÑO ---
\usepackage{graphicx}
\newcommand{\includegraphicssafe}[2] {%
  \IfFileExists{#2}{\includegraphics[width=#1]{#2}}{%
    \fbox{\parbox[c][4cm][c]{#1}{\centering Figura pendiente: \texttt{\detokenize{#2}}}}%
  }%
}
\usepackage{float}
\usepackage{placeins}
\usepackage{subcaption}
\usepackage[table]{xcolor}
\usepackage{makecell}
\usepackage{array}
\usepackage{longtable}
\usepackage{tabularx}
\newcolumntype{Y}{>{\raggedright\arraybackslash}X}
\usepackage{booktabs}
\newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
\usepackage{tikz}
\usetikzlibrary{shapes.geometric, shapes.multipart, positioning, arrows.meta, calc, shadows, decorations.pathreplacing,babel}

% --- LISTAS ---
\usepackage{enumitem}

% --- PAQUETES DE CÓDIGO ---
\usepackage{listings}
% Configuración del estilo de listings
\definecolor{codebg}{rgb}{0.95,0.95,0.95}   
\definecolor{keyword}{rgb}{0.0,0.2,0.6}     
\definecolor{comment}{rgb}{0.25,0.5,0.35}   
\definecolor{string}{rgb}{0.6,0.0,0.0}      
\definecolor{number}{rgb}{0.5,0.0,0.5}      
\definecolor{codegray}{rgb}{0.5,0.5,0.5}
\definecolor{codepurple}{rgb}{0.58,0,0.82}
\definecolor{backcolour}{rgb}{0.95,0.95,0.95}

\lstset{
  backgroundcolor=\color{backcolour},
  basicstyle=\ttfamily\small,
  keywordstyle=\color{blue}\bfseries,
  stringstyle=\color{codepurple},
  commentstyle=\color{codegray}\itshape,
  numbers=left,
  numberstyle=\tiny\color{codegray},
  frame=single,
  rulecolor=\color{black},
  breaklines=true,
  tabsize=4,
  showstringspaces=false,
  literate={á}{{\'a}}1
           {é}{{\'e}}1
           {í}{{\'i}}1
           {ó}{{\'o}}1
           {ú}{{\'u}}1
           {Á}{{\'A}}1
           {É}{{\'E}}1
           {Í}{{\'I}}1
           {Ó}{{\'O}}1
           {Ú}{{\'U}}1
           {ñ}{{\~n}}1
           {Ñ}{{\~N}}1
           {¿}{{\textquestiondown}}1
           {¡}{{\textexclamdown}}1
}

% Estilo para código en C
\lstdefinestyle{cstyle}{
  language=C,
  backgroundcolor=\color{backcolour},
  basicstyle=\ttfamily\small,
  keywordstyle=\color{blue}\bfseries,
    keywordstyle= \color{yellow!70!orange}\bfseries,
    morekeywords= {MPI_Init,MPI_Comm_size,MPI_Comm_rank,MPI_Send,MPI_Recv,MPI_Scatter,MPI_Gather,MPI_Bcast,MPI_Reduce,MPI_Finalize},
    emph={printf},
    emphstyle=\color{blue}\bfseries,
  stringstyle=\color{codepurple},
  commentstyle=\color{codegray}\itshape,
  numbers=left,
  numberstyle=\tiny\color{codegray},
  frame=single,
  rulecolor=\color{black},
  breaklines=true,
  tabsize=4,
  showstringspaces=false
}

% Definición del lenguaje Python para listings
\lstdefinelanguage[LAB]{Python}{
    morekeywords={False, None, True, and, as, assert, async, await, break,
                                class, continue, def, del, elif, else, except, finally,
                                for, from, global, if, import, in, is, lambda, nonlocal,
                                not, or, pass, raise, return, try, while, with, yield,
                                machine, Pin, PWM, ADC, Timer, sleep_ms, sleep_us},
    morecomment=[l]{\#},
    morestring=[b]",
    morestring=[b]',
    sensitive=true
}

% Estilo para salidas de consola/terminal
\lstdefinestyle{output}{
  backgroundcolor=\color{black!5},
  basicstyle=\ttfamily\footnotesize,
  numbers=none,
  frame=single,
  rulecolor=\color{black!30},
  breaklines=true,
  tabsize=4,
  showstringspaces=false,
  xleftmargin=0.5cm,
  xrightmargin=0.5cm
}

% --- ESTILOS PARA DIAGRAMAS DE FLUJO (TIKZ) ---
\tikzset{
  startstop/.style={rectangle, rounded corners, minimum width=3cm, minimum height=1cm,text centered, draw=black, fill=red!30},
  process/.style={rectangle, minimum width=3cm, minimum height=1cm, text centered, draw=black, fill=orange!30},
  decision/.style={diamond, aspect=2, minimum width=3cm, minimum height=1cm, text centered, draw=black, fill=green!30},
  io/.style={trapezium, trapezium left angle=70, trapezium right angle=110, minimum width=3cm, minimum height=1cm, text centered, draw=black, fill=blue!30},
  arrow/.style={thick,->,>=stealth}
}


\definecolor{azulresultado}{HTML}{0072C6}
\definecolor{rojoacarreo}{HTML}{FF0000}

% --- RUTAS DE IMÁGENES ---
\graphicspath{{img/}{portada_img/}}

\definecolor{armblue}{RGB}{0, 113, 188}

% --- ÍNDICE CON PUNTOS ---
\usepackage{tocloft}
\renewcommand{\cftsecleader}{\cftdotfill{\cftdotsep}}

% --- CONFIGURACIÓN DE PÁGINA (GEOMETRÍA) ---
\usepackage[
    left=25mm, 
    right=25mm,
    top=35mm,
    bottom=30mm,
    headheight=77pt, 
    papersize={21.59cm,27.94cm}
]{geometry}

% --- FORMATO DE TEXTO ---
\usepackage{setspace}
\onehalfspacing
\usepackage{parskip} 
\usepackage{lipsum}  

% --- VARIABLES GLOBALES ---
\newcommand{\materia}{}

% --- ENCABEZADOS Y PIES DE PÁGINA ---
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{} 
\fancyhead[L]{\includegraphics[height=1.5cm]{portada_img/der.png}}
\fancyhead[R]{\includegraphics[height=1.5cm]{portada_img/izq.png}}
\fancyfoot[C]{\thepage} 
\renewcommand{\headrulewidth}{0.4pt} 
\renewcommand{\footrulewidth}{0pt}  

\fancypagestyle{indice}{
  \fancyhf{}
  \fancyhead[L]{\includegraphics[height=1.5cm]{portada_img/der.png}}
  \fancyhead[R]{\includegraphics[height=1.5cm]{portada_img/izq.png}}
  \fancyfoot{}
  \renewcommand{\headrulewidth}{0.4pt}
  \renewcommand{\footrulewidth}{0pt}
}

\fancypagestyle{referencias}{
  \fancyhf{}
  \fancyhead[L]{\includegraphics[height=1.5cm]{portada_img/der.png}}
  \fancyhead[R]{\includegraphics[height=1.5cm]{portada_img/izq.png}}
  \renewcommand{\headrulewidth}{0.4pt}
  \renewcommand{\footrulewidth}{0pt}
}

% --- HIPERVÍNCULOS ---
\usepackage{hyperref}
\hypersetup{
    colorlinks=true,
    linkcolor=blue,
    citecolor=blue,
    filecolor=magenta,
    urlcolor=cyan
}


\usepackage{xurl}
\usepackage{caption}
\captionsetup[table]{skip=8pt}
\addto\captionsspanish{\renewcommand{\contentsname}{Indice}}
\setcounter{tocdepth}{1}
\newcommand{\captura}[3]{%
  \begin{figure}[!htbp]
  \centering
  \includegraphics[width=\linewidth,height=.40\textheight,keepaspectratio]{figuras/#1}
  \caption{#2}\label{#3}
  \end{figure}\FloatBarrier
}
\begin{document}
\hypersetup{pageanchor=false}
\begin{titlepage}\input{Portada.tex}\end{titlepage}
\newpage
{\makeatletter\let\ps@plain\ps@indice\makeatother
\pagestyle{indice}\thispagestyle{indice}\hypersetup{linkcolor=black}\tableofcontents\thispagestyle{indice}}
\newpage\setcounter{page}{1}\hypersetup{pageanchor=true}\singlespacing
\input{cifras_informe.tex}
\section{Objetivos del proyecto}
\begin{itemize}
\item Revisar como se relacionan las notas de usuarios y prensa en el catalogo, por genero y por organizacion.
\item Comparar la actividad acumulada, la actividad actual, los juegos pendientes y las listas de deseos para entender que muestra cada indicador.
\item Buscar grupos de juegos con actividad, interes y recepcion parecidos.
\item Estimar el nivel de popularidad de un juego a partir de su genero, organizacion, decada y calificaciones, y revisar en que casos se equivoca el modelo.
\item Mostrar los resultados en una aplicacion donde se puedan filtrar los juegos y probar los parametros de una prediccion.
\end{itemize}

\section{Datos del proyecto}
\subsection{De donde salen los datos}
Primero usamos como base un catalogo de Backloggd que Arnab Chaki publico en Kaggle. Antes de hacer el analisis ya se habian agregado las notas de Metacritic. Esa version tenia \Historico\ registros y, despues de revisar titulos y fechas repetidos, quedaron \Catalogo. En el datasheet, en el apartado~\ref{sec:datos-cambios}, se ve cuantos registros habia en cada paso. Si dos juegos tienen el mismo nombre, tambien revisamos la fecha para distinguirlos.

\subsection{Que significan las columnas}
\begin{description}
\item[Partidas registradas.] Es el conteo acumulado de registros de personas que marcaron el juego como jugado en Backloggd. Una persona puede haberlo marcado aunque ya no lo este jugando.
\item[Jugando actualmente.] Es cuantas personas lo tenian marcado como juego en curso al momento de recopilar los datos.
\item[Juegos pendientes.] Es cuantas personas lo agregaron a su lista para jugarlo mas adelante.
\item[Lista de deseos.] Es cuantas personas lo agregaron a la lista de titulos que les interesan.
\item[Calificacion de usuarios y nota de prensa.] La primera va de 0 a 5 y la segunda de 0 a 100. Cuando comparamos las dos notas, primero las ponemos en la misma escala.
\item[Generos, organizacion y fecha.] Un juego puede tener mas de un genero. El campo de organizaciones puede incluir a estudios y editoras. De la fecha se obtiene la decada de lanzamiento.
\end{description}

\section{Como se hizo el analisis}
Para ordenar el trabajo seguimos CRISP-DM. Primero vimos que queriamos averiguar y que datos teniamos para hacerlo. Despues limpiamos el catalogo, hicimos las graficas y probamos los grupos y las predicciones. Al final pusimos los resultados en Streamlit para poder revisar que pasa al cambiar los datos del formulario.

\subsection{Preparacion de los datos}
Lo primero que revisamos fue como venian los conteos. Si un dato viene como 1.2 mil, hay que leerlo como 1,200. En este caso los conteos ya venian como numeros. Tambien revisamos las fechas y dejamos sin decada los juegos cuya fecha no se pudo leer. Un mismo juego puede ser de aventura y de rol, asi que lo contamos en ambos cuando comparamos generos.

Para comparar las notas usamos los juegos que tenian las dos. Algunas cifras que venian en la columna de prensa se habian estimado, asi que las dejamos fuera de esa comparacion. Ahora bien, si queremos probar un juego en la web y no tenemos su nota de prensa, podemos marcar esa opcion. Lo que hace el modelo en ese caso es usar la mediana, que es la nota que queda en medio al ordenar las notas de entrenamiento.

\section{Problematica a atender}
Una nota alta nos dice que a quienes calificaron el juego les gusto. Ahora bien, para saber que tanto se jugo o si la gente tiene ganas de jugarlo tenemos que ver los otros conteos. En los juegos como servicio hay otra pregunta. Si se sigue gastando en mantener el juego despues del lanzamiento, ¿cuanto de lo que se gasto se llega a recuperar?

\subsection{Que encontramos en los casos publicados}
\CasosComerciales

En estos casos cada empresa dio un dato distinto. En uno sabemos que se cerro el juego y se devolvio el dinero. En otro sabemos cuantas copias se vendieron en cierto tiempo. Para decir que genero tuvo mas juegos con perdidas tendriamos que conocer cuanto ingreso y cuanto costo cada juego, incluyendo los que recuperaron su dinero y los que quedaron por debajo.

\subsection{Como se podria comparar el riesgo por genero}
Para hacer esa comparacion primero escogeriamos juegos que salieron en fechas parecidas. Despues sumariamos los gastos de desarrollo, publicidad y operacion, y revisariamos si cada juego los recupero en sus primeros 24 meses. Tambien separariamos los juegos como servicio y tomariamos en cuenta el presupuesto, la plataforma, el tamaño del estudio y si el juego ya venia de una franquicia. Si queremos saber si una prediccion ayuda a evitar perdidas, habria que comparar que paso con proyectos donde si se uso el modelo y proyectos que siguieron el proceso habitual.

\section{Que vimos en las graficas}
\subsection{Actividad e interes por genero}
En la figura~\ref{fig:actividad} lo que vemos es una fila por genero. La linea de cada caja nos dice que conteo quedo a la mitad y la caja nos muestra donde se concentra la mitad central de los juegos. Los puntos que quedan aparte son juegos con conteos alejados del resto. Si dos generos tienen la linea casi en el mismo lugar, podemos ver cual tiene los juegos mas dispersos fijandonos en cual caja es mas larga.

Ahora bien, si vemos los numeros de abajo, de 100 a 1,000 hay el mismo espacio que de 1,000 a 10,000. Esto pasa porque cada salto multiplica por diez. Usamos esa escala para que en la misma grafica alcancen a verse los juegos que tienen pocos registros y los que tienen muchos.

\captura{web_actividad_nueva.jpg}{Distribucion de actividad por genero en la pestaña Señales de actividad.}{fig:actividad}

\subsection{Como se comparan usuarios y prensa}
Primero pasamos la nota de usuarios a la escala de 100. Por ejemplo, 4 de 5 se vuelve 80. Si para el mismo juego la prensa puso 90, al restar quedan $-10$ puntos. El signo menos nos dice que la prensa le dio mas y el 10 nos dice por cuanto.

De los juegos que tenian las dos notas usamos \Pares. Pearson nos dio \PearsonGlobal\ y Spearman \SpearmanGlobal. Lo que nos dicen esos numeros es que las notas suelen moverse en el mismo sentido. Pearson usa los valores de las notas y Spearman se fija en el lugar que ocupa cada juego al ordenarlas. Para hacer el calculo por genero u organizacion usamos grupos con al menos 20 juegos con las dos notas.

\AsociacionGrupos

En la tabla podemos ver el caso de Disparos. La relacion sale positiva y, al mismo tiempo, hay casi 13 puntos de diferencia entre notas en promedio. Pensemos en dos listas donde los primeros juegos son los mismos, pero una lista tiene calificaciones mas altas. Los juegos quedan en lugares parecidos aunque las notas no sean iguales.

\subsection{Como escogimos la cantidad de grupos}
Para hacer los grupos usamos cuatro conteos y las dos notas. Como los conteos pueden venir en miles y una de las notas llega a 5, primero ajustamos los conteos grandes y despues pusimos las seis medidas en una escala que se pudiera comparar. De esa forma, el conteo no domina el grupo solo porque su numero es mas grande.

La grafica de la izquierda de la figura~\ref{fig:kmeans} nos muestra que tan cerca quedan los juegos del centro de su grupo. En la de la derecha, el punto mas alto queda en dos grupos. A ese valor le llamamos silueta y nos ayuda a ver que tan bien se separan los grupos. Para Ward tambien quedaron dos. Si vemos el arbol de la figura~\ref{fig:ward}, las ramas que se juntan abajo corresponden a grupos mas parecidos. Las que se unen arriba estaban mas separadas.

\captura{clustering_03_kmeans.png}{Comparacion de cortes para K-Means. A la derecha se muestra la separacion entre grupos.}{fig:kmeans}
\captura{clase_ward_dendrograma.png}{Arbol de Ward. Los numeros entre parentesis indican cuantos juegos resume cada rama.}{fig:ward}

\SilTitulo

En la tabla buscamos valores altos en Silueta y Calinski--Harabasz y un valor bajo en Davies--Bouldin. En este caso, al usar los mismos juegos, K-Means quedo mejor en las tres medidas.

\Perfiles
Lo que se ve al comparar los promedios es que un grupo reune juegos con mas actividad, mas pendientes y notas mas altas. En el otro grupo esos numeros son menores. Como estamos viendo promedios, puede haber juegos individuales que se salgan de ese patron.

Con DBSCAN revisamos donde se juntaban muchos puntos. Nos dio \GruposDbscan\ grupo y dejo \RuidoDbscan\ juegos aparte porque tenian pocos vecinos cercanos. En la figura~\ref{fig:pca}, cada punto es un juego y el color nos dice en que grupo quedo. Los dos ejes resumen las seis medidas. Si vemos el panel de DBSCAN, aparece un conjunto grande y unos cuantos puntos separados.

\captura{pca_tres_metodos.png}{Mapa de juegos con los grupos de K-Means, Ward y DBSCAN.}{fig:pca}

\section{El modelo de popularidad}
\subsection{Que aprende el modelo}
Primero ordenamos los juegos tres veces. Una por partidas registradas, otra por deseos y otra por pendientes. De los tres lugares que tuvo cada juego sacamos un promedio. Despues separamos los juegos en tres partes de tamaño parecido. De ahi salen los niveles bajo, medio y alto. Cuando le pedimos al modelo que estime uno de esos niveles, le damos el genero, la organizacion, la decada y las dos notas. Los tres conteos sirven para saber cual era el nivel del juego y comprobar si le atino.

Apartamos \JuegosPrueba\ juegos para la prueba final. Con los demas hicimos diez bloques. Entrenamos con nueve y revisamos el que quedo fuera, hasta pasar por todos. Volvimos a formar los bloques cinco veces. La configuracion se escogio con los datos usados para entrenar en cada vuelta y mantuvimos juntos los registros con el mismo titulo.

\subsection{Como se eligio el modelo para la web}
\ComparacionModelos

La exactitud nos dice cuantos juegos quedaron en el nivel correcto. El F1 macro le da el mismo peso a cada nivel, asi que tambien toma en cuenta como salio el que mas le cuesta al modelo. Si vemos los promedios, la red neuronal quedo un poco arriba. La prueba que compara esa diferencia dio \PComparacion. Con ese resultado todavia no podemos decir cual rinde mejor. Para la web dejamos Random Forest porque sus resultados cambiaron menos entre vueltas y podemos revisar que datos uso mas.

\subsection{Que paso en la prueba}
\MatrizConfusion

En la diagonal estan los aciertos. En la fila de nivel medio vemos que acerto \AciertosMedio\ de \TotalMedio. Si seguimos leyendo esa fila, vemos cuantos quedaron como bajos y cuantos como altos. El resultado de toda la prueba fue \ExactitudPrueba\ de exactitud y \FPrueba\ de F1 macro. Como ya habiamos probado la red neuronal con esos mismos juegos, para saber como saldria con lanzamientos nuevos tendriamos que probar con otro grupo.

Para ver un error concreto, en la tabla de abajo aparece Resident Evil 4: Wii Edition. Segun los conteos del catalogo quedo en el nivel bajo y el modelo lo puso en alto. Lo podemos comparar con los otros ejemplos para ver en que niveles se equivoco, usando como referencia las partidas registradas, los pendientes y los deseos.

\EjemplosError

\subsection{Como ajustamos las probabilidades}
Si a varios juegos les damos cerca de 70\,\% de probabilidad de quedar en alto, esperamos que alrededor de siete de cada diez terminen en ese nivel. Para acercar los porcentajes a lo que observamos usamos un ajuste llamado escalado de temperatura. Lo calculamos con \JuegosCalibracion\ juegos de entrenamiento. Para obtener el porcentaje de cada juego usamos un bosque que se entreno dejando fuera su bloque. Despues comparamos los porcentajes con y sin el ajuste en los \JuegosPrueba\ juegos apartados para la prueba.

\MetricasCalibracion

Las dos medidas bajaron en esta prueba. Brier compara las tres probabilidades con el nivel que realmente obtuvo cada juego. Log-loss aumenta sobre todo cuando el modelo asigna una probabilidad muy baja al nivel que si ocurrio. El ajuste cambia los porcentajes y mantiene el nivel con la barra mas larga.

En la pagina Modelo podemos elegir alto, medio o bajo. En la figura~\ref{fig:fiabilidad} elegimos alto. Cada punto agrupa juegos a los que el bosque les dio porcentajes parecidos. Abajo leemos la probabilidad media y a la izquierda vemos que parte de esos juegos quedo en alto. Si el punto cae sobre la diagonal, los dos porcentajes coinciden. La linea morada muestra los valores originales y la azul los ajustados.

\captura{web_calibracion.jpg}{Probabilidades antes y despues del ajuste para el nivel alto en la pagina Modelo.}{fig:fiabilidad}

\section{Comparacion con Weka}
Tambien hicimos la comparacion en Weka. Lo que vemos en la parte de arriba de la figura~\ref{fig:weka} es cuantos juegos acerto el bosque. Abajo se ve cuales confundio con otro nivel. En Weka salio con la exactitud mas alta de los cuatro modelos. En ese caso la prueba se hizo por diez bloques. En la web mostramos el porcentaje obtenido con los juegos que se dejaron aparte para la prueba final.

\ResultadosWeka
\captura{RandomForest.png}{Resultado del bosque en Weka, con exactitud y matriz de aciertos y errores.}{fig:weka}

\section{Como usamos la aplicacion}
Primero abrimos Inicio. Desde ahi podemos pasar a Exploracion para cambiar el genero, la decada o el rango de notas y ver como cambia la consulta. En la parte de arriba estan las pestañas de actividad, notas, grupos y casos comerciales. Si queremos ver los aciertos y errores de la prueba entramos a Modelo.

\captura{web_inicio_nueva.jpg}{Inicio del observatorio con arte de Halo Infinite y Link en el menu lateral.}{fig:inicio}
\captura{web_juegos_destacados.jpg}{Tarjetas de Inicio con imagenes de Zelda, God of War y Super Mario Odyssey.}{fig:juegos-destacados}
\captura{web_exploracion_nueva.jpg}{Filtros y pestañas del tablero de exploracion.}{fig:exploracion}
\captura{web_comercial_nueva.jpg}{Caso comercial en la pestaña de juegos como servicio.}{fig:comercial}
\captura{web_modelo_nueva.jpg}{Ficha de Random Forest en la pagina Modelo.}{fig:modelo}
\captura{web_bitacora_algoritmos.jpg}{Bitacora con los cinco algoritmos y el detalle de la red neuronal seleccionada.}{fig:bitacora-algoritmos}

\subsection{Como se configuran los parametros de prediccion}
Para hacer la prueba entramos a Prediccion. En la figura~\ref{fig:formulario} se ve el formulario. Para repetir lo que aparece en la captura, dejamos los valores asi.

\begin{enumerate}
\item Elegimos uno o varios generos. En este caso dejamos Aventura y Rol, que aparecen como \emph{Adventure} y \emph{RPG} en el menu.
\item En organizacion dejamos «Otro / Organizacion no frecuente». Esta opcion sirve cuando la organizacion no aparece entre las opciones del modelo.
\item Seleccionamos la decada de 2020. La decada se refiere al lanzamiento que queremos representar.
\item Dejamos 82 de 100 en la nota de prensa y 3.9 de 5 en la calificacion de usuarios. Si no conocemos la de prensa, podemos marcar la casilla que simula su ausencia.
\item Presionamos «Analizar lanzamiento» y revisamos el nivel, las tres barras y los juegos similares.
\end{enumerate}

\captura{web_prediccion_formulario.jpg}{Formulario de Prediccion con el fondo de Spider-Man 2 y los valores del ejemplo.}{fig:formulario}

\subsection{Como se lee el resultado}
Con estos valores la web nos regreso el nivel bajo. En la figura~\ref{fig:prediccion}, la barra de bajo quedo en 44.9\,\%, la de medio en 27.8\,\% y la de alto en 27.4\,\%. Bajo es el nivel que el bosque estima como mas probable para este ejemplo.

Si abrimos el menu debajo de las barras, podemos ver los dos cortes del indice y donde empieza cada nivel, como en la figura~\ref{fig:niveles}. Los cortes se calcularon con los juegos de entrenamiento. El indice resume partidas registradas, pendientes y listas de deseos. Los porcentajes de las barras indican que tan probable estima el bosque que el juego caiga en cada rango de ese indice.

\captura{web_prediccion_resultado.jpg}{Probabilidades calibradas con nota de prensa de 82.}{fig:prediccion}
\captura{web_niveles_popularidad.jpg}{Menu desplegado con la definicion y los cortes de los tres niveles.}{fig:niveles}

Debajo del resultado podemos revisar los cinco juegos que mas se parecen a los datos del formulario. En la figura~\ref{fig:juegos-parecidos} cada juego aparece con su portada, su año y la distancia calculada. Una distancia menor indica que el juego se parece mas al ejemplo que ingresamos.

\captura{web_juegos_parecidos.jpg}{Juegos parecidos para el ejemplo de Aventura y Rol con nota de prensa de 82.}{fig:juegos-parecidos}

Cuando falta una portada local, la web busca el titulo y el año en la tienda de Steam. Si no encuentra una ficha que coincida, muestra la organizacion que figura en el catalogo.

\subsubsection*{Conclusion de la consulta}
Cada consulta explica cual de los tres niveles quedo primero y por cuantos puntos porcentuales. Tambien muestra las notas que se usaron. Si quitamos la nota de prensa, indica con que valor se completo. En la figura~\ref{fig:conclusion-prediccion} dejamos Aventura y Rol, y cambiamos las notas a 5 de 5 y 100 de 100. El nivel alto obtuvo 65.4\,\% y el nivel medio quedo segundo con 19.7\,\%.

\captura{web_conclusion_prediccion.jpg}{Conclusion que genero la web con las notas de usuarios y prensa al maximo.}{fig:conclusion-prediccion}

\subsubsection*{Prueba sin nota de prensa}
Dejamos todo igual y marcamos la casilla para quitar la nota de Metacritic. Al volver a presionar el boton, la figura~\ref{fig:sinnnota} muestra que el nivel se mantuvo en bajo y que la barra subio a 47.5\,\%. En ese caso se completo la nota con el valor de en medio de las notas de entrenamiento. Mas abajo se muestran cinco juegos del entrenamiento con caracteristicas parecidas a las que elegimos.

\captura{web_prediccion_sin_nota.jpg}{Probabilidades calibradas al simular que falta la nota de prensa.}{fig:sinnnota}

Despues hicimos otra prueba con 4.8 de usuarios y 99 de prensa. Dejamos los generos, la organizacion y la decada como estaban. Con las dos notas salio alto y al quitar la de prensa salio bajo. La tabla de abajo deja los valores para repetir esa prueba.

\EscenariosNotas

\section{Conclusiones}
Despues de revisar los resultados vimos que una sola nota deja fuera parte de lo que pasa con un juego. Hay casos donde la gente lo tiene en deseos o en pendientes y todavia no lo marca como jugado. Tambien hay juegos donde la prensa dio mas puntos que los usuarios. Al tener los datos por separado podemos ver cual de esas cosas esta pasando.

Con los grupos pudimos ver que juegos se parecen por actividad y por notas. En la prediccion se ve que el bosque separo mejor los niveles bajo y alto que el nivel medio. Ademas, trabajamos con juegos que aparecen en Backloggd, asi que los generos con poca presencia pueden quedar menos representados.

En cuanto a los juegos como servicio, ya podemos mostrar ejemplos de lo que publicaron las empresas. Para responder que genero pierde mas dinero todavia necesitamos tener los ingresos y costos de juegos comparables. Lo que si podemos probar en la web es como cambia la popularidad estimada cuando cambiamos las entradas del formulario.

\appendix
\section{Datasheet del catalogo}
\label{sec:datasheet}
\subsection{Como quedo el catalogo}
\label{sec:datos-cambios}
\ProcedenciaDatos

La version que ya tenia notas de prensa traia \Historico\ registros. Cuando repetimos la revision por nombre y fecha, vimos que \Descartes\ filas habian quedado fuera porque repetian esos dos datos. Al volver a limpiar el catalogo con el que trabajamos se mantuvieron sus \Catalogo\ registros.

\subsection{Cuantos juegos entraron en las comparaciones}
Hubo tres registros con diferencias que no pudimos aclarar. Los dejamos en el catalogo y los apartamos de los calculos principales. De ahi quedaron \Elegibles\ juegos para revisar. De esos, \Pares\ tenian completos los datos que usamos para comparar notas y formar grupos. Si sumamos por genero, un mismo juego puede aparecer en varias filas.

\section{Plan de trabajo}
En la primera columna vemos la actividad. En las siguientes esta cuando pensabamos hacerla y cuando quedo el primer registro que encontramos. Si se guardaron varias actividades juntas, esa fecha puede ser posterior al dia en que se hicieron.

\PlanTrabajo

\nocite{chaki2023popular,chapman2000crisp,frank2016weka,\FuentesComerciales}
\clearpage
\pagestyle{referencias}
\printbibliography[heading=bibintoc,title={Referencias}]
\end{document}

````

## referencias.bib

Ruta: `DocumentoFinal/referencias.bib` · Bytes: 4997 · SHA-256: `558785022341f97ac3ebc35f48c81fe1c883626fc9ae2de667f6491dead9a6ee`

````text
@online{chaki2023popular,
  author     = {Chaki, Arnab},
  title      = {Popular video games 1980--2023},
  date       = {2023},
  organization = {Kaggle},
  url        = {https://www.kaggle.com/datasets/arnabchaki/popular-video-games-1980-2023},
  urldate    = {2026-11-09},
  type       = {Conjunto de datos},
  langid     = {english}
}

@online{chapman2000crisp,
  author  = {Chapman, Pete and Clinton, Julian and Kerber, Randy and Khabaza, Thomas and Reinartz, Thomas and Shearer, Colin and Wirth, Rüdiger},
  title   = {{CRISP-DM} 1.0: Step-by-step data mining guide},
  date    = {2000},
  organization = {SPSS Inc.},
  url = {https://public.dhe.ibm.com/software/analytics/spss/documentation/modeler/14.2/es/CRISP-DM.pdf},
  langid  = {english}
}

@article{pedregosa2011scikit,
  author  = {Pedregosa, Fabian and Varoquaux, Gaël and Gramfort, Alexandre and Michel, Vincent and Thirion, Bertrand and Grisel, Olivier and Blondel, Mathieu and Prettenhofer, Peter and Weiss, Ron and Dubourg, Vincent and Vanderplas, Jake and Passos, Alexandre and Cournapeau, David and Brucher, Matthieu and Perrot, Matthieu and Duchesnay, Edouard},
  title   = {Scikit-learn: Machine learning in {Python}},
  journaltitle = {Journal of Machine Learning Research},
  date    = {2011},
  volume  = {12},
  pages   = {2825--2830},
  langid  = {english}
}

@inproceedings{mckinney2010pandas,
  author  = {McKinney, Wes},
  title   = {Data structures for statistical computing in {Python}},
  booktitle = {Proceedings of the 9th {Python} in Science Conference},
  date    = {2010},
  pages   = {56--61},
  langid  = {english}
}

@book{frank2016weka,
  author  = {Frank, Eibe and Hall, Mark A. and Witten, Ian H.},
  title   = {The {WEKA} workbench. Online appendix for ``Data mining: Practical machine learning tools and techniques''},
  edition = {4},
  publisher = {Morgan Kaufmann},
  date    = {2016},
  langid  = {english}
}

@inproceedings{ester1996dbscan,
  author  = {Ester, Martin and Kriegel, Hans-Peter and Sander, Jörg and Xu, Xiaowei},
  title   = {A density-based algorithm for discovering clusters in large spatial databases with noise},
  booktitle = {Proceedings of the Second International Conference on Knowledge Discovery and Data Mining ({KDD}-96)},
  publisher = {AAAI Press},
  date    = {1996},
  pages   = {226--231},
  langid  = {english}
}


@online{sklearncv,author={{scikit-learn developers}},title={Cross-validation evaluating estimator performance},url={https://scikit-learn.org/stable/modules/cross_validation.html},urldate={2026-11-09}}
@online{wekaweb,author={{University of Waikato}},title={The Weka Workbench},url={https://ml.cms.waikato.ac.nz/weka/},urldate={2026-11-09}}

@article{nadeau2003,
  author = {Nadeau, Claude and Bengio, Yoshua},
  date = {2003},
  title = {Inference for the generalization error},
  journaltitle = {Machine Learning},
  volume = {52},
  number = {3},
  pages = {239--281},
  doi = {10.1023/A:1024068626366},
  langid = {english}
}

@article{demsar2006,
  author = {Demsar, Janez},
  date = {2006},
  title = {Statistical comparisons of classifiers over multiple data sets},
  journaltitle = {Journal of Machine Learning Research},
  volume = {7},
  pages = {1--30},
  url = {https://www.jmlr.org/papers/v7/demsar06a.html},
  langid = {english}
}

@online{ellis2024concord,
  author = {Ellis, Ryan},
  date = {2024-09-03},
  title = {An important update on {Concord}},
  organization = {PlayStation.Blog},
  url = {https://blog.playstation.com/2024/09/03/an-important-update-on-concord/},
  langid = {english}
}

@online{hulst2024firewalk,
  author = {Hulst, Hermen},
  date = {2024-10-29},
  title = {An update from {PlayStation Studios}},
  organization = {Sony Interactive Entertainment},
  url = {https://sonyinteractive.com/en/news/blog/an-update-from-playstation-studios/},
  langid = {english}
}

@online{ubisoft2024xdefiant,
  author = {{Ubisoft}},
  date = {2024-12-04},
  title = {Ubisoft discontinues development on {XDefiant}},
  type = {Comunicado de prensa},
  url = {https://staticctf.ubisoft.com/8aefmxkxpxwl/3vzLJjyWT9zUqMoxdSDRRR/f2531c0af58c76ae3c9b0413e1fd1ccb/PRESS_RELEASE.pdf},
  langid = {english}
}

@online{sony2024suplemento,
  author = {{Sony Group Corporation}},
  date = {2024-11-08},
  title = {FY2024 second quarter supplemental information},
  url = {https://www.sony.com/en/SonyInfo/IR/library/er/pdf/24q2_supplement.pdf},
  langid = {english}
}

@online{sony2024resultados,
  author = {{Sony Group Corporation}},
  date = {2024-05-14},
  title = {Consolidated financial results for the fiscal year ended March 31, 2024: Speech transcript},
  url = {https://www.sony.com/en/SonyInfo/IR/library/presen/er/pdf/23q4_sonyspeech.pdf},
  langid = {english}
}

@online{squareenix2023forspoken,
  author = {{Square Enix Holdings}},
  date = {2023},
  title = {Outline of results briefing held on February 3, 2023},
  url = {https://www.hd.square-enix.com/eng/ir/library/docs/20230203/page02.html},
  langid = {english}
}

````

