# Lectura del comparativo Python / Weka

El CSV contiene únicamente Python y Weka: dos filas de clustering y cuatro de clasificación por herramienta. Las celdas vacías de exactitud y F1 en clustering significan que esas métricas de clasificación no aplican.

Exactitud usa porcentaje en todas las filas numéricas. Para Python se multiplicó por 100 la proporción ya guardada en models/metadata.json; cada fila conserva el valor fuente en notas. Los números de Weka se mantienen exactamente como aparecen en el panel. El signo ? de ZeroR también se conserva.

F1 mantiene la definición original de cada experimento: macro de prueba en Python y F-Measure ponderada de validación cruzada en Weka. Python evalúa 222 casos reservados después de seleccionar modelos por CV; Weka usa CV estratificada de diez pliegues sobre 892 casos exportados con transformaciones previas. CategoricalNB y NaiveBayes tampoco son la misma variante. Las filas documentan resultados existentes y no acreditan una comparación controlada entre implementaciones.

Orange se excluye del comparativo por decisión documentada en reports/codex_log.md. No se generaron ni atribuyeron métricas a Orange.

## Que debo verificar manualmente

- No comparar F1 macro con F1 ponderado como si fueran idénticos.
- No tratar la prueba reservada de Python y la CV de Weka como una evaluación sobre los mismos casos.
