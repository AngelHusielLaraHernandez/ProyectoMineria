# Documento final

Compilar desde esta carpeta con `latexmk -pdf -interaction=nonstopmode main.tex`. Requiere LaTeX, biblatex APA y biber.

`generar_documento.py` reconstruye el texto y copia tablas de Final; la compilación de main.tex es autónoma con las figuras incluidas. Fecha de corte: 9 de noviembre de 2026. No se atribuye entrega formal ni publicación pública.
